#include "dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_176_fu_103947_p1() {
    zext_ln703_176_fu_103947_p1 = esl_zext<16,15>(add_ln703_1160_fu_103941_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_177_fu_102935_p1() {
    zext_ln703_177_fu_102935_p1 = esl_zext<12,9>(add_ln703_1162_fu_102929_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_178_fu_103951_p1() {
    zext_ln703_178_fu_103951_p1 = esl_zext<15,12>(add_ln703_1163_reg_104201.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_179_fu_103039_p1() {
    zext_ln703_179_fu_103039_p1 = esl_zext<13,11>(add_ln703_1177_fu_103033_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_180_fu_103049_p1() {
    zext_ln703_180_fu_103049_p1 = esl_zext<13,12>(add_ln703_1178_fu_103043_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_181_fu_103059_p1() {
    zext_ln703_181_fu_103059_p1 = esl_zext<14,13>(add_ln703_1179_fu_103053_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_182_fu_103069_p1() {
    zext_ln703_182_fu_103069_p1 = esl_zext<13,12>(add_ln703_1180_fu_103063_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_183_fu_103079_p1() {
    zext_ln703_183_fu_103079_p1 = esl_zext<13,11>(add_ln703_1181_fu_103073_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_184_fu_103089_p1() {
    zext_ln703_184_fu_103089_p1 = esl_zext<14,13>(add_ln703_1182_fu_103083_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_185_fu_103982_p1() {
    zext_ln703_185_fu_103982_p1 = esl_zext<16,14>(add_ln703_1183_reg_104216.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_186_fu_103105_p1() {
    zext_ln703_186_fu_103105_p1 = esl_zext<13,12>(add_ln703_1184_fu_103099_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_187_fu_103115_p1() {
    zext_ln703_187_fu_103115_p1 = esl_zext<13,12>(add_ln703_1185_fu_103109_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_188_fu_103125_p1() {
    zext_ln703_188_fu_103125_p1 = esl_zext<15,13>(add_ln703_1186_fu_103119_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_189_fu_103263_p1() {
    zext_ln703_189_fu_103263_p1 = esl_zext<9,8>(sext_ln703_650_fu_103259_p1.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_190_fu_103273_p1() {
    zext_ln703_190_fu_103273_p1 = esl_zext<11,9>(add_ln703_1204_fu_103267_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_191_fu_103299_p1() {
    zext_ln703_191_fu_103299_p1 = esl_zext<14,12>(add_ln703_1209_fu_103293_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_192_fu_103309_p1() {
    zext_ln703_192_fu_103309_p1 = esl_zext<15,14>(add_ln703_1210_fu_103303_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_193_fu_103319_p1() {
    zext_ln703_193_fu_103319_p1 = esl_zext<14,11>(add_ln703_1211_fu_103313_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_194_fu_103335_p1() {
    zext_ln703_194_fu_103335_p1 = esl_zext<15,14>(add_ln703_1213_fu_103329_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_195_fu_104025_p1() {
    zext_ln703_195_fu_104025_p1 = esl_zext<16,15>(add_ln703_1214_reg_104241.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_196_fu_103357_p1() {
    zext_ln703_196_fu_103357_p1 = esl_zext<13,11>(add_ln703_1216_fu_103351_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_197_fu_103367_p1() {
    zext_ln703_197_fu_103367_p1 = esl_zext<16,13>(add_ln703_1217_fu_103361_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_198_fu_103521_p1() {
    zext_ln703_198_fu_103521_p1 = esl_zext<14,12>(add_ln703_1240_fu_103515_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_199_fu_103531_p1() {
    zext_ln703_199_fu_103531_p1 = esl_zext<13,12>(add_ln703_1241_fu_103525_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_200_fu_103541_p1() {
    zext_ln703_200_fu_103541_p1 = esl_zext<13,12>(add_ln703_1242_fu_103535_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_201_fu_103551_p1() {
    zext_ln703_201_fu_103551_p1 = esl_zext<14,13>(add_ln703_1243_fu_103545_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_202_fu_104056_p1() {
    zext_ln703_202_fu_104056_p1 = esl_zext<16,14>(add_ln703_1244_reg_104266.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_203_fu_103567_p1() {
    zext_ln703_203_fu_103567_p1 = esl_zext<16,14>(add_ln703_1245_fu_103561_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_204_fu_103677_p1() {
    zext_ln703_204_fu_103677_p1 = esl_zext<14,13>(add_ln703_1260_fu_103671_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_205_fu_103725_p1() {
    zext_ln703_205_fu_103725_p1 = esl_zext<12,10>(add_ln703_1269_fu_103719_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_206_fu_103741_p1() {
    zext_ln703_206_fu_103741_p1 = esl_zext<13,12>(add_ln703_1271_fu_103735_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_207_fu_103757_p1() {
    zext_ln703_207_fu_103757_p1 = esl_zext<12,11>(add_ln703_1273_fu_103751_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_208_fu_103767_p1() {
    zext_ln703_208_fu_103767_p1 = esl_zext<13,12>(add_ln703_1274_fu_103761_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_209_fu_104104_p1() {
    zext_ln703_209_fu_104104_p1 = esl_zext<16,13>(add_ln703_1275_reg_104296.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_210_fu_103783_p1() {
    zext_ln703_210_fu_103783_p1 = esl_zext<13,12>(add_ln703_1276_fu_103777_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_211_fu_103793_p1() {
    zext_ln703_211_fu_103793_p1 = esl_zext<13,12>(add_ln703_1277_fu_103787_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_212_fu_103803_p1() {
    zext_ln703_212_fu_103803_p1 = esl_zext<15,13>(add_ln703_1278_fu_103797_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_213_fu_103813_p1() {
    zext_ln703_213_fu_103813_p1 = esl_zext<15,10>(add_ln703_1279_fu_103807_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln703_fu_102791_p1() {
    zext_ln703_fu_102791_p1 = esl_zext<13,12>(add_ln703_1145_fu_102785_p2.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln708_336_fu_101228_p1() {
    zext_ln708_336_fu_101228_p1 = esl_zext<15,8>(p_read15.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln708_337_fu_101272_p1() {
    zext_ln708_337_fu_101272_p1 = esl_zext<16,7>(lshr_ln708_65_fu_101262_p4.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln708_384_fu_101300_p1() {
    zext_ln708_384_fu_101300_p1 = esl_zext<12,4>(lshr_ln708_66_fu_101290_p4.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln708_385_fu_101996_p1() {
    zext_ln708_385_fu_101996_p1 = esl_zext<12,8>(tmp_807_fu_101986_p4.read());
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_zext_ln708_386_fu_102721_p1() {
    zext_ln708_386_fu_102721_p1 = esl_zext<16,10>(tmp_825_fu_102711_p4.read());
}

}

