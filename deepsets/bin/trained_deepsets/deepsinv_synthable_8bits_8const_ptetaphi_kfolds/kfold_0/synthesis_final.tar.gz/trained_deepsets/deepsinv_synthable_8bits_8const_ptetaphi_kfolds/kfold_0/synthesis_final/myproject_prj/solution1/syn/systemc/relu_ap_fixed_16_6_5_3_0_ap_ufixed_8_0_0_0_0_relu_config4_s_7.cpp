#include "relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_411_fu_18972_p1() {
    zext_ln415_411_fu_18972_p1 = esl_zext<8,1>(tmp_1256_fu_18964_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_412_fu_19080_p1() {
    zext_ln415_412_fu_19080_p1 = esl_zext<8,1>(tmp_1259_fu_19072_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_413_fu_19188_p1() {
    zext_ln415_413_fu_19188_p1 = esl_zext<8,1>(tmp_1262_fu_19180_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_414_fu_19296_p1() {
    zext_ln415_414_fu_19296_p1 = esl_zext<8,1>(tmp_1265_fu_19288_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_415_fu_19404_p1() {
    zext_ln415_415_fu_19404_p1 = esl_zext<8,1>(tmp_1268_fu_19396_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_416_fu_19512_p1() {
    zext_ln415_416_fu_19512_p1 = esl_zext<8,1>(tmp_1271_fu_19504_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_417_fu_19620_p1() {
    zext_ln415_417_fu_19620_p1 = esl_zext<8,1>(tmp_1274_fu_19612_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_418_fu_19728_p1() {
    zext_ln415_418_fu_19728_p1 = esl_zext<8,1>(tmp_1277_fu_19720_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_419_fu_19836_p1() {
    zext_ln415_419_fu_19836_p1 = esl_zext<8,1>(tmp_1280_fu_19828_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_420_fu_19944_p1() {
    zext_ln415_420_fu_19944_p1 = esl_zext<8,1>(tmp_1283_fu_19936_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_421_fu_20052_p1() {
    zext_ln415_421_fu_20052_p1 = esl_zext<8,1>(tmp_1286_fu_20044_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_422_fu_20160_p1() {
    zext_ln415_422_fu_20160_p1 = esl_zext<8,1>(tmp_1289_fu_20152_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_423_fu_20268_p1() {
    zext_ln415_423_fu_20268_p1 = esl_zext<8,1>(tmp_1292_fu_20260_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_424_fu_20376_p1() {
    zext_ln415_424_fu_20376_p1 = esl_zext<8,1>(tmp_1295_fu_20368_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_425_fu_20484_p1() {
    zext_ln415_425_fu_20484_p1 = esl_zext<8,1>(tmp_1298_fu_20476_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_426_fu_20592_p1() {
    zext_ln415_426_fu_20592_p1 = esl_zext<8,1>(tmp_1301_fu_20584_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_427_fu_20700_p1() {
    zext_ln415_427_fu_20700_p1 = esl_zext<8,1>(tmp_1304_fu_20692_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_428_fu_20808_p1() {
    zext_ln415_428_fu_20808_p1 = esl_zext<8,1>(tmp_1307_fu_20800_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_429_fu_20916_p1() {
    zext_ln415_429_fu_20916_p1 = esl_zext<8,1>(tmp_1310_fu_20908_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_430_fu_21024_p1() {
    zext_ln415_430_fu_21024_p1 = esl_zext<8,1>(tmp_1313_fu_21016_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_431_fu_21132_p1() {
    zext_ln415_431_fu_21132_p1 = esl_zext<8,1>(tmp_1316_fu_21124_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_432_fu_21240_p1() {
    zext_ln415_432_fu_21240_p1 = esl_zext<8,1>(tmp_1319_fu_21232_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_433_fu_21348_p1() {
    zext_ln415_433_fu_21348_p1 = esl_zext<8,1>(tmp_1322_fu_21340_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_434_fu_21456_p1() {
    zext_ln415_434_fu_21456_p1 = esl_zext<8,1>(tmp_1325_fu_21448_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_435_fu_21564_p1() {
    zext_ln415_435_fu_21564_p1 = esl_zext<8,1>(tmp_1328_fu_21556_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_436_fu_21672_p1() {
    zext_ln415_436_fu_21672_p1 = esl_zext<8,1>(tmp_1331_fu_21664_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_437_fu_21780_p1() {
    zext_ln415_437_fu_21780_p1 = esl_zext<8,1>(tmp_1334_fu_21772_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_438_fu_21888_p1() {
    zext_ln415_438_fu_21888_p1 = esl_zext<8,1>(tmp_1337_fu_21880_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_439_fu_21996_p1() {
    zext_ln415_439_fu_21996_p1 = esl_zext<8,1>(tmp_1340_fu_21988_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_440_fu_22104_p1() {
    zext_ln415_440_fu_22104_p1 = esl_zext<8,1>(tmp_1343_fu_22096_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_441_fu_22212_p1() {
    zext_ln415_441_fu_22212_p1 = esl_zext<8,1>(tmp_1346_fu_22204_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_442_fu_22320_p1() {
    zext_ln415_442_fu_22320_p1 = esl_zext<8,1>(tmp_1349_fu_22312_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_443_fu_22428_p1() {
    zext_ln415_443_fu_22428_p1 = esl_zext<8,1>(tmp_1352_fu_22420_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_444_fu_22536_p1() {
    zext_ln415_444_fu_22536_p1 = esl_zext<8,1>(tmp_1355_fu_22528_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_445_fu_22644_p1() {
    zext_ln415_445_fu_22644_p1 = esl_zext<8,1>(tmp_1358_fu_22636_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_446_fu_22752_p1() {
    zext_ln415_446_fu_22752_p1 = esl_zext<8,1>(tmp_1361_fu_22744_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_447_fu_22860_p1() {
    zext_ln415_447_fu_22860_p1 = esl_zext<8,1>(tmp_1364_fu_22852_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_448_fu_22968_p1() {
    zext_ln415_448_fu_22968_p1 = esl_zext<8,1>(tmp_1367_fu_22960_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_449_fu_23076_p1() {
    zext_ln415_449_fu_23076_p1 = esl_zext<8,1>(tmp_1370_fu_23068_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_450_fu_23184_p1() {
    zext_ln415_450_fu_23184_p1 = esl_zext<8,1>(tmp_1373_fu_23176_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_451_fu_23292_p1() {
    zext_ln415_451_fu_23292_p1 = esl_zext<8,1>(tmp_1376_fu_23284_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_452_fu_23400_p1() {
    zext_ln415_452_fu_23400_p1 = esl_zext<8,1>(tmp_1379_fu_23392_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_453_fu_23508_p1() {
    zext_ln415_453_fu_23508_p1 = esl_zext<8,1>(tmp_1382_fu_23500_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_454_fu_23616_p1() {
    zext_ln415_454_fu_23616_p1 = esl_zext<8,1>(tmp_1385_fu_23608_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_455_fu_23724_p1() {
    zext_ln415_455_fu_23724_p1 = esl_zext<8,1>(tmp_1388_fu_23716_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_456_fu_23832_p1() {
    zext_ln415_456_fu_23832_p1 = esl_zext<8,1>(tmp_1391_fu_23824_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_457_fu_23940_p1() {
    zext_ln415_457_fu_23940_p1 = esl_zext<8,1>(tmp_1394_fu_23932_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_458_fu_24048_p1() {
    zext_ln415_458_fu_24048_p1 = esl_zext<8,1>(tmp_1397_fu_24040_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_459_fu_24156_p1() {
    zext_ln415_459_fu_24156_p1 = esl_zext<8,1>(tmp_1400_fu_24148_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_460_fu_24264_p1() {
    zext_ln415_460_fu_24264_p1 = esl_zext<8,1>(tmp_1403_fu_24256_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_461_fu_24372_p1() {
    zext_ln415_461_fu_24372_p1 = esl_zext<8,1>(tmp_1406_fu_24364_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_462_fu_24480_p1() {
    zext_ln415_462_fu_24480_p1 = esl_zext<8,1>(tmp_1409_fu_24472_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_463_fu_24588_p1() {
    zext_ln415_463_fu_24588_p1 = esl_zext<8,1>(tmp_1412_fu_24580_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_464_fu_24696_p1() {
    zext_ln415_464_fu_24696_p1 = esl_zext<8,1>(tmp_1415_fu_24688_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_465_fu_24804_p1() {
    zext_ln415_465_fu_24804_p1 = esl_zext<8,1>(tmp_1418_fu_24796_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_466_fu_24912_p1() {
    zext_ln415_466_fu_24912_p1 = esl_zext<8,1>(tmp_1421_fu_24904_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_467_fu_25020_p1() {
    zext_ln415_467_fu_25020_p1 = esl_zext<8,1>(tmp_1424_fu_25012_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_468_fu_25128_p1() {
    zext_ln415_468_fu_25128_p1 = esl_zext<8,1>(tmp_1427_fu_25120_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_469_fu_25236_p1() {
    zext_ln415_469_fu_25236_p1 = esl_zext<8,1>(tmp_1430_fu_25228_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_470_fu_25344_p1() {
    zext_ln415_470_fu_25344_p1 = esl_zext<8,1>(tmp_1433_fu_25336_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_471_fu_25452_p1() {
    zext_ln415_471_fu_25452_p1 = esl_zext<8,1>(tmp_1436_fu_25444_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_472_fu_25560_p1() {
    zext_ln415_472_fu_25560_p1 = esl_zext<8,1>(tmp_1439_fu_25552_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_473_fu_25668_p1() {
    zext_ln415_473_fu_25668_p1 = esl_zext<8,1>(tmp_1442_fu_25660_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_474_fu_25776_p1() {
    zext_ln415_474_fu_25776_p1 = esl_zext<8,1>(tmp_1445_fu_25768_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_475_fu_25884_p1() {
    zext_ln415_475_fu_25884_p1 = esl_zext<8,1>(tmp_1448_fu_25876_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_476_fu_25992_p1() {
    zext_ln415_476_fu_25992_p1 = esl_zext<8,1>(tmp_1451_fu_25984_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_477_fu_26100_p1() {
    zext_ln415_477_fu_26100_p1 = esl_zext<8,1>(tmp_1454_fu_26092_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_478_fu_26208_p1() {
    zext_ln415_478_fu_26208_p1 = esl_zext<8,1>(tmp_1457_fu_26200_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_479_fu_26316_p1() {
    zext_ln415_479_fu_26316_p1 = esl_zext<8,1>(tmp_1460_fu_26308_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_480_fu_26424_p1() {
    zext_ln415_480_fu_26424_p1 = esl_zext<8,1>(tmp_1463_fu_26416_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_481_fu_26532_p1() {
    zext_ln415_481_fu_26532_p1 = esl_zext<8,1>(tmp_1466_fu_26524_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_482_fu_26640_p1() {
    zext_ln415_482_fu_26640_p1 = esl_zext<8,1>(tmp_1469_fu_26632_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_483_fu_26748_p1() {
    zext_ln415_483_fu_26748_p1 = esl_zext<8,1>(tmp_1472_fu_26740_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_484_fu_26856_p1() {
    zext_ln415_484_fu_26856_p1 = esl_zext<8,1>(tmp_1475_fu_26848_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_485_fu_26964_p1() {
    zext_ln415_485_fu_26964_p1 = esl_zext<8,1>(tmp_1478_fu_26956_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_486_fu_27072_p1() {
    zext_ln415_486_fu_27072_p1 = esl_zext<8,1>(tmp_1481_fu_27064_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_487_fu_27180_p1() {
    zext_ln415_487_fu_27180_p1 = esl_zext<8,1>(tmp_1484_fu_27172_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_488_fu_27288_p1() {
    zext_ln415_488_fu_27288_p1 = esl_zext<8,1>(tmp_1487_fu_27280_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_489_fu_27396_p1() {
    zext_ln415_489_fu_27396_p1 = esl_zext<8,1>(tmp_1490_fu_27388_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_490_fu_27504_p1() {
    zext_ln415_490_fu_27504_p1 = esl_zext<8,1>(tmp_1493_fu_27496_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_491_fu_27612_p1() {
    zext_ln415_491_fu_27612_p1 = esl_zext<8,1>(tmp_1496_fu_27604_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_492_fu_27720_p1() {
    zext_ln415_492_fu_27720_p1 = esl_zext<8,1>(tmp_1499_fu_27712_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_493_fu_27828_p1() {
    zext_ln415_493_fu_27828_p1 = esl_zext<8,1>(tmp_1502_fu_27820_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_494_fu_27936_p1() {
    zext_ln415_494_fu_27936_p1 = esl_zext<8,1>(tmp_1505_fu_27928_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_495_fu_28044_p1() {
    zext_ln415_495_fu_28044_p1 = esl_zext<8,1>(tmp_1508_fu_28036_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_496_fu_28152_p1() {
    zext_ln415_496_fu_28152_p1 = esl_zext<8,1>(tmp_1511_fu_28144_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_497_fu_28260_p1() {
    zext_ln415_497_fu_28260_p1 = esl_zext<8,1>(tmp_1514_fu_28252_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_498_fu_28368_p1() {
    zext_ln415_498_fu_28368_p1 = esl_zext<8,1>(tmp_1517_fu_28360_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_499_fu_28476_p1() {
    zext_ln415_499_fu_28476_p1 = esl_zext<8,1>(tmp_1520_fu_28468_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_500_fu_28584_p1() {
    zext_ln415_500_fu_28584_p1 = esl_zext<8,1>(tmp_1523_fu_28576_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_501_fu_28692_p1() {
    zext_ln415_501_fu_28692_p1 = esl_zext<8,1>(tmp_1526_fu_28684_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_502_fu_28800_p1() {
    zext_ln415_502_fu_28800_p1 = esl_zext<8,1>(tmp_1529_fu_28792_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_503_fu_28908_p1() {
    zext_ln415_503_fu_28908_p1 = esl_zext<8,1>(tmp_1532_fu_28900_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_504_fu_29016_p1() {
    zext_ln415_504_fu_29016_p1 = esl_zext<8,1>(tmp_1535_fu_29008_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_505_fu_29124_p1() {
    zext_ln415_505_fu_29124_p1 = esl_zext<8,1>(tmp_1538_fu_29116_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_506_fu_29232_p1() {
    zext_ln415_506_fu_29232_p1 = esl_zext<8,1>(tmp_1541_fu_29224_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_507_fu_29340_p1() {
    zext_ln415_507_fu_29340_p1 = esl_zext<8,1>(tmp_1544_fu_29332_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_508_fu_29448_p1() {
    zext_ln415_508_fu_29448_p1 = esl_zext<8,1>(tmp_1547_fu_29440_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_509_fu_29556_p1() {
    zext_ln415_509_fu_29556_p1 = esl_zext<8,1>(tmp_1550_fu_29548_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_510_fu_29664_p1() {
    zext_ln415_510_fu_29664_p1 = esl_zext<8,1>(tmp_1553_fu_29656_p3.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_0_0_0_relu_config4_s::thread_zext_ln415_fu_2124_p1() {
    zext_ln415_fu_2124_p1 = esl_zext<8,1>(tmp_788_fu_2116_p3.read());
}

}

