#include "dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_pp0_stage0;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_done_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_continue.read())) {
            ap_done_reg = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
                    esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_done_reg = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0))) {
            ap_enable_reg_pp0_iter1 = ap_start.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_0_preg = ap_const_lv16_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_return_0_preg = add_ln703_1176_fu_103976_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_1_preg = ap_const_lv16_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_return_1_preg = acc_1_V_fu_104019_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_2_preg = ap_const_lv16_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_return_2_preg = acc_2_V_fu_104050_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_3_preg = ap_const_lv16_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_return_3_preg = acc_3_V_fu_104098_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_4_preg = ap_const_lv16_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
            ap_return_4_preg = acc_4_V_fu_104155_p2.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        add_ln703_1152_reg_104191 = add_ln703_1152_fu_102851_p2.read();
        add_ln703_1159_reg_104196 = add_ln703_1159_fu_102917_p2.read();
        add_ln703_1163_reg_104201 = add_ln703_1163_fu_102939_p2.read();
        add_ln703_1166_reg_104206 = add_ln703_1166_fu_102961_p2.read();
        add_ln703_1174_reg_104211 = add_ln703_1174_fu_103027_p2.read();
        add_ln703_1183_reg_104216 = add_ln703_1183_fu_103093_p2.read();
        add_ln703_1190_reg_104221 = add_ln703_1190_fu_103155_p2.read();
        add_ln703_1194_reg_104226 = add_ln703_1194_fu_103181_p2.read();
        add_ln703_1197_reg_104231 = add_ln703_1197_fu_103207_p2.read();
        add_ln703_1206_reg_104236 = add_ln703_1206_fu_103287_p2.read();
        add_ln703_1214_reg_104241 = add_ln703_1214_fu_103339_p2.read();
        add_ln703_1221_reg_104246 = add_ln703_1221_fu_103389_p2.read();
        add_ln703_1225_reg_104251 = add_ln703_1225_fu_103415_p2.read();
        add_ln703_1228_reg_104256 = add_ln703_1228_fu_103441_p2.read();
        add_ln703_1236_reg_104261 = add_ln703_1236_fu_103503_p2.read();
        add_ln703_1244_reg_104266 = add_ln703_1244_fu_103555_p2.read();
        add_ln703_1251_reg_104271 = add_ln703_1251_fu_103613_p2.read();
        add_ln703_1255_reg_104276 = add_ln703_1255_fu_103639_p2.read();
        add_ln703_1258_reg_104281 = add_ln703_1258_fu_103665_p2.read();
        add_ln703_1262_reg_104286 = add_ln703_1262_fu_103691_p2.read();
        add_ln703_1265_reg_104291 = add_ln703_1265_fu_103713_p2.read();
        add_ln703_1275_reg_104296 = add_ln703_1275_fu_103771_p2.read();
        add_ln703_1282_reg_104301 = add_ln703_1282_fu_103829_p2.read();
        add_ln703_1286_reg_104306 = add_ln703_1286_fu_103855_p2.read();
        add_ln703_1289_reg_104311 = add_ln703_1289_fu_103881_p2.read();
        add_ln703_1291_reg_104316 = add_ln703_1291_fu_103887_p2.read();
        add_ln703_1292_reg_104321 = add_ln703_1292_fu_103893_p2.read();
        add_ln703_1297_reg_104326 = add_ln703_1297_fu_103929_p2.read();
    }
}

void dense_latency_ap_ufixed_ap_fixed_16_6_5_3_0_config16_0_0_0_0_0_0::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            ap_NS_fsm = ap_ST_fsm_pp0_stage0;
break;
        default : 
            ap_NS_fsm = "X";
            break;
    }
}

}

