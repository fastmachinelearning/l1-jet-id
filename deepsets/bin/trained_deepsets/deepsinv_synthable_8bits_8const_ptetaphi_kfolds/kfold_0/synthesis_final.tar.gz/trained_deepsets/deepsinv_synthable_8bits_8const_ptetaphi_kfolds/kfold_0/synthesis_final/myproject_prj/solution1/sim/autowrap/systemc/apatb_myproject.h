// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_myproject (
ap_fixed<12, 4, (ap_q_mode) 0, (ap_o_mode)0, 0> input_layer[24],
ap_fixed<16, 6, (ap_q_mode) 5, (ap_o_mode)3, 0> layer18_out[5]);
