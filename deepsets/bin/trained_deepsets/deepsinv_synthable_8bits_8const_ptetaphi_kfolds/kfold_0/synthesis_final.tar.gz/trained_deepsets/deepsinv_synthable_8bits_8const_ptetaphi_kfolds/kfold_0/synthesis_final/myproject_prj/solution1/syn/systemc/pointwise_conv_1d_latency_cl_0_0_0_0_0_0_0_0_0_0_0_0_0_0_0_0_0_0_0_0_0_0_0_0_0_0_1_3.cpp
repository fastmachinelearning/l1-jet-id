#include "pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_0_V_fu_137843_p2() {
    acc_0_0_V_fu_137843_p2 = (!add_ln703_116_fu_137791_p2.read().is_01() || !sext_ln703_52_fu_137839_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_116_fu_137791_p2.read()) + sc_bigint<16>(sext_ln703_52_fu_137839_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_10_V_fu_138684_p2() {
    acc_0_10_V_fu_138684_p2 = (!add_ln703_435_fu_138632_p2.read().is_01() || !sext_ln703_268_fu_138680_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_435_fu_138632_p2.read()) + sc_bigint<16>(sext_ln703_268_fu_138680_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_11_V_fu_138781_p2() {
    acc_0_11_V_fu_138781_p2 = (!sext_ln703_284_fu_138731_p1.read().is_01() || !sext_ln703_287_fu_138777_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_284_fu_138731_p1.read()) + sc_bigint<16>(sext_ln703_287_fu_138777_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_12_V_fu_138864_p2() {
    acc_0_12_V_fu_138864_p2 = (!sext_ln703_303_fu_138821_p1.read().is_01() || !sext_ln703_306_fu_138860_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_303_fu_138821_p1.read()) + sc_bigint<16>(sext_ln703_306_fu_138860_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_13_V_fu_138970_p2() {
    acc_0_13_V_fu_138970_p2 = (!add_ln703_530_fu_138914_p2.read().is_01() || !sext_ln703_327_fu_138966_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_530_fu_138914_p2.read()) + sc_bigint<15>(sext_ln703_327_fu_138966_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_14_V_fu_139085_p2() {
    acc_0_14_V_fu_139085_p2 = (!add_ln703_561_fu_139024_p2.read().is_01() || !zext_ln703_74_fu_139081_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_561_fu_139024_p2.read()) + sc_biguint<16>(zext_ln703_74_fu_139081_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_15_V_fu_139200_p2() {
    acc_0_15_V_fu_139200_p2 = (!add_ln703_595_fu_139158_p2.read().is_01() || !sext_ln703_355_fu_139196_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_595_fu_139158_p2.read()) + sc_bigint<16>(sext_ln703_355_fu_139196_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_16_V_fu_139288_p2() {
    acc_0_16_V_fu_139288_p2 = (!add_ln703_625_fu_139229_p2.read().is_01() || !sext_ln703_371_fu_139284_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_625_fu_139229_p2.read()) + sc_bigint<16>(sext_ln703_371_fu_139284_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_17_V_fu_139374_p2() {
    acc_0_17_V_fu_139374_p2 = (!add_ln703_657_fu_139329_p2.read().is_01() || !sext_ln703_390_fu_139370_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_657_fu_139329_p2.read()) + sc_bigint<15>(sext_ln703_390_fu_139370_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_18_V_fu_139438_p2() {
    acc_0_18_V_fu_139438_p2 = (!sext_ln703_407_fu_139408_p1.read().is_01() || !sext_ln703_412_fu_139434_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_407_fu_139408_p1.read()) + sc_bigint<16>(sext_ln703_412_fu_139434_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_19_V_fu_139542_p2() {
    acc_0_19_V_fu_139542_p2 = (!add_ln703_721_fu_139497_p2.read().is_01() || !sext_ln703_427_fu_139538_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_721_fu_139497_p2.read()) + sc_bigint<15>(sext_ln703_427_fu_139538_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_1_V_fu_137887_p2() {
    acc_0_1_V_fu_137887_p2 = (!add_ln703_149_fu_137859_p2.read().is_01() || !sext_ln703_66_fu_137883_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_149_fu_137859_p2.read()) + sc_bigint<15>(sext_ln703_66_fu_137883_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_20_V_fu_139631_p2() {
    acc_0_20_V_fu_139631_p2 = (!add_ln703_754_fu_139589_p2.read().is_01() || !sext_ln703_441_fu_139627_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_754_fu_139589_p2.read()) + sc_bigint<15>(sext_ln703_441_fu_139627_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_21_V_fu_139738_p2() {
    acc_0_21_V_fu_139738_p2 = (!sext_ln203_127_fu_136811_p1.read().is_01() || !add_ln703_790_fu_139732_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_127_fu_136811_p1.read()) + sc_biguint<15>(add_ln703_790_fu_139732_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_22_V_fu_139865_p2() {
    acc_0_22_V_fu_139865_p2 = (!sext_ln703_463_fu_139825_p1.read().is_01() || !sext_ln703_469_fu_139861_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_463_fu_139825_p1.read()) + sc_bigint<16>(sext_ln703_469_fu_139861_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_23_V_fu_140054_p2() {
    acc_0_23_V_fu_140054_p2 = (!add_ln703_847_fu_139986_p2.read().is_01() || !sext_ln703_487_fu_140050_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_847_fu_139986_p2.read()) + sc_bigint<16>(sext_ln703_487_fu_140050_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_24_V_fu_140199_p2() {
    acc_0_24_V_fu_140199_p2 = (!add_ln703_879_fu_140150_p2.read().is_01() || !sext_ln703_511_fu_140195_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_879_fu_140150_p2.read()) + sc_bigint<16>(sext_ln703_511_fu_140195_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_25_V_fu_140344_p2() {
    acc_0_25_V_fu_140344_p2 = (!add_ln703_913_fu_140302_p2.read().is_01() || !sext_ln703_526_fu_140340_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_913_fu_140302_p2.read()) + sc_bigint<15>(sext_ln703_526_fu_140340_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_26_V_fu_140459_p2() {
    acc_0_26_V_fu_140459_p2 = (!sext_ln703_539_fu_140415_p1.read().is_01() || !sext_ln703_542_fu_140455_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_539_fu_140415_p1.read()) + sc_bigint<16>(sext_ln703_542_fu_140455_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_27_V_fu_140588_p2() {
    acc_0_27_V_fu_140588_p2 = (!add_ln703_976_fu_140540_p2.read().is_01() || !sext_ln703_560_fu_140584_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_976_fu_140540_p2.read()) + sc_bigint<16>(sext_ln703_560_fu_140584_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_28_V_fu_140689_p2() {
    acc_0_28_V_fu_140689_p2 = (!add_ln703_1011_fu_140663_p2.read().is_01() || !sext_ln703_573_fu_140685_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1011_fu_140663_p2.read()) + sc_bigint<15>(sext_ln703_573_fu_140685_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_29_V_fu_140807_p2() {
    acc_0_29_V_fu_140807_p2 = (!sext_ln703_584_fu_140770_p1.read().is_01() || !sext_ln703_587_fu_140803_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_584_fu_140770_p1.read()) + sc_bigint<16>(sext_ln703_587_fu_140803_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_2_V_fu_137925_p2() {
    acc_0_2_V_fu_137925_p2 = (!add_ln703_183_fu_137909_p2.read().is_01() || !sext_ln703_83_fu_137921_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_183_fu_137909_p2.read()) + sc_bigint<15>(sext_ln703_83_fu_137921_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_30_V_fu_140962_p2() {
    acc_0_30_V_fu_140962_p2 = (!add_ln703_1069_fu_140924_p2.read().is_01() || !sext_ln703_604_fu_140958_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_1069_fu_140924_p2.read()) + sc_bigint<16>(sext_ln703_604_fu_140958_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_31_V_fu_141095_p2() {
    acc_0_31_V_fu_141095_p2 = (!sext_ln703_620_fu_141058_p1.read().is_01() || !sext_ln703_624_fu_141091_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_620_fu_141058_p1.read()) + sc_bigint<15>(sext_ln703_624_fu_141091_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_3_V_fu_138034_p2() {
    acc_0_3_V_fu_138034_p2 = (!sext_ln703_97_fu_137981_p1.read().is_01() || !sext_ln703_101_fu_138030_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_97_fu_137981_p1.read()) + sc_bigint<16>(sext_ln703_101_fu_138030_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_4_V_fu_138145_p2() {
    acc_0_4_V_fu_138145_p2 = (!add_ln703_242_fu_138079_p2.read().is_01() || !sext_ln703_125_fu_138141_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_242_fu_138079_p2.read()) + sc_bigint<15>(sext_ln703_125_fu_138141_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_5_V_fu_138216_p2() {
    acc_0_5_V_fu_138216_p2 = (!sext_ln703_143_fu_138176_p1.read().is_01() || !sext_ln703_145_fu_138212_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_143_fu_138176_p1.read()) + sc_bigint<16>(sext_ln703_145_fu_138212_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_6_V_fu_138280_p2() {
    acc_0_6_V_fu_138280_p2 = (!sext_ln703_160_fu_138222_p1.read().is_01() || !zext_ln703_38_fu_138276_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_160_fu_138222_p1.read()) + sc_biguint<16>(zext_ln703_38_fu_138276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_7_V_fu_138355_p2() {
    acc_0_7_V_fu_138355_p2 = (!add_ln703_342_fu_138329_p2.read().is_01() || !sext_ln703_179_fu_138351_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_342_fu_138329_p2.read()) + sc_bigint<15>(sext_ln703_179_fu_138351_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_8_V_fu_138462_p2() {
    acc_0_8_V_fu_138462_p2 = (!add_ln703_371_fu_138413_p2.read().is_01() || !sext_ln703_219_fu_138458_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_371_fu_138413_p2.read()) + sc_bigint<16>(sext_ln703_219_fu_138458_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_acc_0_9_V_fu_138542_p2() {
    acc_0_9_V_fu_138542_p2 = (!sext_ln703_234_fu_138492_p1.read().is_01() || !sext_ln703_243_fu_138538_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_234_fu_138492_p1.read()) + sc_bigint<16>(sext_ln703_243_fu_138538_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_10_fu_135013_p2() {
    add_ln1118_10_fu_135013_p2 = (!zext_ln1118_76_reg_142980.read().is_01() || !zext_ln1118_159_reg_143910.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_76_reg_142980.read()) + sc_biguint<14>(zext_ln1118_159_reg_143910.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_11_fu_127466_p2() {
    add_ln1118_11_fu_127466_p2 = (!zext_ln1118_197_fu_127452_p1.read().is_01() || !zext_ln1118_198_fu_127462_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_197_fu_127452_p1.read()) + sc_biguint<12>(zext_ln1118_198_fu_127462_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_12_fu_120335_p2() {
    add_ln1118_12_fu_120335_p2 = (!zext_ln1118_166_reg_142350.read().is_01() || !zext_ln1118_206_fu_120331_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_166_reg_142350.read()) + sc_biguint<14>(zext_ln1118_206_fu_120331_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_13_fu_120539_p2() {
    add_ln1118_13_fu_120539_p2 = (!zext_ln1118_25_reg_141864.read().is_01() || !zext_ln1118_226_fu_120535_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_25_reg_141864.read()) + sc_biguint<14>(zext_ln1118_226_fu_120535_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_14_fu_135334_p2() {
    add_ln1118_14_fu_135334_p2 = (!zext_ln1118_234_fu_135330_p1.read().is_01() || !zext_ln1118_233_fu_135326_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_234_fu_135330_p1.read()) + sc_biguint<13>(zext_ln1118_233_fu_135326_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_15_fu_127847_p2() {
    add_ln1118_15_fu_127847_p2 = (!zext_ln1118_236_fu_127843_p1.read().is_01() || !zext_ln1118_235_fu_127839_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_236_fu_127843_p1.read()) + sc_biguint<14>(zext_ln1118_235_fu_127839_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_16_fu_127905_p2() {
    add_ln1118_16_fu_127905_p2 = (!zext_ln1118_178_reg_143066.read().is_01() || !zext_ln1118_250_fu_127901_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_178_reg_143066.read()) + sc_biguint<14>(zext_ln1118_250_fu_127901_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_17_fu_120815_p2() {
    add_ln1118_17_fu_120815_p2 = (!zext_ln1118_254_fu_120811_p1.read().is_01() || !zext_ln1118_253_fu_120800_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_254_fu_120811_p1.read()) + sc_biguint<13>(zext_ln1118_253_fu_120800_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_18_fu_120898_p2() {
    add_ln1118_18_fu_120898_p2 = (!zext_ln1118_162_reg_142337.read().is_01() || !zext_ln1118_164_fu_120037_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_162_reg_142337.read()) + sc_biguint<14>(zext_ln1118_164_fu_120037_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_19_fu_128067_p2() {
    add_ln1118_19_fu_128067_p2 = (!zext_ln1118_274_fu_127970_p1.read().is_01() || !zext_ln1118_182_fu_127315_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_274_fu_127970_p1.read()) + sc_biguint<14>(zext_ln1118_182_fu_127315_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_20_fu_128218_p2() {
    add_ln1118_20_fu_128218_p2 = (!zext_ln1118_172_reg_142361.read().is_01() || !zext_ln1118_319_fu_128214_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_172_reg_142361.read()) + sc_biguint<14>(zext_ln1118_319_fu_128214_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_21_fu_128312_p2() {
    add_ln1118_21_fu_128312_p2 = (!zext_ln1118_325_fu_128309_p1.read().is_01() || !zext_ln1118_324_fu_128305_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_325_fu_128309_p1.read()) + sc_biguint<14>(zext_ln1118_324_fu_128305_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_22_fu_128405_p2() {
    add_ln1118_22_fu_128405_p2 = (!zext_ln1118_336_fu_128401_p1.read().is_01() || !zext_ln1118_335_fu_128390_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_336_fu_128401_p1.read()) + sc_biguint<14>(zext_ln1118_335_fu_128390_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_23_fu_136320_p2() {
    add_ln1118_23_fu_136320_p2 = (!zext_ln1118_194_fu_135147_p1.read().is_01() || !zext_ln1118_193_fu_135144_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_194_fu_135147_p1.read()) + sc_biguint<12>(zext_ln1118_193_fu_135144_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_24_fu_136496_p2() {
    add_ln1118_24_fu_136496_p2 = (!zext_ln1118_187_fu_135091_p1.read().is_01() || !zext_ln1118_186_fu_135087_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_187_fu_135091_p1.read()) + sc_biguint<14>(zext_ln1118_186_fu_135087_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_25_fu_128978_p2() {
    add_ln1118_25_fu_128978_p2 = (!zext_ln1118_58_reg_142063.read().is_01() || !zext_ln1118_290_fu_128093_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_58_reg_142063.read()) + sc_biguint<12>(zext_ln1118_290_fu_128093_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_26_fu_136608_p2() {
    add_ln1118_26_fu_136608_p2 = (!zext_ln1118_400_fu_136605_p1.read().is_01() || !zext_ln1118_218_fu_135285_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_400_fu_136605_p1.read()) + sc_biguint<13>(zext_ln1118_218_fu_135285_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_27_fu_123039_p2() {
    add_ln1118_27_fu_123039_p2 = (!zext_ln1118_380_fu_122467_p1.read().is_01() || !zext_ln1118_411_fu_123035_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_380_fu_122467_p1.read()) + sc_biguint<12>(zext_ln1118_411_fu_123035_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_28_fu_123090_p2() {
    add_ln1118_28_fu_123090_p2 = (!zext_ln1118_263_fu_120852_p1.read().is_01() || !zext_ln1118_403_fu_122921_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_263_fu_120852_p1.read()) + sc_biguint<12>(zext_ln1118_403_fu_122921_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_29_fu_129424_p2() {
    add_ln1118_29_fu_129424_p2 = (!zext_ln1118_434_fu_129420_p1.read().is_01() || !zext_ln1118_290_fu_128093_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_434_fu_129420_p1.read()) + sc_biguint<12>(zext_ln1118_290_fu_128093_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_30_fu_136738_p2() {
    add_ln1118_30_fu_136738_p2 = (!zext_ln1118_191_fu_135141_p1.read().is_01() || !zext_ln1118_193_fu_135144_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_191_fu_135141_p1.read()) + sc_biguint<12>(zext_ln1118_193_fu_135144_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_31_fu_129536_p2() {
    add_ln1118_31_fu_129536_p2 = (!zext_ln1118_52_reg_142049.read().is_01() || !zext_ln1118_348_fu_128597_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_52_reg_142049.read()) + sc_biguint<14>(zext_ln1118_348_fu_128597_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_32_fu_129562_p2() {
    add_ln1118_32_fu_129562_p2 = (!zext_ln1118_443_fu_129558_p1.read().is_01() || !zext_ln1118_409_fu_129125_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_443_fu_129558_p1.read()) + sc_biguint<13>(zext_ln1118_409_fu_129125_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_33_fu_123655_p2() {
    add_ln1118_33_fu_123655_p2 = (!zext_ln1118_5_fu_119100_p1.read().is_01() || !zext_ln1118_329_fu_121633_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_5_fu_119100_p1.read()) + sc_biguint<12>(zext_ln1118_329_fu_121633_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_34_fu_118838_p2() {
    add_ln1118_34_fu_118838_p2 = (!zext_ln1118_424_fu_118788_p1.read().is_01() || !zext_ln1118_261_fu_118503_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_424_fu_118788_p1.read()) + sc_biguint<14>(zext_ln1118_261_fu_118503_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_35_fu_137313_p2() {
    add_ln1118_35_fu_137313_p2 = (!zext_ln1118_482_fu_137309_p1.read().is_01() || !zext_ln1118_312_fu_135857_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_482_fu_137309_p1.read()) + sc_biguint<12>(zext_ln1118_312_fu_135857_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_36_fu_123927_p2() {
    add_ln1118_36_fu_123927_p2 = (!zext_ln1118_163_fu_120027_p1.read().is_01() || !zext_ln1118_495_fu_123923_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_163_fu_120027_p1.read()) + sc_biguint<13>(zext_ln1118_495_fu_123923_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_37_fu_123943_p2() {
    add_ln1118_37_fu_123943_p2 = (!zext_ln1118_27_fu_119243_p1.read().is_01() || !zext_ln1118_356_fu_122108_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_27_fu_119243_p1.read()) + sc_biguint<12>(zext_ln1118_356_fu_122108_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_38_fu_124001_p2() {
    add_ln1118_38_fu_124001_p2 = (!zext_ln1118_37_fu_119285_p1.read().is_01() || !zext_ln1118_272_fu_120948_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_37_fu_119285_p1.read()) + sc_biguint<12>(zext_ln1118_272_fu_120948_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_39_fu_131236_p2() {
    add_ln1118_39_fu_131236_p2 = (!zext_ln1118_523_fu_131232_p1.read().is_01() || !zext_ln1118_451_fu_129795_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_523_fu_131232_p1.read()) + sc_biguint<14>(zext_ln1118_451_fu_129795_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_40_fu_124105_p2() {
    add_ln1118_40_fu_124105_p2 = (!zext_ln1118_426_fu_123376_p1.read().is_01() || !zext_ln1118_356_fu_122108_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_426_fu_123376_p1.read()) + sc_biguint<12>(zext_ln1118_356_fu_122108_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_6_fu_126828_p2() {
    add_ln1118_6_fu_126828_p2 = (!zext_ln1118_125_fu_126824_p1.read().is_01() || !zext_ln1118_124_reg_143020.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_125_fu_126824_p1.read()) + sc_biguint<14>(zext_ln1118_124_reg_143020.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_7_fu_126910_p2() {
    add_ln1118_7_fu_126910_p2 = (!zext_ln1118_131_fu_126906_p1.read().is_01() || !zext_ln1118_130_fu_126895_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_131_fu_126906_p1.read()) + sc_biguint<12>(zext_ln1118_130_fu_126895_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_8_fu_119864_p2() {
    add_ln1118_8_fu_119864_p2 = (!zext_ln1118_144_fu_119860_p1.read().is_01() || !zext_ln1118_143_fu_119849_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_144_fu_119860_p1.read()) + sc_biguint<13>(zext_ln1118_143_fu_119849_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_9_fu_126998_p2() {
    add_ln1118_9_fu_126998_p2 = (!zext_ln1118_152_fu_126994_p1.read().is_01() || !zext_ln1118_151_fu_126990_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_152_fu_126994_p1.read()) + sc_biguint<13>(zext_ln1118_151_fu_126990_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln1118_fu_119439_p2() {
    add_ln1118_fu_119439_p2 = (!zext_ln1118_90_fu_119435_p1.read().is_01() || !zext_ln1118_89_fu_119424_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_90_fu_119435_p1.read()) + sc_biguint<13>(zext_ln1118_89_fu_119424_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1000_fu_134090_p2() {
    add_ln703_1000_fu_134090_p2 = (!zext_ln1118_505_fu_130803_p1.read().is_01() || !zext_ln1118_504_fu_130799_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_505_fu_130803_p1.read()) + sc_biguint<10>(zext_ln1118_504_fu_130799_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1001_fu_134100_p2() {
    add_ln703_1001_fu_134100_p2 = (!zext_ln703_130_fu_134086_p1.read().is_01() || !zext_ln703_131_fu_134096_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_130_fu_134086_p1.read()) + sc_biguint<11>(zext_ln703_131_fu_134096_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1002_fu_140648_p2() {
    add_ln703_1002_fu_140648_p2 = (!sext_ln703_568_fu_140641_p1.read().is_01() || !zext_ln703_132_fu_140645_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_568_fu_140641_p1.read()) + sc_biguint<15>(zext_ln703_132_fu_140645_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1003_fu_134106_p2() {
    add_ln703_1003_fu_134106_p2 = (!zext_ln1118_506_fu_130815_p1.read().is_01() || !zext_ln1116_49_fu_130807_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_506_fu_130815_p1.read()) + sc_biguint<9>(zext_ln1116_49_fu_130807_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1004_fu_134116_p2() {
    add_ln703_1004_fu_134116_p2 = (!zext_ln1118_508_fu_130823_p1.read().is_01() || !zext_ln1118_507_fu_130819_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_508_fu_130823_p1.read()) + sc_biguint<10>(zext_ln1118_507_fu_130819_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1005_fu_134126_p2() {
    add_ln703_1005_fu_134126_p2 = (!zext_ln703_133_fu_134112_p1.read().is_01() || !zext_ln703_134_fu_134122_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_133_fu_134112_p1.read()) + sc_biguint<11>(zext_ln703_134_fu_134122_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1006_fu_134136_p2() {
    add_ln703_1006_fu_134136_p2 = (!sext_ln1116_40_fu_130791_p1.read().is_01() || !sext_ln1116_39_fu_130787_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_40_fu_130791_p1.read()) + sc_bigint<11>(sext_ln1116_39_fu_130787_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1007_fu_134146_p2() {
    add_ln703_1007_fu_134146_p2 = (!sext_ln1118_318_fu_130811_p1.read().is_01() || !sext_ln1118_317_fu_130795_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_318_fu_130811_p1.read()) + sc_bigint<10>(sext_ln1118_317_fu_130795_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1008_fu_134156_p2() {
    add_ln703_1008_fu_134156_p2 = (!sext_ln703_569_fu_134142_p1.read().is_01() || !sext_ln703_570_fu_134152_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_569_fu_134142_p1.read()) + sc_bigint<12>(sext_ln703_570_fu_134152_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1009_fu_134166_p2() {
    add_ln703_1009_fu_134166_p2 = (!zext_ln703_135_fu_134132_p1.read().is_01() || !sext_ln703_571_fu_134162_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_135_fu_134132_p1.read()) + sc_bigint<13>(sext_ln703_571_fu_134162_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_100_fu_124207_p2() {
    add_ln703_100_fu_124207_p2 = (!sext_ln1118_fu_119278_p1.read().is_01() || !sext_ln1116_6_fu_119274_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_fu_119278_p1.read()) + sc_bigint<12>(sext_ln1116_6_fu_119274_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1010_fu_140657_p2() {
    add_ln703_1010_fu_140657_p2 = (!add_ln703_1002_fu_140648_p2.read().is_01() || !sext_ln703_572_fu_140654_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1002_fu_140648_p2.read()) + sc_bigint<15>(sext_ln703_572_fu_140654_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1011_fu_140663_p2() {
    add_ln703_1011_fu_140663_p2 = (!zext_ln203_76_fu_137541_p1.read().is_01() || !add_ln703_1010_fu_140657_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_76_fu_137541_p1.read()) + sc_biguint<15>(add_ln703_1010_fu_140657_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1012_fu_140669_p2() {
    add_ln703_1012_fu_140669_p2 = (!zext_ln708_205_fu_137583_p1.read().is_01() || !zext_ln708_203_fu_137555_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_205_fu_137583_p1.read()) + sc_biguint<11>(zext_ln708_203_fu_137555_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1013_fu_140679_p2() {
    add_ln703_1013_fu_140679_p2 = (!sext_ln203_176_fu_137559_p1.read().is_01() || !zext_ln703_136_fu_140675_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_176_fu_137559_p1.read()) + sc_biguint<13>(zext_ln703_136_fu_140675_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1015_fu_134172_p2() {
    add_ln703_1015_fu_134172_p2 = (!sext_ln203_177_fu_130837_p1.read().is_01() || !ap_const_lv12_C00.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_177_fu_130837_p1.read()) + sc_bigint<12>(ap_const_lv12_C00));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1016_fu_134182_p2() {
    add_ln703_1016_fu_134182_p2 = (!sext_ln203_178_fu_130841_p1.read().is_01() || !sext_ln703_266_fu_134178_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_178_fu_130841_p1.read()) + sc_bigint<13>(sext_ln703_266_fu_134178_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1017_fu_134188_p2() {
    add_ln703_1017_fu_134188_p2 = (!sext_ln708_91_fu_130845_p1.read().is_01() || !zext_ln1118_509_fu_130849_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_91_fu_130845_p1.read()) + sc_biguint<12>(zext_ln1118_509_fu_130849_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1018_fu_134198_p2() {
    add_ln703_1018_fu_134198_p2 = (!add_ln703_1016_fu_134182_p2.read().is_01() || !sext_ln703_575_fu_134194_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_1016_fu_134182_p2.read()) + sc_bigint<13>(sext_ln703_575_fu_134194_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1019_fu_134208_p2() {
    add_ln703_1019_fu_134208_p2 = (!sext_ln1118_91_reg_143033.read().is_01() || !sext_ln708_92_fu_130853_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_91_reg_143033.read()) + sc_bigint<12>(sext_ln708_92_fu_130853_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_101_fu_124217_p2() {
    add_ln703_101_fu_124217_p2 = (!sext_ln703_40_fu_124203_p1.read().is_01() || !sext_ln703_41_fu_124213_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_40_fu_124203_p1.read()) + sc_bigint<15>(sext_ln703_41_fu_124213_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1020_fu_134217_p2() {
    add_ln703_1020_fu_134217_p2 = (!sext_ln703_267_fu_134204_p1.read().is_01() || !sext_ln703_576_fu_134213_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_267_fu_134204_p1.read()) + sc_bigint<14>(sext_ln703_576_fu_134213_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1021_fu_134223_p2() {
    add_ln703_1021_fu_134223_p2 = (!sext_ln1118_320_fu_130861_p1.read().is_01() || !zext_ln708_206_fu_130857_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_320_fu_130861_p1.read()) + sc_biguint<11>(zext_ln708_206_fu_130857_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1022_fu_134233_p2() {
    add_ln703_1022_fu_134233_p2 = (!sext_ln708_93_fu_130864_p1.read().is_01() || !sext_ln703_577_fu_134229_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_93_fu_130864_p1.read()) + sc_bigint<12>(sext_ln703_577_fu_134229_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1023_fu_140702_p2() {
    add_ln703_1023_fu_140702_p2 = (!add_ln703_1020_reg_144533.read().is_01() || !sext_ln703_578_fu_140699_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1020_reg_144533.read()) + sc_bigint<14>(sext_ln703_578_fu_140699_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1024_fu_134239_p2() {
    add_ln703_1024_fu_134239_p2 = (!zext_ln708_208_fu_130871_p1.read().is_01() || !zext_ln708_207_fu_130867_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_208_fu_130871_p1.read()) + sc_biguint<11>(zext_ln708_207_fu_130867_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1025_fu_140710_p2() {
    add_ln703_1025_fu_140710_p2 = (!add_ln703_1023_fu_140702_p2.read().is_01() || !zext_ln703_137_fu_140707_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1023_fu_140702_p2.read()) + sc_biguint<14>(zext_ln703_137_fu_140707_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1026_fu_134245_p2() {
    add_ln703_1026_fu_134245_p2 = (!zext_ln1118_511_fu_130906_p1.read().is_01() || !grp_fu_117354_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_511_fu_130906_p1.read()) + sc_biguint<10>(grp_fu_117354_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1027_fu_134255_p2() {
    add_ln703_1027_fu_134255_p2 = (!zext_ln1118_513_fu_130967_p1.read().is_01() || !zext_ln1118_127_fu_126847_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_513_fu_130967_p1.read()) + sc_biguint<10>(zext_ln1118_127_fu_126847_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1028_fu_134265_p2() {
    add_ln703_1028_fu_134265_p2 = (!zext_ln703_138_fu_134251_p1.read().is_01() || !zext_ln703_139_fu_134261_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_138_fu_134251_p1.read()) + sc_biguint<11>(zext_ln703_139_fu_134261_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1029_fu_140723_p2() {
    add_ln703_1029_fu_140723_p2 = (!sext_ln703_579_fu_140716_p1.read().is_01() || !zext_ln703_140_fu_140720_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_579_fu_140716_p1.read()) + sc_biguint<15>(zext_ln703_140_fu_140720_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_102_fu_124223_p2() {
    add_ln703_102_fu_124223_p2 = (!zext_ln1116_18_fu_119319_p1.read().is_01() || !sext_ln1116_8_fu_119315_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_18_fu_119319_p1.read()) + sc_bigint<12>(sext_ln1116_8_fu_119315_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1030_fu_134271_p2() {
    add_ln703_1030_fu_134271_p2 = (!zext_ln708_210_fu_131006_p1.read().is_01() || !trunc_ln708_1303_fu_130996_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_210_fu_131006_p1.read()) + sc_biguint<10>(trunc_ln708_1303_fu_130996_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1031_fu_134277_p2() {
    add_ln703_1031_fu_134277_p2 = (!zext_ln708_209_fu_130987_p1.read().is_01() || !add_ln703_1030_fu_134271_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_209_fu_130987_p1.read()) + sc_biguint<10>(add_ln703_1030_fu_134271_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1032_fu_134287_p2() {
    add_ln703_1032_fu_134287_p2 = (!sext_ln708_66_fu_128464_p1.read().is_01() || !sext_ln1118_323_fu_130944_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_66_fu_128464_p1.read()) + sc_bigint<10>(sext_ln1118_323_fu_130944_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1033_fu_134293_p2() {
    add_ln703_1033_fu_134293_p2 = (!sext_ln1118_322_fu_130925_p1.read().is_01() || !sext_ln1118_321_fu_130902_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_322_fu_130925_p1.read()) + sc_bigint<8>(sext_ln1118_321_fu_130902_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1034_fu_134303_p2() {
    add_ln703_1034_fu_134303_p2 = (!add_ln703_1032_fu_134287_p2.read().is_01() || !sext_ln703_580_fu_134299_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(add_ln703_1032_fu_134287_p2.read()) + sc_bigint<10>(sext_ln703_580_fu_134299_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1035_fu_134313_p2() {
    add_ln703_1035_fu_134313_p2 = (!zext_ln703_141_fu_134283_p1.read().is_01() || !sext_ln703_581_fu_134309_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_141_fu_134283_p1.read()) + sc_bigint<12>(sext_ln703_581_fu_134309_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1036_fu_140732_p2() {
    add_ln703_1036_fu_140732_p2 = (!add_ln703_1029_fu_140723_p2.read().is_01() || !sext_ln703_582_fu_140729_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1029_fu_140723_p2.read()) + sc_bigint<15>(sext_ln703_582_fu_140729_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1037_fu_140738_p2() {
    add_ln703_1037_fu_140738_p2 = (!zext_ln203_77_fu_137587_p1.read().is_01() || !add_ln703_1036_fu_140732_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_77_fu_137587_p1.read()) + sc_biguint<15>(add_ln703_1036_fu_140732_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1038_fu_140744_p2() {
    add_ln703_1038_fu_140744_p2 = (!zext_ln708_211_fu_137606_p1.read().is_01() || !zext_ln708_192_fu_137301_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_211_fu_137606_p1.read()) + sc_biguint<11>(zext_ln708_192_fu_137301_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1039_fu_140754_p2() {
    add_ln703_1039_fu_140754_p2 = (!sext_ln203_181_fu_137614_p1.read().is_01() || !zext_ln703_142_fu_140750_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_181_fu_137614_p1.read()) + sc_biguint<13>(zext_ln703_142_fu_140750_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_103_fu_131476_p2() {
    add_ln703_103_fu_131476_p2 = (!sext_ln1116_7_fu_126464_p1.read().is_01() || !sext_ln703_42_fu_131473_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_7_fu_126464_p1.read()) + sc_bigint<13>(sext_ln703_42_fu_131473_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1040_fu_140764_p2() {
    add_ln703_1040_fu_140764_p2 = (!add_ln703_1037_fu_140738_p2.read().is_01() || !sext_ln703_583_fu_140760_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1037_fu_140738_p2.read()) + sc_bigint<15>(sext_ln703_583_fu_140760_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1041_fu_140774_p2() {
    add_ln703_1041_fu_140774_p2 = (!zext_ln708_212_fu_137610_p1.read().is_01() || !zext_ln708_64_fu_135418_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_212_fu_137610_p1.read()) + sc_biguint<11>(zext_ln708_64_fu_135418_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1042_fu_134319_p2() {
    add_ln703_1042_fu_134319_p2 = (!sext_ln203_180_fu_131044_p1.read().is_01() || !sext_ln203_179_fu_131010_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_180_fu_131044_p1.read()) + sc_bigint<11>(sext_ln203_179_fu_131010_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1043_fu_140787_p2() {
    add_ln703_1043_fu_140787_p2 = (!zext_ln203_78_fu_137617_p1.read().is_01() || !sext_ln703_585_fu_140784_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_78_fu_137617_p1.read()) + sc_bigint<12>(sext_ln703_585_fu_140784_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1044_fu_140797_p2() {
    add_ln703_1044_fu_140797_p2 = (!zext_ln703_143_fu_140780_p1.read().is_01() || !sext_ln703_586_fu_140793_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_143_fu_140780_p1.read()) + sc_bigint<13>(sext_ln703_586_fu_140793_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1046_fu_134325_p2() {
    add_ln703_1046_fu_134325_p2 = (!grp_fu_117144_p4.read().is_01() || !ap_const_lv10_58.is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117144_p4.read()) + sc_biguint<10>(ap_const_lv10_58));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1047_fu_134335_p2() {
    add_ln703_1047_fu_134335_p2 = (!zext_ln703_4_fu_134331_p1.read().is_01() || !sext_ln203_182_fu_131068_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_4_fu_134331_p1.read()) + sc_bigint<12>(sext_ln203_182_fu_131068_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1048_fu_134345_p2() {
    add_ln703_1048_fu_134345_p2 = (!sext_ln708_94_fu_131072_p1.read().is_01() || !zext_ln1118_516_fu_131075_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_94_fu_131072_p1.read()) + sc_biguint<12>(zext_ln1118_516_fu_131075_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1049_fu_134355_p2() {
    add_ln703_1049_fu_134355_p2 = (!sext_ln703_270_fu_134341_p1.read().is_01() || !sext_ln703_588_fu_134351_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_270_fu_134341_p1.read()) + sc_bigint<13>(sext_ln703_588_fu_134351_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_104_fu_131486_p2() {
    add_ln703_104_fu_131486_p2 = (!add_ln703_101_reg_143476.read().is_01() || !sext_ln703_43_fu_131482_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_101_reg_143476.read()) + sc_bigint<15>(sext_ln703_43_fu_131482_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1050_fu_140816_p2() {
    add_ln703_1050_fu_140816_p2 = (!sext_ln203_183_fu_137621_p1.read().is_01() || !sext_ln703_271_fu_140813_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_183_fu_137621_p1.read()) + sc_bigint<14>(sext_ln703_271_fu_140813_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1051_fu_126342_p2() {
    add_ln703_1051_fu_126342_p2 = (!sext_ln1118_91_fu_119943_p1.read().is_01() || !sext_ln1118_326_fu_124036_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_91_fu_119943_p1.read()) + sc_bigint<12>(sext_ln1118_326_fu_124036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1052_fu_126352_p2() {
    add_ln703_1052_fu_126352_p2 = (!sext_ln1118_325_fu_124017_p1.read().is_01() || !sext_ln703_589_fu_126348_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_325_fu_124017_p1.read()) + sc_bigint<13>(sext_ln703_589_fu_126348_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1053_fu_140825_p2() {
    add_ln703_1053_fu_140825_p2 = (!add_ln703_1050_fu_140816_p2.read().is_01() || !sext_ln703_590_fu_140822_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1050_fu_140816_p2.read()) + sc_bigint<14>(sext_ln703_590_fu_140822_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1054_fu_140835_p2() {
    add_ln703_1054_fu_140835_p2 = (!sext_ln203_184_fu_137625_p1.read().is_01() || !sext_ln703_272_fu_140831_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_184_fu_137625_p1.read()) + sc_bigint<15>(sext_ln703_272_fu_140831_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1055_fu_134361_p2() {
    add_ln703_1055_fu_134361_p2 = (!sext_ln1118_330_fu_131101_p1.read().is_01() || !sext_ln1118_329_fu_131097_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_330_fu_131101_p1.read()) + sc_bigint<12>(sext_ln1118_329_fu_131097_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1056_fu_140844_p2() {
    add_ln703_1056_fu_140844_p2 = (!sext_ln1118_328_fu_137628_p1.read().is_01() || !sext_ln703_591_fu_140841_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_328_fu_137628_p1.read()) + sc_bigint<13>(sext_ln703_591_fu_140841_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1057_fu_140854_p2() {
    add_ln703_1057_fu_140854_p2 = (!add_ln703_1054_fu_140835_p2.read().is_01() || !sext_ln703_592_fu_140850_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1054_fu_140835_p2.read()) + sc_bigint<15>(sext_ln703_592_fu_140850_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1058_fu_134367_p2() {
    add_ln703_1058_fu_134367_p2 = (!zext_ln1118_520_fu_131190_p1.read().is_01() || !zext_ln1118_519_fu_131186_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_520_fu_131190_p1.read()) + sc_biguint<10>(zext_ln1118_519_fu_131186_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1059_fu_134377_p2() {
    add_ln703_1059_fu_134377_p2 = (!sext_ln1118_333_fu_131166_p1.read().is_01() || !sext_ln1118_327_fu_131093_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_333_fu_131166_p1.read()) + sc_bigint<10>(sext_ln1118_327_fu_131093_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_105_fu_131491_p2() {
    add_ln703_105_fu_131491_p2 = (!zext_ln708_9_fu_126505_p1.read().is_01() || !zext_ln708_7_fu_126474_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_9_fu_126505_p1.read()) + sc_biguint<11>(zext_ln708_7_fu_126474_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1060_fu_134387_p2() {
    add_ln703_1060_fu_134387_p2 = (!sext_ln1118_332_fu_131131_p1.read().is_01() || !sext_ln703_593_fu_134383_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_332_fu_131131_p1.read()) + sc_bigint<11>(sext_ln703_593_fu_134383_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1061_fu_134397_p2() {
    add_ln703_1061_fu_134397_p2 = (!zext_ln703_144_fu_134373_p1.read().is_01() || !sext_ln703_594_fu_134393_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_144_fu_134373_p1.read()) + sc_bigint<12>(sext_ln703_594_fu_134393_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1062_fu_140863_p2() {
    add_ln703_1062_fu_140863_p2 = (!add_ln703_1057_fu_140854_p2.read().is_01() || !sext_ln703_595_fu_140860_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1057_fu_140854_p2.read()) + sc_bigint<15>(sext_ln703_595_fu_140860_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1063_fu_140869_p2() {
    add_ln703_1063_fu_140869_p2 = (!sext_ln203_186_fu_137635_p1.read().is_01() || !add_ln703_1062_fu_140863_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_186_fu_137635_p1.read()) + sc_biguint<15>(add_ln703_1062_fu_140863_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1064_fu_140875_p2() {
    add_ln703_1064_fu_140875_p2 = (!sext_ln1118_152_reg_143978.read().is_01() || !sext_ln203_187_fu_137649_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_152_reg_143978.read()) + sc_bigint<12>(sext_ln203_187_fu_137649_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1065_fu_140884_p2() {
    add_ln703_1065_fu_140884_p2 = (!add_ln703_1063_fu_140869_p2.read().is_01() || !sext_ln703_596_fu_140880_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1063_fu_140869_p2.read()) + sc_bigint<15>(sext_ln703_596_fu_140880_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1066_fu_140894_p2() {
    add_ln703_1066_fu_140894_p2 = (!sext_ln203_189_fu_137684_p1.read().is_01() || !sext_ln203_188_fu_137653_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_189_fu_137684_p1.read()) + sc_bigint<12>(sext_ln203_188_fu_137653_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1067_fu_140904_p2() {
    add_ln703_1067_fu_140904_p2 = (!sext_ln203_191_fu_137702_p1.read().is_01() || !sext_ln203_190_fu_137688_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_191_fu_137702_p1.read()) + sc_bigint<12>(sext_ln203_190_fu_137688_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1068_fu_140914_p2() {
    add_ln703_1068_fu_140914_p2 = (!sext_ln703_598_fu_140900_p1.read().is_01() || !sext_ln703_599_fu_140910_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_598_fu_140900_p1.read()) + sc_bigint<13>(sext_ln703_599_fu_140910_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1069_fu_140924_p2() {
    add_ln703_1069_fu_140924_p2 = (!sext_ln703_597_fu_140890_p1.read().is_01() || !sext_ln703_600_fu_140920_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_597_fu_140890_p1.read()) + sc_bigint<16>(sext_ln703_600_fu_140920_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_106_fu_131501_p2() {
    add_ln703_106_fu_131501_p2 = (!zext_ln1118_43_fu_126471_p1.read().is_01() || !zext_ln703_3_fu_131497_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_43_fu_126471_p1.read()) + sc_biguint<12>(zext_ln703_3_fu_131497_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1070_fu_134403_p2() {
    add_ln703_1070_fu_134403_p2 = (!sext_ln203_193_fu_131264_p1.read().is_01() || !sext_ln203_192_fu_131256_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_193_fu_131264_p1.read()) + sc_bigint<12>(sext_ln203_192_fu_131256_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1071_fu_134413_p2() {
    add_ln703_1071_fu_134413_p2 = (!zext_ln708_214_fu_131228_p1.read().is_01() || !zext_ln708_213_fu_131214_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_214_fu_131228_p1.read()) + sc_biguint<11>(zext_ln708_213_fu_131214_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1072_fu_134423_p2() {
    add_ln703_1072_fu_134423_p2 = (!sext_ln703_601_fu_134409_p1.read().is_01() || !zext_ln703_145_fu_134419_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_601_fu_134409_p1.read()) + sc_biguint<13>(zext_ln703_145_fu_134419_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1073_fu_134429_p2() {
    add_ln703_1073_fu_134429_p2 = (!zext_ln203_80_fu_131260_p1.read().is_01() || !zext_ln203_79_fu_131252_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_80_fu_131260_p1.read()) + sc_biguint<10>(zext_ln203_79_fu_131252_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1074_fu_140936_p2() {
    add_ln703_1074_fu_140936_p2 = (!sext_ln203_185_fu_137632_p1.read().is_01() || !zext_ln203_81_fu_137706_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_185_fu_137632_p1.read()) + sc_biguint<12>(zext_ln203_81_fu_137706_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1075_fu_140942_p2() {
    add_ln703_1075_fu_140942_p2 = (!zext_ln703_146_fu_140933_p1.read().is_01() || !add_ln703_1074_fu_140936_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_146_fu_140933_p1.read()) + sc_biguint<12>(add_ln703_1074_fu_140936_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1076_fu_140952_p2() {
    add_ln703_1076_fu_140952_p2 = (!sext_ln703_602_fu_140930_p1.read().is_01() || !sext_ln703_603_fu_140948_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_602_fu_140930_p1.read()) + sc_bigint<14>(sext_ln703_603_fu_140948_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1078_fu_134435_p2() {
    add_ln703_1078_fu_134435_p2 = (!grp_fu_116494_p4.read().is_01() || !ap_const_lv8_A8.is_01())? sc_lv<8>(): (sc_biguint<8>(grp_fu_116494_p4.read()) + sc_bigint<8>(ap_const_lv8_A8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1079_fu_134445_p2() {
    add_ln703_1079_fu_134445_p2 = (!sext_ln703_605_fu_134441_p1.read().is_01() || !sext_ln1118_334_fu_131268_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_605_fu_134441_p1.read()) + sc_bigint<11>(sext_ln1118_334_fu_131268_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_107_fu_131511_p2() {
    add_ln703_107_fu_131511_p2 = (!sext_ln1116_5_fu_126372_p1.read().is_01() || !zext_ln1118_49_fu_126547_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_5_fu_126372_p1.read()) + sc_biguint<12>(zext_ln1118_49_fu_126547_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1080_fu_134451_p2() {
    add_ln703_1080_fu_134451_p2 = (!zext_ln708_215_fu_131286_p1.read().is_01() || !add_ln703_1079_fu_134445_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_215_fu_131286_p1.read()) + sc_biguint<11>(add_ln703_1079_fu_134445_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1081_fu_134461_p2() {
    add_ln703_1081_fu_134461_p2 = (!sext_ln1118_308_fu_130544_p1.read().is_01() || !sext_ln1118_335_fu_131272_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_308_fu_130544_p1.read()) + sc_bigint<11>(sext_ln1118_335_fu_131272_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1082_fu_134471_p2() {
    add_ln703_1082_fu_134471_p2 = (!sext_ln703_606_fu_134457_p1.read().is_01() || !sext_ln703_607_fu_134467_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_606_fu_134457_p1.read()) + sc_bigint<12>(sext_ln703_607_fu_134467_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1083_fu_140971_p2() {
    add_ln703_1083_fu_140971_p2 = (!sext_ln1118_337_fu_137710_p1.read().is_01() || !sext_ln703_608_fu_140968_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_337_fu_137710_p1.read()) + sc_bigint<13>(sext_ln703_608_fu_140968_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1084_fu_126358_p2() {
    add_ln703_1084_fu_126358_p2 = (!zext_ln1118_525_fu_124121_p1.read().is_01() || !zext_ln1118_524_fu_124085_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln1118_525_fu_124121_p1.read()) + sc_biguint<8>(zext_ln1118_524_fu_124085_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1085_fu_140980_p2() {
    add_ln703_1085_fu_140980_p2 = (!add_ln703_1083_fu_140971_p2.read().is_01() || !zext_ln703_147_fu_140977_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_1083_fu_140971_p2.read()) + sc_biguint<13>(zext_ln703_147_fu_140977_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1086_fu_134477_p2() {
    add_ln703_1086_fu_134477_p2 = (!sext_ln1118_340_fu_131308_p1.read().is_01() || !zext_ln708_185_fu_130410_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_340_fu_131308_p1.read()) + sc_biguint<11>(zext_ln708_185_fu_130410_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1087_fu_134487_p2() {
    add_ln703_1087_fu_134487_p2 = (!sext_ln1118_339_fu_131304_p1.read().is_01() || !sext_ln1118_338_fu_131290_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_339_fu_131304_p1.read()) + sc_bigint<10>(sext_ln1118_338_fu_131290_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1088_fu_134497_p2() {
    add_ln703_1088_fu_134497_p2 = (!sext_ln703_610_fu_134483_p1.read().is_01() || !sext_ln703_611_fu_134493_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_610_fu_134483_p1.read()) + sc_bigint<12>(sext_ln703_611_fu_134493_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1089_fu_140993_p2() {
    add_ln703_1089_fu_140993_p2 = (!sext_ln703_609_fu_140986_p1.read().is_01() || !sext_ln703_612_fu_140990_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_609_fu_140986_p1.read()) + sc_bigint<14>(sext_ln703_612_fu_140990_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_108_fu_131517_p2() {
    add_ln703_108_fu_131517_p2 = (!zext_ln1116_14_fu_126434_p1.read().is_01() || !zext_ln1116_12_fu_126401_p1.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln1116_14_fu_126434_p1.read()) + sc_biguint<6>(zext_ln1116_12_fu_126401_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1090_fu_134503_p2() {
    add_ln703_1090_fu_134503_p2 = (!zext_ln1118_528_fu_131373_p1.read().is_01() || !sext_ln708_95_fu_131369_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_528_fu_131373_p1.read()) + sc_bigint<12>(sext_ln708_95_fu_131369_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1091_fu_141002_p2() {
    add_ln703_1091_fu_141002_p2 = (!add_ln703_1089_fu_140993_p2.read().is_01() || !sext_ln703_613_fu_140999_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1089_fu_140993_p2.read()) + sc_bigint<14>(sext_ln703_613_fu_140999_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1092_fu_134509_p2() {
    add_ln703_1092_fu_134509_p2 = (!sext_ln1118_344_fu_131380_p1.read().is_01() || !sext_ln1118_332_fu_131131_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_344_fu_131380_p1.read()) + sc_bigint<11>(sext_ln1118_332_fu_131131_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1093_fu_134515_p2() {
    add_ln703_1093_fu_134515_p2 = (!zext_ln708_217_fu_131377_p1.read().is_01() || !add_ln703_1092_fu_134509_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_217_fu_131377_p1.read()) + sc_biguint<11>(add_ln703_1092_fu_134509_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1094_fu_141011_p2() {
    add_ln703_1094_fu_141011_p2 = (!add_ln703_1091_fu_141002_p2.read().is_01() || !sext_ln703_614_fu_141008_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1091_fu_141002_p2.read()) + sc_bigint<14>(sext_ln703_614_fu_141008_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1095_fu_134521_p2() {
    add_ln703_1095_fu_134521_p2 = (!zext_ln1118_529_fu_131398_p1.read().is_01() || !zext_ln1118_45_fu_126480_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_529_fu_131398_p1.read()) + sc_biguint<9>(zext_ln1118_45_fu_126480_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1096_fu_134531_p2() {
    add_ln703_1096_fu_134531_p2 = (!sext_ln708_96_fu_131394_p1.read().is_01() || !zext_ln703_148_fu_134527_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_96_fu_131394_p1.read()) + sc_biguint<11>(zext_ln703_148_fu_134527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1097_fu_134537_p2() {
    add_ln703_1097_fu_134537_p2 = (!sext_ln1118_345_fu_131417_p1.read().is_01() || !sext_ln1118_342_fu_131335_p1.read().is_01())? sc_lv<6>(): (sc_bigint<6>(sext_ln1118_345_fu_131417_p1.read()) + sc_bigint<6>(sext_ln1118_342_fu_131335_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1098_fu_134547_p2() {
    add_ln703_1098_fu_134547_p2 = (!sext_ln1118_341_fu_131311_p1.read().is_01() || !sext_ln703_615_fu_134543_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_341_fu_131311_p1.read()) + sc_bigint<7>(sext_ln703_615_fu_134543_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1099_fu_134557_p2() {
    add_ln703_1099_fu_134557_p2 = (!add_ln703_1096_fu_134531_p2.read().is_01() || !sext_ln703_616_fu_134553_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_1096_fu_134531_p2.read()) + sc_bigint<11>(sext_ln703_616_fu_134553_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_109_fu_131527_p2() {
    add_ln703_109_fu_131527_p2 = (!add_ln703_107_fu_131511_p2.read().is_01() || !zext_ln703_6_fu_131523_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_107_fu_131511_p2.read()) + sc_biguint<12>(zext_ln703_6_fu_131523_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1100_fu_141020_p2() {
    add_ln703_1100_fu_141020_p2 = (!add_ln703_1094_fu_141011_p2.read().is_01() || !sext_ln703_617_fu_141017_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1094_fu_141011_p2.read()) + sc_bigint<14>(sext_ln703_617_fu_141017_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1101_fu_141026_p2() {
    add_ln703_1101_fu_141026_p2 = (!zext_ln203_82_fu_137724_p1.read().is_01() || !add_ln703_1100_fu_141020_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln203_82_fu_137724_p1.read()) + sc_biguint<14>(add_ln703_1100_fu_141020_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1102_fu_141032_p2() {
    add_ln703_1102_fu_141032_p2 = (!sext_ln203_199_fu_137748_p1.read().is_01() || !sext_ln203_195_fu_137717_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_199_fu_137748_p1.read()) + sc_bigint<11>(sext_ln203_195_fu_137717_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1103_fu_141042_p2() {
    add_ln703_1103_fu_141042_p2 = (!zext_ln203_83_fu_137772_p1.read().is_01() || !sext_ln703_618_fu_141038_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_83_fu_137772_p1.read()) + sc_bigint<12>(sext_ln703_618_fu_141038_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1104_fu_141052_p2() {
    add_ln703_1104_fu_141052_p2 = (!add_ln703_1101_fu_141026_p2.read().is_01() || !sext_ln703_619_fu_141048_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_1101_fu_141026_p2.read()) + sc_bigint<14>(sext_ln703_619_fu_141048_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1105_fu_141062_p2() {
    add_ln703_1105_fu_141062_p2 = (!sext_ln203_194_fu_137713_p1.read().is_01() || !sext_ln203_156_fu_137181_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_194_fu_137713_p1.read()) + sc_bigint<11>(sext_ln203_156_fu_137181_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1106_fu_134563_p2() {
    add_ln703_1106_fu_134563_p2 = (!sext_ln203_198_fu_131469_p1.read().is_01() || !sext_ln203_196_fu_131450_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_198_fu_131469_p1.read()) + sc_bigint<9>(sext_ln203_196_fu_131450_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1107_fu_141075_p2() {
    add_ln703_1107_fu_141075_p2 = (!sext_ln203_197_fu_137720_p1.read().is_01() || !sext_ln703_622_fu_141072_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_197_fu_137720_p1.read()) + sc_bigint<10>(sext_ln703_622_fu_141072_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_1108_fu_141085_p2() {
    add_ln703_1108_fu_141085_p2 = (!sext_ln703_621_fu_141068_p1.read().is_01() || !sext_ln703_623_fu_141081_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_621_fu_141068_p1.read()) + sc_bigint<12>(sext_ln703_623_fu_141081_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_110_fu_131537_p2() {
    add_ln703_110_fu_131537_p2 = (!zext_ln703_5_fu_131507_p1.read().is_01() || !sext_ln703_44_fu_131533_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_5_fu_131507_p1.read()) + sc_bigint<13>(sext_ln703_44_fu_131533_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_111_fu_131547_p2() {
    add_ln703_111_fu_131547_p2 = (!add_ln703_104_fu_131486_p2.read().is_01() || !sext_ln703_45_fu_131543_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_104_fu_131486_p2.read()) + sc_bigint<15>(sext_ln703_45_fu_131543_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_112_fu_131553_p2() {
    add_ln703_112_fu_131553_p2 = (!sext_ln203_8_fu_126634_p1.read().is_01() || !sext_ln203_4_fu_126579_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_8_fu_126634_p1.read()) + sc_bigint<12>(sext_ln203_4_fu_126579_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_113_fu_137782_p2() {
    add_ln703_113_fu_137782_p2 = (!sext_ln703_46_fu_137776_p1.read().is_01() || !sext_ln703_47_fu_137779_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_46_fu_137776_p1.read()) + sc_bigint<16>(sext_ln703_47_fu_137779_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_114_fu_131559_p2() {
    add_ln703_114_fu_131559_p2 = (!grp_fu_117214_p4.read().is_01() || !zext_ln203_1_fu_126617_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_117214_p4.read()) + sc_biguint<9>(zext_ln203_1_fu_126617_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_115_fu_131569_p2() {
    add_ln703_115_fu_131569_p2 = (!sext_ln203_10_fu_126638_p1.read().is_01() || !zext_ln703_7_fu_131565_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_10_fu_126638_p1.read()) + sc_biguint<12>(zext_ln703_7_fu_131565_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_116_fu_137791_p2() {
    add_ln703_116_fu_137791_p2 = (!add_ln703_113_fu_137782_p2.read().is_01() || !sext_ln703_48_fu_137788_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_113_fu_137782_p2.read()) + sc_bigint<16>(sext_ln703_48_fu_137788_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_117_fu_137797_p2() {
    add_ln703_117_fu_137797_p2 = (!sext_ln203_7_fu_134709_p1.read().is_01() || !sext_ln203_6_fu_134697_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_7_fu_134709_p1.read()) + sc_bigint<11>(sext_ln203_6_fu_134697_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_118_fu_137807_p2() {
    add_ln703_118_fu_137807_p2 = (!sext_ln203_2_fu_134569_p1.read().is_01() || !sext_ln703_49_fu_137803_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_2_fu_134569_p1.read()) + sc_bigint<12>(sext_ln703_49_fu_137803_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_119_fu_137813_p2() {
    add_ln703_119_fu_137813_p2 = (!sext_ln203_9_fu_134743_p1.read().is_01() || !sext_ln203_3_fu_134594_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_9_fu_134743_p1.read()) + sc_bigint<8>(sext_ln203_3_fu_134594_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_120_fu_137823_p2() {
    add_ln703_120_fu_137823_p2 = (!sext_ln203_5_fu_134639_p1.read().is_01() || !sext_ln703_50_fu_137819_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_5_fu_134639_p1.read()) + sc_bigint<9>(sext_ln703_50_fu_137819_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_121_fu_137833_p2() {
    add_ln703_121_fu_137833_p2 = (!add_ln703_118_fu_137807_p2.read().is_01() || !sext_ln703_51_fu_137829_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_118_fu_137807_p2.read()) + sc_bigint<12>(sext_ln703_51_fu_137829_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_123_fu_124229_p2() {
    add_ln703_123_fu_124229_p2 = (!zext_ln708_15_fu_119366_p1.read().is_01() || !ap_const_lv11_428.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_15_fu_119366_p1.read()) + sc_bigint<11>(ap_const_lv11_428));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_124_fu_118898_p2() {
    add_ln703_124_fu_118898_p2 = (!sext_ln203_11_fu_117988_p1.read().is_01() || !zext_ln203_fu_118001_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_11_fu_117988_p1.read()) + sc_biguint<12>(zext_ln203_fu_118001_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_125_fu_124239_p2() {
    add_ln703_125_fu_124239_p2 = (!sext_ln703_53_fu_124235_p1.read().is_01() || !add_ln703_124_reg_142837.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_53_fu_124235_p1.read()) + sc_biguint<12>(add_ln703_124_reg_142837.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_126_fu_124244_p2() {
    add_ln703_126_fu_124244_p2 = (!zext_ln1118_85_fu_119404_p1.read().is_01() || !add_ln703_125_fu_124239_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_85_fu_119404_p1.read()) + sc_biguint<12>(add_ln703_125_fu_124239_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_127_fu_118904_p2() {
    add_ln703_127_fu_118904_p2 = (!zext_ln1118_86_fu_118009_p1.read().is_01() || !sext_ln1118_71_fu_118005_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_86_fu_118009_p1.read()) + sc_bigint<12>(sext_ln1118_71_fu_118005_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_128_fu_124257_p2() {
    add_ln703_128_fu_124257_p2 = (!sext_ln703_54_fu_124250_p1.read().is_01() || !sext_ln703_55_fu_124254_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_54_fu_124250_p1.read()) + sc_bigint<13>(sext_ln703_55_fu_124254_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_129_fu_124267_p2() {
    add_ln703_129_fu_124267_p2 = (!sext_ln1118_73_fu_119459_p1.read().is_01() || !zext_ln1118_20_fu_119226_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_73_fu_119459_p1.read()) + sc_biguint<12>(zext_ln1118_20_fu_119226_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_130_fu_124277_p2() {
    add_ln703_130_fu_124277_p2 = (!sext_ln703_56_fu_124263_p1.read().is_01() || !sext_ln703_57_fu_124273_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_56_fu_124263_p1.read()) + sc_bigint<14>(sext_ln703_57_fu_124273_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_131_fu_124283_p2() {
    add_ln703_131_fu_124283_p2 = (!sext_ln1118_72_fu_119408_p1.read().is_01() || !zext_ln708_16_fu_119455_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_72_fu_119408_p1.read()) + sc_biguint<11>(zext_ln708_16_fu_119455_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_132_fu_124293_p2() {
    add_ln703_132_fu_124293_p2 = (!zext_ln1118_88_fu_119414_p1.read().is_01() || !sext_ln703_58_fu_124289_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_88_fu_119414_p1.read()) + sc_bigint<12>(sext_ln703_58_fu_124289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_133_fu_131578_p2() {
    add_ln703_133_fu_131578_p2 = (!add_ln703_130_reg_143486.read().is_01() || !sext_ln703_59_fu_131575_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_130_reg_143486.read()) + sc_bigint<14>(sext_ln703_59_fu_131575_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_134_fu_131583_p2() {
    add_ln703_134_fu_131583_p2 = (!zext_ln1118_93_fu_126673_p1.read().is_01() || !trunc_ln_reg_142152.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_93_fu_126673_p1.read()) + sc_biguint<10>(trunc_ln_reg_142152.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_135_fu_131592_p2() {
    add_ln703_135_fu_131592_p2 = (!add_ln703_133_fu_131578_p2.read().is_01() || !zext_ln703_8_fu_131588_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_133_fu_131578_p2.read()) + sc_biguint<14>(zext_ln703_8_fu_131588_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_136_fu_118910_p2() {
    add_ln703_136_fu_118910_p2 = (!zext_ln708_19_fu_118033_p1.read().is_01() || !zext_ln708_17_fu_118024_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_19_fu_118033_p1.read()) + sc_biguint<11>(zext_ln708_17_fu_118024_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_137_fu_124302_p2() {
    add_ln703_137_fu_124302_p2 = (!zext_ln708_22_fu_119550_p1.read().is_01() || !zext_ln708_21_fu_119546_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_22_fu_119550_p1.read()) + sc_biguint<11>(zext_ln708_21_fu_119546_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_138_fu_124312_p2() {
    add_ln703_138_fu_124312_p2 = (!zext_ln703_9_fu_124299_p1.read().is_01() || !zext_ln703_10_fu_124308_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_9_fu_124299_p1.read()) + sc_biguint<12>(zext_ln703_10_fu_124308_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_139_fu_131605_p2() {
    add_ln703_139_fu_131605_p2 = (!sext_ln703_60_fu_131598_p1.read().is_01() || !zext_ln703_11_fu_131602_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_60_fu_131598_p1.read()) + sc_biguint<15>(zext_ln703_11_fu_131602_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_140_fu_118916_p2() {
    add_ln703_140_fu_118916_p2 = (!zext_ln1118_102_fu_118048_p1.read().is_01() || !zext_ln1118_99_fu_118037_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_102_fu_118048_p1.read()) + sc_biguint<10>(zext_ln1118_99_fu_118037_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_141_fu_118922_p2() {
    add_ln703_141_fu_118922_p2 = (!grp_fu_116404_p4.read().is_01() || !zext_ln1118_103_fu_118052_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(grp_fu_116404_p4.read()) + sc_biguint<8>(zext_ln1118_103_fu_118052_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_142_fu_118932_p2() {
    add_ln703_142_fu_118932_p2 = (!add_ln703_140_fu_118916_p2.read().is_01() || !zext_ln703_12_fu_118928_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(add_ln703_140_fu_118916_p2.read()) + sc_biguint<10>(zext_ln703_12_fu_118928_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_143_fu_131614_p2() {
    add_ln703_143_fu_131614_p2 = (!sext_ln1118_79_fu_126719_p1.read().is_01() || !sext_ln1118_75_fu_126676_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_79_fu_126719_p1.read()) + sc_bigint<11>(sext_ln1118_75_fu_126676_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_144_fu_131620_p2() {
    add_ln703_144_fu_131620_p2 = (!sext_ln1118_74_fu_126669_p1.read().is_01() || !sext_ln1118_77_fu_126680_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_74_fu_126669_p1.read()) + sc_bigint<9>(sext_ln1118_77_fu_126680_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_145_fu_131630_p2() {
    add_ln703_145_fu_131630_p2 = (!add_ln703_143_fu_131614_p2.read().is_01() || !sext_ln703_61_fu_131626_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_143_fu_131614_p2.read()) + sc_bigint<11>(sext_ln703_61_fu_131626_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_146_fu_131640_p2() {
    add_ln703_146_fu_131640_p2 = (!zext_ln703_13_fu_131611_p1.read().is_01() || !sext_ln703_62_fu_131636_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_13_fu_131611_p1.read()) + sc_bigint<12>(sext_ln703_62_fu_131636_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_147_fu_131650_p2() {
    add_ln703_147_fu_131650_p2 = (!add_ln703_139_fu_131605_p2.read().is_01() || !sext_ln703_63_fu_131646_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_139_fu_131605_p2.read()) + sc_bigint<15>(sext_ln703_63_fu_131646_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_148_fu_137849_p2() {
    add_ln703_148_fu_137849_p2 = (!zext_ln708_24_fu_134811_p1.read().is_01() || !zext_ln708_23_fu_134807_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_24_fu_134811_p1.read()) + sc_biguint<11>(zext_ln708_23_fu_134807_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_149_fu_137859_p2() {
    add_ln703_149_fu_137859_p2 = (!add_ln703_147_reg_144148.read().is_01() || !zext_ln703_14_fu_137855_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_147_reg_144148.read()) + sc_biguint<15>(zext_ln703_14_fu_137855_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_150_fu_131656_p2() {
    add_ln703_150_fu_131656_p2 = (!sext_ln203_14_fu_126727_p1.read().is_01() || !sext_ln203_13_fu_126723_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_14_fu_126727_p1.read()) + sc_bigint<11>(sext_ln203_13_fu_126723_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_151_fu_137867_p2() {
    add_ln703_151_fu_137867_p2 = (!sext_ln203_12_fu_134793_p1.read().is_01() || !sext_ln203_15_fu_134853_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_12_fu_134793_p1.read()) + sc_bigint<11>(sext_ln203_15_fu_134853_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_152_fu_137877_p2() {
    add_ln703_152_fu_137877_p2 = (!sext_ln703_64_fu_137864_p1.read().is_01() || !sext_ln703_65_fu_137873_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_64_fu_137864_p1.read()) + sc_bigint<12>(sext_ln703_65_fu_137873_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_154_fu_124318_p2() {
    add_ln703_154_fu_124318_p2 = (!trunc_ln6_reg_142205.read().is_01() || !ap_const_lv10_220.is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln6_reg_142205.read()) + sc_bigint<10>(ap_const_lv10_220));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_155_fu_124327_p2() {
    add_ln703_155_fu_124327_p2 = (!sext_ln1118_81_fu_119572_p1.read().is_01() || !sext_ln703_68_fu_124323_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_81_fu_119572_p1.read()) + sc_bigint<11>(sext_ln703_68_fu_124323_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_156_fu_124337_p2() {
    add_ln703_156_fu_124337_p2 = (!zext_ln203_2_fu_119576_p1.read().is_01() || !sext_ln703_69_fu_124333_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_2_fu_119576_p1.read()) + sc_bigint<12>(sext_ln703_69_fu_124333_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_157_fu_124343_p2() {
    add_ln703_157_fu_124343_p2 = (!zext_ln1118_115_fu_119641_p1.read().is_01() || !add_ln703_156_fu_124337_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_115_fu_119641_p1.read()) + sc_biguint<12>(add_ln703_156_fu_124337_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_158_fu_124353_p2() {
    add_ln703_158_fu_124353_p2 = (!sext_ln1118_82_fu_119610_p1.read().is_01() || !sext_ln1118_83_fu_119645_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_82_fu_119610_p1.read()) + sc_bigint<11>(sext_ln1118_83_fu_119645_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_159_fu_124363_p2() {
    add_ln703_159_fu_124363_p2 = (!sext_ln703_70_fu_124349_p1.read().is_01() || !sext_ln703_71_fu_124359_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_70_fu_124349_p1.read()) + sc_bigint<13>(sext_ln703_71_fu_124359_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_160_fu_118938_p2() {
    add_ln703_160_fu_118938_p2 = (!zext_ln708_26_fu_118090_p1.read().is_01() || !zext_ln708_25_fu_118086_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_26_fu_118090_p1.read()) + sc_biguint<11>(zext_ln708_25_fu_118086_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_161_fu_124372_p2() {
    add_ln703_161_fu_124372_p2 = (!add_ln703_159_fu_124363_p2.read().is_01() || !zext_ln703_15_fu_124369_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_159_fu_124363_p2.read()) + sc_biguint<13>(zext_ln703_15_fu_124369_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_162_fu_124382_p2() {
    add_ln703_162_fu_124382_p2 = (!sext_ln1118_84_fu_119748_p1.read().is_01() || !sext_ln708_fu_119675_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_84_fu_119748_p1.read()) + sc_bigint<8>(sext_ln708_fu_119675_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_163_fu_124392_p2() {
    add_ln703_163_fu_124392_p2 = (!zext_ln708_29_fu_119717_p1.read().is_01() || !sext_ln703_73_fu_124388_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_29_fu_119717_p1.read()) + sc_bigint<11>(sext_ln703_73_fu_124388_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_164_fu_124402_p2() {
    add_ln703_164_fu_124402_p2 = (!sext_ln703_72_fu_124378_p1.read().is_01() || !sext_ln703_74_fu_124398_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_72_fu_124378_p1.read()) + sc_bigint<14>(sext_ln703_74_fu_124398_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_165_fu_124408_p2() {
    add_ln703_165_fu_124408_p2 = (!zext_ln1118_120_fu_119752_p1.read().is_01() || !add_ln703_164_fu_124402_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_120_fu_119752_p1.read()) + sc_biguint<14>(add_ln703_164_fu_124402_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_166_fu_131662_p2() {
    add_ln703_166_fu_131662_p2 = (!zext_ln708_31_fu_126813_p1.read().is_01() || !zext_ln1118_121_fu_126776_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_31_fu_126813_p1.read()) + sc_biguint<10>(zext_ln1118_121_fu_126776_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_167_fu_131672_p2() {
    add_ln703_167_fu_131672_p2 = (!add_ln703_165_reg_143501.read().is_01() || !zext_ln703_16_fu_131668_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_165_reg_143501.read()) + sc_biguint<14>(zext_ln703_16_fu_131668_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_168_fu_131677_p2() {
    add_ln703_168_fu_131677_p2 = (!zext_ln1118_127_fu_126847_p1.read().is_01() || !zext_ln1118_126_fu_126843_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_127_fu_126847_p1.read()) + sc_biguint<10>(zext_ln1118_126_fu_126843_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_169_fu_131687_p2() {
    add_ln703_169_fu_131687_p2 = (!tmp_46_reg_142256.read().is_01() || !zext_ln1118_133_fu_126930_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_46_reg_142256.read()) + sc_biguint<8>(zext_ln1118_133_fu_126930_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_170_fu_131696_p2() {
    add_ln703_170_fu_131696_p2 = (!zext_ln1118_129_fu_126884_p1.read().is_01() || !zext_ln703_18_fu_131692_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_129_fu_126884_p1.read()) + sc_biguint<9>(zext_ln703_18_fu_131692_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_171_fu_131706_p2() {
    add_ln703_171_fu_131706_p2 = (!zext_ln703_17_fu_131683_p1.read().is_01() || !zext_ln703_19_fu_131702_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_17_fu_131683_p1.read()) + sc_biguint<11>(zext_ln703_19_fu_131702_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_172_fu_131716_p2() {
    add_ln703_172_fu_131716_p2 = (!add_ln703_167_fu_131672_p2.read().is_01() || !zext_ln703_20_fu_131712_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_167_fu_131672_p2.read()) + sc_biguint<14>(zext_ln703_20_fu_131712_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_173_fu_124414_p2() {
    add_ln703_173_fu_124414_p2 = (!zext_ln1118_137_fu_119808_p1.read().is_01() || !zext_ln1118_135_fu_119771_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_137_fu_119808_p1.read()) + sc_biguint<10>(zext_ln1118_135_fu_119771_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_174_fu_131725_p2() {
    add_ln703_174_fu_131725_p2 = (!sext_ln708_51_fu_126769_p1.read().is_01() || !zext_ln708_32_fu_126940_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_51_fu_126769_p1.read()) + sc_biguint<11>(zext_ln708_32_fu_126940_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_175_fu_131735_p2() {
    add_ln703_175_fu_131735_p2 = (!zext_ln1118_138_fu_126937_p1.read().is_01() || !sext_ln703_76_fu_131731_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_138_fu_126937_p1.read()) + sc_bigint<12>(sext_ln703_76_fu_131731_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_176_fu_131745_p2() {
    add_ln703_176_fu_131745_p2 = (!zext_ln703_21_fu_131722_p1.read().is_01() || !sext_ln703_77_fu_131741_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_21_fu_131722_p1.read()) + sc_bigint<13>(sext_ln703_77_fu_131741_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_177_fu_124420_p2() {
    add_ln703_177_fu_124420_p2 = (!zext_ln1118_123_fu_119756_p1.read().is_01() || !sext_ln708_52_fu_119812_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_123_fu_119756_p1.read()) + sc_bigint<11>(sext_ln708_52_fu_119812_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_178_fu_131754_p2() {
    add_ln703_178_fu_131754_p2 = (!sext_ln1118_85_fu_126970_p1.read().is_01() || !zext_ln708_30_fu_126773_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_85_fu_126970_p1.read()) + sc_biguint<7>(zext_ln708_30_fu_126773_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_179_fu_131764_p2() {
    add_ln703_179_fu_131764_p2 = (!zext_ln708_13_fu_126597_p1.read().is_01() || !sext_ln703_79_fu_131760_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_13_fu_126597_p1.read()) + sc_bigint<11>(sext_ln703_79_fu_131760_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_180_fu_131774_p2() {
    add_ln703_180_fu_131774_p2 = (!sext_ln703_78_fu_131751_p1.read().is_01() || !sext_ln703_80_fu_131770_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_78_fu_131751_p1.read()) + sc_bigint<12>(sext_ln703_80_fu_131770_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_181_fu_131784_p2() {
    add_ln703_181_fu_131784_p2 = (!add_ln703_176_fu_131745_p2.read().is_01() || !sext_ln703_81_fu_131780_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_176_fu_131745_p2.read()) + sc_bigint<13>(sext_ln703_81_fu_131780_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_182_fu_137903_p2() {
    add_ln703_182_fu_137903_p2 = (!sext_ln703_75_fu_137897_p1.read().is_01() || !sext_ln703_82_fu_137900_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_75_fu_137897_p1.read()) + sc_bigint<15>(sext_ln703_82_fu_137900_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_183_fu_137909_p2() {
    add_ln703_183_fu_137909_p2 = (!zext_ln203_3_fu_134857_p1.read().is_01() || !add_ln703_182_fu_137903_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_3_fu_134857_p1.read()) + sc_biguint<15>(add_ln703_182_fu_137903_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_184_fu_137915_p2() {
    add_ln703_184_fu_137915_p2 = (!sext_ln203_16_fu_134902_p1.read().is_01() || !zext_ln708_33_fu_134861_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_16_fu_134902_p1.read()) + sc_biguint<11>(zext_ln708_33_fu_134861_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_186_fu_124426_p2() {
    add_ln703_186_fu_124426_p2 = (!sext_ln203_17_fu_119835_p1.read().is_01() || !ap_const_lv12_EC8.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_17_fu_119835_p1.read()) + sc_bigint<12>(ap_const_lv12_EC8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_187_fu_124436_p2() {
    add_ln703_187_fu_124436_p2 = (!sext_ln203_18_fu_119839_p1.read().is_01() || !sext_ln703_85_fu_124432_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_18_fu_119839_p1.read()) + sc_bigint<13>(sext_ln703_85_fu_124432_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_188_fu_124442_p2() {
    add_ln703_188_fu_124442_p2 = (!zext_ln1118_145_fu_119880_p1.read().is_01() || !sext_ln1118_87_fu_119884_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_145_fu_119880_p1.read()) + sc_bigint<12>(sext_ln1118_87_fu_119884_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_189_fu_124452_p2() {
    add_ln703_189_fu_124452_p2 = (!add_ln703_187_fu_124436_p2.read().is_01() || !sext_ln703_86_fu_124448_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_187_fu_124436_p2.read()) + sc_bigint<13>(sext_ln703_86_fu_124448_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_190_fu_124462_p2() {
    add_ln703_190_fu_124462_p2 = (!sext_ln1118_91_fu_119943_p1.read().is_01() || !sext_ln1118_90_fu_119921_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_91_fu_119943_p1.read()) + sc_bigint<12>(sext_ln1118_90_fu_119921_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_191_fu_124472_p2() {
    add_ln703_191_fu_124472_p2 = (!sext_ln703_87_fu_124458_p1.read().is_01() || !sext_ln703_88_fu_124468_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_87_fu_124458_p1.read()) + sc_bigint<14>(sext_ln703_88_fu_124468_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_192_fu_124478_p2() {
    add_ln703_192_fu_124478_p2 = (!sext_ln1118_88_fu_119914_p1.read().is_01() || !sext_ln1118_89_fu_119918_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_88_fu_119914_p1.read()) + sc_bigint<11>(sext_ln1118_89_fu_119918_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_193_fu_124484_p2() {
    add_ln703_193_fu_124484_p2 = (!zext_ln708_34_fu_119947_p1.read().is_01() || !add_ln703_192_fu_124478_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_34_fu_119947_p1.read()) + sc_biguint<11>(add_ln703_192_fu_124478_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_194_fu_124494_p2() {
    add_ln703_194_fu_124494_p2 = (!add_ln703_191_fu_124472_p2.read().is_01() || !sext_ln703_89_fu_124490_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_191_fu_124472_p2.read()) + sc_bigint<14>(sext_ln703_89_fu_124490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_195_fu_124500_p2() {
    add_ln703_195_fu_124500_p2 = (!sext_ln1118_95_fu_120024_p1.read().is_01() || !add_ln703_194_fu_124494_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_95_fu_120024_p1.read()) + sc_biguint<14>(add_ln703_194_fu_124494_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_196_fu_131793_p2() {
    add_ln703_196_fu_131793_p2 = (!zext_ln1118_150_fu_126977_p1.read().is_01() || !sext_ln708_53_fu_127092_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_150_fu_126977_p1.read()) + sc_bigint<12>(sext_ln708_53_fu_127092_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_197_fu_131803_p2() {
    add_ln703_197_fu_131803_p2 = (!sext_ln1118_96_fu_127063_p1.read().is_01() || !sext_ln703_91_fu_131799_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_96_fu_127063_p1.read()) + sc_bigint<13>(sext_ln703_91_fu_131799_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_198_fu_131813_p2() {
    add_ln703_198_fu_131813_p2 = (!sext_ln703_90_fu_131790_p1.read().is_01() || !sext_ln703_92_fu_131809_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_90_fu_131790_p1.read()) + sc_bigint<15>(sext_ln703_92_fu_131809_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_199_fu_131819_p2() {
    add_ln703_199_fu_131819_p2 = (!zext_ln708_37_fu_127118_p1.read().is_01() || !zext_ln708_36_fu_127014_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_37_fu_127118_p1.read()) + sc_biguint<11>(zext_ln708_36_fu_127014_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_200_fu_131825_p2() {
    add_ln703_200_fu_131825_p2 = (!zext_ln708_35_fu_126980_p1.read().is_01() || !add_ln703_199_fu_131819_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_35_fu_126980_p1.read()) + sc_biguint<11>(add_ln703_199_fu_131819_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_201_fu_131835_p2() {
    add_ln703_201_fu_131835_p2 = (!sext_ln1118_93_fu_127018_p1.read().is_01() || !sext_ln1118_94_fu_127059_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_93_fu_127018_p1.read()) + sc_bigint<11>(sext_ln1118_94_fu_127059_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_202_fu_131845_p2() {
    add_ln703_202_fu_131845_p2 = (!sext_ln1118_92_fu_126974_p1.read().is_01() || !sext_ln703_93_fu_131841_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_92_fu_126974_p1.read()) + sc_bigint<12>(sext_ln703_93_fu_131841_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_203_fu_131855_p2() {
    add_ln703_203_fu_131855_p2 = (!zext_ln703_22_fu_131831_p1.read().is_01() || !sext_ln703_94_fu_131851_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_22_fu_131831_p1.read()) + sc_bigint<13>(sext_ln703_94_fu_131851_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_204_fu_131865_p2() {
    add_ln703_204_fu_131865_p2 = (!add_ln703_198_fu_131813_p2.read().is_01() || !sext_ln703_95_fu_131861_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_198_fu_131813_p2.read()) + sc_bigint<15>(sext_ln703_95_fu_131861_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_205_fu_137935_p2() {
    add_ln703_205_fu_137935_p2 = (!sext_ln203_23_fu_134940_p1.read().is_01() || !sext_ln203_19_fu_134916_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_23_fu_134940_p1.read()) + sc_bigint<12>(sext_ln203_19_fu_134916_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_206_fu_137945_p2() {
    add_ln703_206_fu_137945_p2 = (!add_ln703_204_reg_144168.read().is_01() || !sext_ln703_96_fu_137941_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_204_reg_144168.read()) + sc_bigint<15>(sext_ln703_96_fu_137941_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_207_fu_137950_p2() {
    add_ln703_207_fu_137950_p2 = (!zext_ln708_39_fu_134963_p1.read().is_01() || !zext_ln708_38_fu_134959_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_39_fu_134963_p1.read()) + sc_biguint<11>(zext_ln708_38_fu_134959_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_208_fu_137956_p2() {
    add_ln703_208_fu_137956_p2 = (!trunc_ln203_2_reg_142332.read().is_01() || !zext_ln203_4_fu_135001_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln203_2_reg_142332.read()) + sc_biguint<9>(zext_ln203_4_fu_135001_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_209_fu_137965_p2() {
    add_ln703_209_fu_137965_p2 = (!add_ln703_207_fu_137950_p2.read().is_01() || !zext_ln703_23_fu_137961_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_207_fu_137950_p2.read()) + sc_biguint<11>(zext_ln703_23_fu_137961_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_210_fu_137975_p2() {
    add_ln703_210_fu_137975_p2 = (!add_ln703_206_fu_137945_p2.read().is_01() || !zext_ln703_24_fu_137971_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_206_fu_137945_p2.read()) + sc_biguint<15>(zext_ln703_24_fu_137971_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_211_fu_137985_p2() {
    add_ln703_211_fu_137985_p2 = (!zext_ln708_42_fu_135027_p1.read().is_01() || !zext_ln708_41_fu_135009_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_42_fu_135027_p1.read()) + sc_biguint<11>(zext_ln708_41_fu_135009_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_212_fu_137991_p2() {
    add_ln703_212_fu_137991_p2 = (!zext_ln708_40_fu_135005_p1.read().is_01() || !add_ln703_211_fu_137985_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_40_fu_135005_p1.read()) + sc_biguint<11>(add_ln703_211_fu_137985_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_213_fu_131871_p2() {
    add_ln703_213_fu_131871_p2 = (!sext_ln203_21_fu_127169_p1.read().is_01() || !sext_ln203_20_fu_127138_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_21_fu_127169_p1.read()) + sc_bigint<11>(sext_ln203_20_fu_127138_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_214_fu_138004_p2() {
    add_ln703_214_fu_138004_p2 = (!sext_ln203_24_fu_135062_p1.read().is_01() || !sext_ln203_22_fu_134936_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_24_fu_135062_p1.read()) + sc_bigint<8>(sext_ln203_22_fu_134936_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_215_fu_138014_p2() {
    add_ln703_215_fu_138014_p2 = (!sext_ln703_98_fu_138001_p1.read().is_01() || !sext_ln703_99_fu_138010_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_98_fu_138001_p1.read()) + sc_bigint<12>(sext_ln703_99_fu_138010_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_216_fu_138024_p2() {
    add_ln703_216_fu_138024_p2 = (!zext_ln703_25_fu_137997_p1.read().is_01() || !sext_ln703_100_fu_138020_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_25_fu_137997_p1.read()) + sc_bigint<13>(sext_ln703_100_fu_138020_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_218_fu_118944_p2() {
    add_ln703_218_fu_118944_p2 = (!sext_ln1118_97_fu_118129_p1.read().is_01() || !ap_const_lv11_790.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_97_fu_118129_p1.read()) + sc_bigint<11>(ap_const_lv11_790));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_219_fu_118954_p2() {
    add_ln703_219_fu_118954_p2 = (!sext_ln1118_98_fu_118143_p1.read().is_01() || !sext_ln1118_99_fu_118147_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_98_fu_118143_p1.read()) + sc_bigint<11>(sext_ln1118_99_fu_118147_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_220_fu_118964_p2() {
    add_ln703_220_fu_118964_p2 = (!sext_ln703_102_fu_118950_p1.read().is_01() || !sext_ln703_103_fu_118960_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_102_fu_118950_p1.read()) + sc_bigint<12>(sext_ln703_103_fu_118960_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_221_fu_118970_p2() {
    add_ln703_221_fu_118970_p2 = (!sext_ln1118_100_fu_118151_p1.read().is_01() || !zext_ln708_43_fu_118159_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_100_fu_118151_p1.read()) + sc_biguint<11>(zext_ln708_43_fu_118159_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_222_fu_118980_p2() {
    add_ln703_222_fu_118980_p2 = (!add_ln703_220_fu_118964_p2.read().is_01() || !sext_ln703_104_fu_118976_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_220_fu_118964_p2.read()) + sc_bigint<12>(sext_ln703_104_fu_118976_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_223_fu_118986_p2() {
    add_ln703_223_fu_118986_p2 = (!sext_ln1116_9_fu_118169_p1.read().is_01() || !sext_ln1118_101_fu_118155_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_9_fu_118169_p1.read()) + sc_bigint<11>(sext_ln1118_101_fu_118155_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_224_fu_124512_p2() {
    add_ln703_224_fu_124512_p2 = (!zext_ln1118_167_fu_120069_p1.read().is_01() || !sext_ln1118_102_fu_120061_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_167_fu_120069_p1.read()) + sc_bigint<10>(sext_ln1118_102_fu_120061_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_225_fu_124522_p2() {
    add_ln703_225_fu_124522_p2 = (!sext_ln703_106_fu_124509_p1.read().is_01() || !sext_ln703_107_fu_124518_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_106_fu_124509_p1.read()) + sc_bigint<12>(sext_ln703_107_fu_124518_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_226_fu_124532_p2() {
    add_ln703_226_fu_124532_p2 = (!sext_ln703_105_fu_124506_p1.read().is_01() || !sext_ln703_108_fu_124528_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_105_fu_124506_p1.read()) + sc_bigint<13>(sext_ln703_108_fu_124528_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_227_fu_124542_p2() {
    add_ln703_227_fu_124542_p2 = (!zext_ln1118_176_fu_120161_p1.read().is_01() || !sext_ln1118_106_fu_120157_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_176_fu_120161_p1.read()) + sc_bigint<12>(sext_ln1118_106_fu_120157_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_228_fu_124552_p2() {
    add_ln703_228_fu_124552_p2 = (!sext_ln703_109_fu_124538_p1.read().is_01() || !sext_ln703_110_fu_124548_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_109_fu_124538_p1.read()) + sc_bigint<14>(sext_ln703_110_fu_124548_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_229_fu_131877_p2() {
    add_ln703_229_fu_131877_p2 = (!sext_ln1118_110_fu_127356_p1.read().is_01() || !zext_ln708_46_fu_127270_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_110_fu_127356_p1.read()) + sc_biguint<11>(zext_ln708_46_fu_127270_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_230_fu_131883_p2() {
    add_ln703_230_fu_131883_p2 = (!zext_ln708_45_fu_127267_p1.read().is_01() || !add_ln703_229_fu_131877_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_45_fu_127267_p1.read()) + sc_biguint<11>(add_ln703_229_fu_131877_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_231_fu_131893_p2() {
    add_ln703_231_fu_131893_p2 = (!add_ln703_228_reg_143521.read().is_01() || !sext_ln703_111_fu_131889_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_228_reg_143521.read()) + sc_bigint<14>(sext_ln703_111_fu_131889_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_232_fu_118992_p2() {
    add_ln703_232_fu_118992_p2 = (!sext_ln1116_12_fu_118230_p1.read().is_01() || !sext_ln1118_107_fu_118203_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_12_fu_118230_p1.read()) + sc_bigint<10>(sext_ln1118_107_fu_118203_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_233_fu_131901_p2() {
    add_ln703_233_fu_131901_p2 = (!sext_ln1118_104_fu_127191_p1.read().is_01() || !sext_ln703_112_fu_131898_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_104_fu_127191_p1.read()) + sc_bigint<11>(sext_ln703_112_fu_131898_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_234_fu_131907_p2() {
    add_ln703_234_fu_131907_p2 = (!sext_ln1116_11_fu_127304_p1.read().is_01() || !sext_ln1118_108_fu_127263_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1116_11_fu_127304_p1.read()) + sc_bigint<8>(sext_ln1118_108_fu_127263_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_235_fu_131917_p2() {
    add_ln703_235_fu_131917_p2 = (!sext_ln1116_10_fu_127232_p1.read().is_01() || !sext_ln703_113_fu_131913_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1116_10_fu_127232_p1.read()) + sc_bigint<9>(sext_ln703_113_fu_131913_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_236_fu_131927_p2() {
    add_ln703_236_fu_131927_p2 = (!add_ln703_233_fu_131901_p2.read().is_01() || !sext_ln703_114_fu_131923_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_233_fu_131901_p2.read()) + sc_bigint<11>(sext_ln703_114_fu_131923_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_237_fu_131937_p2() {
    add_ln703_237_fu_131937_p2 = (!add_ln703_231_fu_131893_p2.read().is_01() || !sext_ln703_115_fu_131933_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_231_fu_131893_p2.read()) + sc_bigint<14>(sext_ln703_115_fu_131933_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_238_fu_138043_p2() {
    add_ln703_238_fu_138043_p2 = (!sext_ln203_35_fu_135239_p1.read().is_01() || !sext_ln203_28_fu_135114_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_35_fu_135239_p1.read()) + sc_bigint<12>(sext_ln203_28_fu_135114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_239_fu_138053_p2() {
    add_ln703_239_fu_138053_p2 = (!sext_ln703_116_fu_138040_p1.read().is_01() || !sext_ln703_117_fu_138049_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_116_fu_138040_p1.read()) + sc_bigint<15>(sext_ln703_117_fu_138049_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_240_fu_138059_p2() {
    add_ln703_240_fu_138059_p2 = (!sext_ln203_30_fu_135120_p1.read().is_01() || !sext_ln203_26_fu_135069_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_30_fu_135120_p1.read()) + sc_bigint<11>(sext_ln203_26_fu_135069_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_241_fu_138069_p2() {
    add_ln703_241_fu_138069_p2 = (!zext_ln203_5_fu_135174_p1.read().is_01() || !sext_ln703_118_fu_138065_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_5_fu_135174_p1.read()) + sc_bigint<12>(sext_ln703_118_fu_138065_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_242_fu_138079_p2() {
    add_ln703_242_fu_138079_p2 = (!add_ln703_239_fu_138053_p2.read().is_01() || !sext_ln703_119_fu_138075_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_239_fu_138053_p2.read()) + sc_bigint<15>(sext_ln703_119_fu_138075_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_243_fu_138085_p2() {
    add_ln703_243_fu_138085_p2 = (!sext_ln203_29_fu_135117_p1.read().is_01() || !sext_ln203_27_fu_135110_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_29_fu_135117_p1.read()) + sc_bigint<10>(sext_ln203_27_fu_135110_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_244_fu_138095_p2() {
    add_ln703_244_fu_138095_p2 = (!sext_ln203_31_fu_135134_p1.read().is_01() || !sext_ln703_120_fu_138091_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_31_fu_135134_p1.read()) + sc_bigint<11>(sext_ln703_120_fu_138091_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_245_fu_138105_p2() {
    add_ln703_245_fu_138105_p2 = (!sext_ln203_34_fu_135235_p1.read().is_01() || !sext_ln203_32_fu_135138_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_34_fu_135235_p1.read()) + sc_bigint<10>(sext_ln203_32_fu_135138_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_246_fu_138115_p2() {
    add_ln703_246_fu_138115_p2 = (!sext_ln203_33_fu_135166_p1.read().is_01() || !sext_ln203_25_fu_135066_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_33_fu_135166_p1.read()) + sc_bigint<9>(sext_ln203_25_fu_135066_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_247_fu_138125_p2() {
    add_ln703_247_fu_138125_p2 = (!sext_ln703_122_fu_138111_p1.read().is_01() || !sext_ln703_123_fu_138121_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_122_fu_138111_p1.read()) + sc_bigint<11>(sext_ln703_123_fu_138121_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_248_fu_138135_p2() {
    add_ln703_248_fu_138135_p2 = (!sext_ln703_121_fu_138101_p1.read().is_01() || !sext_ln703_124_fu_138131_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_121_fu_138101_p1.read()) + sc_bigint<12>(sext_ln703_124_fu_138131_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_250_fu_124558_p2() {
    add_ln703_250_fu_124558_p2 = (!sext_ln1118_113_fu_120206_p1.read().is_01() || !ap_const_lv11_608.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_113_fu_120206_p1.read()) + sc_bigint<11>(ap_const_lv11_608));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_251_fu_124568_p2() {
    add_ln703_251_fu_124568_p2 = (!zext_ln708_48_fu_120213_p1.read().is_01() || !sext_ln1118_114_fu_120210_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_48_fu_120213_p1.read()) + sc_bigint<12>(sext_ln1118_114_fu_120210_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_252_fu_124574_p2() {
    add_ln703_252_fu_124574_p2 = (!sext_ln703_127_fu_124564_p1.read().is_01() || !add_ln703_251_fu_124568_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_127_fu_124564_p1.read()) + sc_biguint<12>(add_ln703_251_fu_124568_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_253_fu_124584_p2() {
    add_ln703_253_fu_124584_p2 = (!sext_ln1118_116_fu_120245_p1.read().is_01() || !zext_ln708_49_fu_120271_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_116_fu_120245_p1.read()) + sc_biguint<11>(zext_ln708_49_fu_120271_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_254_fu_124594_p2() {
    add_ln703_254_fu_124594_p2 = (!zext_ln1118_203_fu_120216_p1.read().is_01() || !sext_ln703_129_fu_124590_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_203_fu_120216_p1.read()) + sc_bigint<12>(sext_ln703_129_fu_124590_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_255_fu_124604_p2() {
    add_ln703_255_fu_124604_p2 = (!sext_ln703_128_fu_124580_p1.read().is_01() || !sext_ln703_130_fu_124600_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_128_fu_124580_p1.read()) + sc_bigint<13>(sext_ln703_130_fu_124600_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_256_fu_131946_p2() {
    add_ln703_256_fu_131946_p2 = (!sext_ln1118_117_fu_127485_p1.read().is_01() || !zext_ln1118_204_fu_127482_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_117_fu_127485_p1.read()) + sc_biguint<12>(zext_ln1118_204_fu_127482_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_257_fu_131956_p2() {
    add_ln703_257_fu_131956_p2 = (!sext_ln703_131_fu_131943_p1.read().is_01() || !sext_ln703_132_fu_131952_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_131_fu_131943_p1.read()) + sc_bigint<14>(sext_ln703_132_fu_131952_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_258_fu_124610_p2() {
    add_ln703_258_fu_124610_p2 = (!trunc_ln1118_2_reg_142459.read().is_01() || !zext_ln1118_207_fu_120350_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_2_reg_142459.read()) + sc_biguint<10>(zext_ln1118_207_fu_120350_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_259_fu_124619_p2() {
    add_ln703_259_fu_124619_p2 = (!zext_ln1118_26_fu_119240_p1.read().is_01() || !sext_ln203_36_fu_120354_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_26_fu_119240_p1.read()) + sc_bigint<10>(sext_ln203_36_fu_120354_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_260_fu_124629_p2() {
    add_ln703_260_fu_124629_p2 = (!zext_ln703_26_fu_124615_p1.read().is_01() || !sext_ln703_133_fu_124625_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_26_fu_124615_p1.read()) + sc_bigint<12>(sext_ln703_133_fu_124625_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_261_fu_131965_p2() {
    add_ln703_261_fu_131965_p2 = (!add_ln703_257_fu_131956_p2.read().is_01() || !sext_ln703_134_fu_131962_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_257_fu_131956_p2.read()) + sc_bigint<14>(sext_ln703_134_fu_131962_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_262_fu_131971_p2() {
    add_ln703_262_fu_131971_p2 = (!sext_ln1118_120_fu_127551_p1.read().is_01() || !zext_ln1118_209_fu_127493_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_120_fu_127551_p1.read()) + sc_biguint<12>(zext_ln1118_209_fu_127493_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_263_fu_131981_p2() {
    add_ln703_263_fu_131981_p2 = (!add_ln703_261_fu_131965_p2.read().is_01() || !sext_ln703_135_fu_131977_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_261_fu_131965_p2.read()) + sc_bigint<14>(sext_ln703_135_fu_131977_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_264_fu_118998_p2() {
    add_ln703_264_fu_118998_p2 = (!zext_ln708_52_fu_118291_p1.read().is_01() || !zext_ln708_51_fu_118287_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_52_fu_118291_p1.read()) + sc_biguint<11>(zext_ln708_51_fu_118287_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_265_fu_131994_p2() {
    add_ln703_265_fu_131994_p2 = (!sext_ln1118_121_fu_127575_p1.read().is_01() || !zext_ln703_27_fu_131991_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_121_fu_127575_p1.read()) + sc_biguint<13>(zext_ln703_27_fu_131991_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_266_fu_132004_p2() {
    add_ln703_266_fu_132004_p2 = (!sext_ln703_136_fu_131987_p1.read().is_01() || !sext_ln703_137_fu_132000_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_136_fu_131987_p1.read()) + sc_bigint<15>(sext_ln703_137_fu_132000_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_267_fu_132010_p2() {
    add_ln703_267_fu_132010_p2 = (!trunc_ln1118_3_reg_142498.read().is_01() || !zext_ln1118_134_fu_126934_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_3_reg_142498.read()) + sc_biguint<10>(zext_ln1118_134_fu_126934_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_268_fu_132015_p2() {
    add_ln703_268_fu_132015_p2 = (!zext_ln1118_213_fu_127599_p1.read().is_01() || !add_ln703_267_fu_132010_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_213_fu_127599_p1.read()) + sc_biguint<10>(add_ln703_267_fu_132010_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_269_fu_132025_p2() {
    add_ln703_269_fu_132025_p2 = (!sext_ln708_54_fu_127499_p1.read().is_01() || !zext_ln708_54_fu_127630_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_54_fu_127499_p1.read()) + sc_biguint<11>(zext_ln708_54_fu_127630_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_270_fu_132035_p2() {
    add_ln703_270_fu_132035_p2 = (!sext_ln1118_119_fu_127528_p1.read().is_01() || !sext_ln1118_118_fu_127496_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_119_fu_127528_p1.read()) + sc_bigint<10>(sext_ln1118_118_fu_127496_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_271_fu_132045_p2() {
    add_ln703_271_fu_132045_p2 = (!sext_ln703_138_fu_132031_p1.read().is_01() || !sext_ln703_139_fu_132041_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_138_fu_132031_p1.read()) + sc_bigint<12>(sext_ln703_139_fu_132041_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_272_fu_132055_p2() {
    add_ln703_272_fu_132055_p2 = (!zext_ln703_28_fu_132021_p1.read().is_01() || !sext_ln703_140_fu_132051_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_28_fu_132021_p1.read()) + sc_bigint<13>(sext_ln703_140_fu_132051_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_273_fu_132065_p2() {
    add_ln703_273_fu_132065_p2 = (!add_ln703_266_fu_132004_p2.read().is_01() || !sext_ln703_141_fu_132061_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_266_fu_132004_p2.read()) + sc_bigint<15>(sext_ln703_141_fu_132061_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_274_fu_138155_p2() {
    add_ln703_274_fu_138155_p2 = (!sext_ln203_38_fu_135275_p1.read().is_01() || !add_ln703_273_reg_144183.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_38_fu_135275_p1.read()) + sc_biguint<15>(add_ln703_273_reg_144183.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_275_fu_138160_p2() {
    add_ln703_275_fu_138160_p2 = (!zext_ln203_6_fu_135257_p1.read().is_01() || !sext_ln203_40_fu_135318_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_6_fu_135257_p1.read()) + sc_bigint<12>(sext_ln203_40_fu_135318_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_276_fu_138170_p2() {
    add_ln703_276_fu_138170_p2 = (!add_ln703_274_fu_138155_p2.read().is_01() || !sext_ln703_142_fu_138166_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_274_fu_138155_p2.read()) + sc_bigint<15>(sext_ln703_142_fu_138166_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_277_fu_138180_p2() {
    add_ln703_277_fu_138180_p2 = (!grp_fu_117234_p4.read().is_01() || !zext_ln203_7_fu_135271_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117234_p4.read()) + sc_biguint<10>(zext_ln203_7_fu_135271_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_278_fu_138190_p2() {
    add_ln703_278_fu_138190_p2 = (!sext_ln203_39_fu_135314_p1.read().is_01() || !sext_ln203_37_fu_135243_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_39_fu_135314_p1.read()) + sc_bigint<11>(sext_ln203_37_fu_135243_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_279_fu_138196_p2() {
    add_ln703_279_fu_138196_p2 = (!zext_ln708_55_fu_135322_p1.read().is_01() || !add_ln703_278_fu_138190_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_55_fu_135322_p1.read()) + sc_biguint<11>(add_ln703_278_fu_138190_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_280_fu_138206_p2() {
    add_ln703_280_fu_138206_p2 = (!zext_ln703_29_fu_138186_p1.read().is_01() || !sext_ln703_144_fu_138202_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_29_fu_138186_p1.read()) + sc_bigint<12>(sext_ln703_144_fu_138202_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_282_fu_124635_p2() {
    add_ln703_282_fu_124635_p2 = (!sext_ln203_41_fu_120373_p1.read().is_01() || !ap_const_lv12_CD8.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_41_fu_120373_p1.read()) + sc_bigint<12>(ap_const_lv12_CD8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_283_fu_124641_p2() {
    add_ln703_283_fu_124641_p2 = (!zext_ln1118_219_fu_120377_p1.read().is_01() || !add_ln703_282_fu_124635_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_219_fu_120377_p1.read()) + sc_biguint<12>(add_ln703_282_fu_124635_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_284_fu_119004_p2() {
    add_ln703_284_fu_119004_p2 = (!sext_ln1118_124_fu_118314_p1.read().is_01() || !sext_ln708_55_fu_118300_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_124_fu_118314_p1.read()) + sc_bigint<11>(sext_ln708_55_fu_118300_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_285_fu_124654_p2() {
    add_ln703_285_fu_124654_p2 = (!sext_ln703_146_fu_124647_p1.read().is_01() || !sext_ln703_147_fu_124651_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_146_fu_124647_p1.read()) + sc_bigint<13>(sext_ln703_147_fu_124651_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_286_fu_124664_p2() {
    add_ln703_286_fu_124664_p2 = (!sext_ln1118_126_fu_120411_p1.read().is_01() || !sext_ln1118_125_fu_120407_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_126_fu_120411_p1.read()) + sc_bigint<12>(sext_ln1118_125_fu_120407_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_287_fu_124674_p2() {
    add_ln703_287_fu_124674_p2 = (!sext_ln703_148_fu_124660_p1.read().is_01() || !sext_ln703_149_fu_124670_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_148_fu_124660_p1.read()) + sc_bigint<14>(sext_ln703_149_fu_124670_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_288_fu_124680_p2() {
    add_ln703_288_fu_124680_p2 = (!sext_ln1118_127_fu_120456_p1.read().is_01() || !zext_ln708_56_fu_120415_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_127_fu_120456_p1.read()) + sc_biguint<11>(zext_ln708_56_fu_120415_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_289_fu_124690_p2() {
    add_ln703_289_fu_124690_p2 = (!sext_ln708_56_fu_120498_p1.read().is_01() || !sext_ln703_150_fu_124686_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_56_fu_120498_p1.read()) + sc_bigint<12>(sext_ln703_150_fu_124686_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_290_fu_124700_p2() {
    add_ln703_290_fu_124700_p2 = (!add_ln703_287_fu_124674_p2.read().is_01() || !sext_ln703_151_fu_124696_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_287_fu_124674_p2.read()) + sc_bigint<14>(sext_ln703_151_fu_124696_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_291_fu_124706_p2() {
    add_ln703_291_fu_124706_p2 = (!zext_ln1118_225_fu_120524_p1.read().is_01() || !add_ln703_290_fu_124700_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_225_fu_120524_p1.read()) + sc_biguint<14>(add_ln703_290_fu_124700_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_292_fu_132074_p2() {
    add_ln703_292_fu_132074_p2 = (!sext_ln1118_132_fu_127726_p1.read().is_01() || !sext_ln1118_128_fu_127706_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_132_fu_127726_p1.read()) + sc_bigint<12>(sext_ln1118_128_fu_127706_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_293_fu_132084_p2() {
    add_ln703_293_fu_132084_p2 = (!sext_ln708_57_fu_127675_p1.read().is_01() || !sext_ln703_153_fu_132080_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln708_57_fu_127675_p1.read()) + sc_bigint<13>(sext_ln703_153_fu_132080_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_294_fu_132094_p2() {
    add_ln703_294_fu_132094_p2 = (!sext_ln703_152_fu_132071_p1.read().is_01() || !sext_ln703_154_fu_132090_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_152_fu_132071_p1.read()) + sc_bigint<15>(sext_ln703_154_fu_132090_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_295_fu_124712_p2() {
    add_ln703_295_fu_124712_p2 = (!trunc_ln1118_4_reg_142513.read().is_01() || !zext_ln1118_227_fu_120554_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_4_reg_142513.read()) + sc_biguint<10>(zext_ln1118_227_fu_120554_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_296_fu_124721_p2() {
    add_ln703_296_fu_124721_p2 = (!sext_ln1118_130_fu_120589_p1.read().is_01() || !sext_ln1118_131_fu_120593_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_130_fu_120589_p1.read()) + sc_bigint<11>(sext_ln1118_131_fu_120593_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_297_fu_124731_p2() {
    add_ln703_297_fu_124731_p2 = (!sext_ln1118_129_fu_120558_p1.read().is_01() || !sext_ln703_155_fu_124727_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_129_fu_120558_p1.read()) + sc_bigint<12>(sext_ln703_155_fu_124727_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_298_fu_124737_p2() {
    add_ln703_298_fu_124737_p2 = (!zext_ln703_30_fu_124717_p1.read().is_01() || !add_ln703_297_fu_124731_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_30_fu_124717_p1.read()) + sc_biguint<12>(add_ln703_297_fu_124731_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_299_fu_132103_p2() {
    add_ln703_299_fu_132103_p2 = (!add_ln703_294_fu_132094_p2.read().is_01() || !sext_ln703_156_fu_132100_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_294_fu_132094_p2.read()) + sc_bigint<15>(sext_ln703_156_fu_132100_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_300_fu_132109_p2() {
    add_ln703_300_fu_132109_p2 = (!sext_ln203_43_fu_127795_p1.read().is_01() || !sext_ln203_42_fu_127757_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_43_fu_127795_p1.read()) + sc_bigint<12>(sext_ln203_42_fu_127757_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_301_fu_132119_p2() {
    add_ln703_301_fu_132119_p2 = (!add_ln703_299_fu_132103_p2.read().is_01() || !sext_ln703_157_fu_132115_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_299_fu_132103_p2.read()) + sc_bigint<15>(sext_ln703_157_fu_132115_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_302_fu_132125_p2() {
    add_ln703_302_fu_132125_p2 = (!zext_ln203_8_fu_127761_p1.read().is_01() || !sext_ln203_44_fu_127894_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_8_fu_127761_p1.read()) + sc_bigint<12>(sext_ln203_44_fu_127894_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_303_fu_119010_p2() {
    add_ln703_303_fu_119010_p2 = (!zext_ln708_58_fu_118332_p1.read().is_01() || !zext_ln708_57_fu_118328_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_58_fu_118332_p1.read()) + sc_biguint<11>(zext_ln708_57_fu_118328_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_304_fu_132138_p2() {
    add_ln703_304_fu_132138_p2 = (!sext_ln703_158_fu_132131_p1.read().is_01() || !zext_ln703_31_fu_132135_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_158_fu_132131_p1.read()) + sc_biguint<13>(zext_ln703_31_fu_132135_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_305_fu_132148_p2() {
    add_ln703_305_fu_132148_p2 = (!add_ln703_301_fu_132119_p2.read().is_01() || !sext_ln703_159_fu_132144_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_301_fu_132119_p2.read()) + sc_bigint<15>(sext_ln703_159_fu_132144_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_306_fu_132154_p2() {
    add_ln703_306_fu_132154_p2 = (!zext_ln203_10_fu_127802_p1.read().is_01() || !zext_ln203_9_fu_127799_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_10_fu_127802_p1.read()) + sc_biguint<10>(zext_ln203_9_fu_127799_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_307_fu_138228_p2() {
    add_ln703_307_fu_138228_p2 = (!zext_ln203_11_fu_135350_p1.read().is_01() || !trunc_ln203_3_reg_142528.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_11_fu_135350_p1.read()) + sc_biguint<10>(trunc_ln203_3_reg_142528.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_308_fu_138237_p2() {
    add_ln703_308_fu_138237_p2 = (!zext_ln703_32_fu_138225_p1.read().is_01() || !zext_ln703_33_fu_138233_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_32_fu_138225_p1.read()) + sc_biguint<11>(zext_ln703_33_fu_138233_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_309_fu_132160_p2() {
    add_ln703_309_fu_132160_p2 = (!zext_ln203_12_fu_127863_p1.read().is_01() || !trunc_ln203_4_fu_127822_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_12_fu_127863_p1.read()) + sc_biguint<10>(trunc_ln203_4_fu_127822_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_310_fu_138250_p2() {
    add_ln703_310_fu_138250_p2 = (!zext_ln203_14_fu_135384_p1.read().is_01() || !zext_ln203_13_fu_135354_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_14_fu_135384_p1.read()) + sc_biguint<10>(zext_ln203_13_fu_135354_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_311_fu_138260_p2() {
    add_ln703_311_fu_138260_p2 = (!zext_ln703_35_fu_138247_p1.read().is_01() || !zext_ln703_36_fu_138256_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_35_fu_138247_p1.read()) + sc_biguint<11>(zext_ln703_36_fu_138256_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_312_fu_138270_p2() {
    add_ln703_312_fu_138270_p2 = (!zext_ln703_34_fu_138243_p1.read().is_01() || !zext_ln703_37_fu_138266_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_34_fu_138243_p1.read()) + sc_biguint<12>(zext_ln703_37_fu_138266_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_314_fu_124743_p2() {
    add_ln703_314_fu_124743_p2 = (!zext_ln203_15_fu_120622_p1.read().is_01() || !sext_ln203_41_fu_120373_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_15_fu_120622_p1.read()) + sc_bigint<12>(sext_ln203_41_fu_120373_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_315_fu_124749_p2() {
    add_ln703_315_fu_124749_p2 = (!zext_ln1118_239_fu_120618_p1.read().is_01() || !ap_const_lv10_268.is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_239_fu_120618_p1.read()) + sc_bigint<10>(ap_const_lv10_268));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_316_fu_124759_p2() {
    add_ln703_316_fu_124759_p2 = (!add_ln703_314_fu_124743_p2.read().is_01() || !sext_ln703_161_fu_124755_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_314_fu_124743_p2.read()) + sc_bigint<12>(sext_ln703_161_fu_124755_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_317_fu_124769_p2() {
    add_ln703_317_fu_124769_p2 = (!sext_ln708_58_fu_120671_p1.read().is_01() || !zext_ln1118_240_fu_120647_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_58_fu_120671_p1.read()) + sc_biguint<12>(zext_ln1118_240_fu_120647_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_318_fu_124779_p2() {
    add_ln703_318_fu_124779_p2 = (!sext_ln703_162_fu_124765_p1.read().is_01() || !sext_ln703_163_fu_124775_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_162_fu_124765_p1.read()) + sc_bigint<13>(sext_ln703_163_fu_124775_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_319_fu_124789_p2() {
    add_ln703_319_fu_124789_p2 = (!zext_ln203_16_fu_120697_p1.read().is_01() || !sext_ln703_164_fu_124785_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln203_16_fu_120697_p1.read()) + sc_bigint<14>(sext_ln703_164_fu_124785_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_320_fu_124795_p2() {
    add_ln703_320_fu_124795_p2 = (!zext_ln1118_245_fu_120724_p1.read().is_01() || !sext_ln1118_133_fu_120701_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_245_fu_120724_p1.read()) + sc_bigint<12>(sext_ln1118_133_fu_120701_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_321_fu_124805_p2() {
    add_ln703_321_fu_124805_p2 = (!add_ln703_319_fu_124789_p2.read().is_01() || !sext_ln703_165_fu_124801_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_319_fu_124789_p2.read()) + sc_bigint<14>(sext_ln703_165_fu_124801_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_322_fu_119016_p2() {
    add_ln703_322_fu_119016_p2 = (!zext_ln1118_247_fu_118428_p1.read().is_01() || !zext_ln1118_246_fu_118414_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_247_fu_118428_p1.read()) + sc_biguint<10>(zext_ln1118_246_fu_118414_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_323_fu_119026_p2() {
    add_ln703_323_fu_119026_p2 = (!zext_ln1118_242_fu_118356_p1.read().is_01() || !sext_ln1118_134_fu_118400_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_242_fu_118356_p1.read()) + sc_bigint<9>(sext_ln1118_134_fu_118400_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_324_fu_119036_p2() {
    add_ln703_324_fu_119036_p2 = (!zext_ln1118_248_fu_118442_p1.read().is_01() || !sext_ln703_166_fu_119032_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_248_fu_118442_p1.read()) + sc_bigint<10>(sext_ln703_166_fu_119032_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_325_fu_119046_p2() {
    add_ln703_325_fu_119046_p2 = (!zext_ln703_39_fu_119022_p1.read().is_01() || !sext_ln703_167_fu_119042_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_39_fu_119022_p1.read()) + sc_bigint<12>(sext_ln703_167_fu_119042_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_326_fu_124814_p2() {
    add_ln703_326_fu_124814_p2 = (!add_ln703_321_fu_124805_p2.read().is_01() || !sext_ln703_168_fu_124811_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_321_fu_124805_p2.read()) + sc_bigint<14>(sext_ln703_168_fu_124811_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_327_fu_132169_p2() {
    add_ln703_327_fu_132169_p2 = (!sext_ln1118_120_fu_127551_p1.read().is_01() || !sext_ln1118_135_fu_127898_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_120_fu_127551_p1.read()) + sc_bigint<12>(sext_ln1118_135_fu_127898_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_328_fu_132179_p2() {
    add_ln703_328_fu_132179_p2 = (!sext_ln703_169_fu_132166_p1.read().is_01() || !sext_ln703_170_fu_132175_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_169_fu_132166_p1.read()) + sc_bigint<15>(sext_ln703_170_fu_132175_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_329_fu_138286_p2() {
    add_ln703_329_fu_138286_p2 = (!zext_ln1118_249_fu_135388_p1.read().is_01() || !sext_ln1118_137_fu_135392_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_249_fu_135388_p1.read()) + sc_bigint<12>(sext_ln1118_137_fu_135392_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_330_fu_132185_p2() {
    add_ln703_330_fu_132185_p2 = (!zext_ln1118_132_fu_126926_p1.read().is_01() || !trunc_ln1118_5_fu_127910_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_132_fu_126926_p1.read()) + sc_biguint<9>(trunc_ln1118_5_fu_127910_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_331_fu_138295_p2() {
    add_ln703_331_fu_138295_p2 = (!add_ln703_329_fu_138286_p2.read().is_01() || !zext_ln703_40_fu_138292_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_329_fu_138286_p2.read()) + sc_biguint<12>(zext_ln703_40_fu_138292_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_332_fu_138305_p2() {
    add_ln703_332_fu_138305_p2 = (!add_ln703_328_reg_144203.read().is_01() || !sext_ln703_171_fu_138301_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_328_reg_144203.read()) + sc_bigint<15>(sext_ln703_171_fu_138301_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_333_fu_124820_p2() {
    add_ln703_333_fu_124820_p2 = (!zext_ln708_62_fu_120789_p1.read().is_01() || !trunc_ln1118_6_reg_142564.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_62_fu_120789_p1.read()) + sc_biguint<10>(trunc_ln1118_6_reg_142564.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_334_fu_124829_p2() {
    add_ln703_334_fu_124829_p2 = (!zext_ln1118_255_fu_120831_p1.read().is_01() || !trunc_ln1118_7_reg_142569.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_255_fu_120831_p1.read()) + sc_biguint<10>(trunc_ln1118_7_reg_142569.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_335_fu_124838_p2() {
    add_ln703_335_fu_124838_p2 = (!zext_ln703_41_fu_124825_p1.read().is_01() || !zext_ln703_42_fu_124834_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_41_fu_124825_p1.read()) + sc_biguint<11>(zext_ln703_42_fu_124834_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_336_fu_119052_p2() {
    add_ln703_336_fu_119052_p2 = (!sext_ln1118_136_fu_118446_p1.read().is_01() || !zext_ln708_63_fu_118480_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_136_fu_118446_p1.read()) + sc_biguint<11>(zext_ln708_63_fu_118480_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_337_fu_124851_p2() {
    add_ln703_337_fu_124851_p2 = (!zext_ln708_61_fu_120759_p1.read().is_01() || !sext_ln708_59_fu_120755_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_61_fu_120759_p1.read()) + sc_bigint<10>(sext_ln708_59_fu_120755_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_338_fu_124861_p2() {
    add_ln703_338_fu_124861_p2 = (!sext_ln703_172_fu_124848_p1.read().is_01() || !sext_ln703_173_fu_124857_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_172_fu_124848_p1.read()) + sc_bigint<12>(sext_ln703_173_fu_124857_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_339_fu_124871_p2() {
    add_ln703_339_fu_124871_p2 = (!zext_ln703_43_fu_124844_p1.read().is_01() || !sext_ln703_174_fu_124867_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_43_fu_124844_p1.read()) + sc_bigint<13>(sext_ln703_174_fu_124867_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_340_fu_138313_p2() {
    add_ln703_340_fu_138313_p2 = (!add_ln703_332_fu_138305_p2.read().is_01() || !sext_ln703_175_fu_138310_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_332_fu_138305_p2.read()) + sc_bigint<15>(sext_ln703_175_fu_138310_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_341_fu_138319_p2() {
    add_ln703_341_fu_138319_p2 = (!sext_ln203_47_fu_135477_p1.read().is_01() || !zext_ln203_17_fu_135422_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_47_fu_135477_p1.read()) + sc_biguint<12>(zext_ln203_17_fu_135422_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_342_fu_138329_p2() {
    add_ln703_342_fu_138329_p2 = (!add_ln703_340_fu_138313_p2.read().is_01() || !sext_ln703_176_fu_138325_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_340_fu_138313_p2.read()) + sc_bigint<15>(sext_ln703_176_fu_138325_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_343_fu_138335_p2() {
    add_ln703_343_fu_138335_p2 = (!sext_ln203_45_fu_135442_p1.read().is_01() || !sext_ln203_46_fu_135473_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_45_fu_135442_p1.read()) + sc_bigint<10>(sext_ln203_46_fu_135473_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_344_fu_138345_p2() {
    add_ln703_344_fu_138345_p2 = (!sext_ln203_16_fu_134902_p1.read().is_01() || !sext_ln703_177_fu_138341_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_16_fu_134902_p1.read()) + sc_bigint<11>(sext_ln703_177_fu_138341_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_346_fu_124877_p2() {
    add_ln703_346_fu_124877_p2 = (!trunc_ln708_986_reg_142580.read().is_01() || !ap_const_lv9_38.is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln708_986_reg_142580.read()) + sc_biguint<9>(ap_const_lv9_38));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_347_fu_124886_p2() {
    add_ln703_347_fu_124886_p2 = (!sext_ln203_17_fu_119835_p1.read().is_01() || !zext_ln703_44_fu_124882_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_17_fu_119835_p1.read()) + sc_biguint<12>(zext_ln703_44_fu_124882_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_348_fu_124896_p2() {
    add_ln703_348_fu_124896_p2 = (!sext_ln1116_14_fu_120845_p1.read().is_01() || !sext_ln1116_13_fu_120842_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_14_fu_120845_p1.read()) + sc_bigint<11>(sext_ln1116_13_fu_120842_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_349_fu_124906_p2() {
    add_ln703_349_fu_124906_p2 = (!sext_ln703_178_fu_124892_p1.read().is_01() || !sext_ln703_181_fu_124902_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_178_fu_124892_p1.read()) + sc_bigint<13>(sext_ln703_181_fu_124902_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_350_fu_124912_p2() {
    add_ln703_350_fu_124912_p2 = (!sext_ln1116_15_fu_120848_p1.read().is_01() || !add_ln703_349_fu_124906_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_15_fu_120848_p1.read()) + sc_biguint<13>(add_ln703_349_fu_124906_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_351_fu_124922_p2() {
    add_ln703_351_fu_124922_p2 = (!zext_ln708_65_fu_120894_p1.read().is_01() || !sext_ln708_60_fu_120928_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_65_fu_120894_p1.read()) + sc_bigint<12>(sext_ln708_60_fu_120928_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_352_fu_124932_p2() {
    add_ln703_352_fu_124932_p2 = (!sext_ln703_186_fu_124918_p1.read().is_01() || !sext_ln703_187_fu_124928_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_186_fu_124918_p1.read()) + sc_bigint<14>(sext_ln703_187_fu_124928_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_353_fu_124938_p2() {
    add_ln703_353_fu_124938_p2 = (!zext_ln1116_29_fu_120921_p1.read().is_01() || !zext_ln1116_28_fu_120913_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_29_fu_120921_p1.read()) + sc_biguint<10>(zext_ln1116_28_fu_120913_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_354_fu_124948_p2() {
    add_ln703_354_fu_124948_p2 = (!zext_ln1118_26_fu_119240_p1.read().is_01() || !sext_ln1118_139_fu_120917_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_26_fu_119240_p1.read()) + sc_bigint<10>(sext_ln1118_139_fu_120917_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_355_fu_124958_p2() {
    add_ln703_355_fu_124958_p2 = (!zext_ln703_45_fu_124944_p1.read().is_01() || !sext_ln703_191_fu_124954_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_45_fu_124944_p1.read()) + sc_bigint<12>(sext_ln703_191_fu_124954_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_356_fu_132194_p2() {
    add_ln703_356_fu_132194_p2 = (!add_ln703_352_reg_143556.read().is_01() || !sext_ln703_194_fu_132191_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_352_reg_143556.read()) + sc_bigint<14>(sext_ln703_194_fu_132191_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_357_fu_132199_p2() {
    add_ln703_357_fu_132199_p2 = (!sext_ln1118_140_fu_127947_p1.read().is_01() || !add_ln703_356_fu_132194_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_140_fu_127947_p1.read()) + sc_biguint<14>(add_ln703_356_fu_132194_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_358_fu_119058_p2() {
    add_ln703_358_fu_119058_p2 = (!sext_ln1116_18_fu_118583_p1.read().is_01() || !sext_ln1116_17_fu_118569_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_18_fu_118583_p1.read()) + sc_bigint<12>(sext_ln1116_17_fu_118569_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_359_fu_132212_p2() {
    add_ln703_359_fu_132212_p2 = (!sext_ln1116_16_fu_127966_p1.read().is_01() || !sext_ln703_196_fu_132209_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_16_fu_127966_p1.read()) + sc_bigint<13>(sext_ln703_196_fu_132209_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_360_fu_132222_p2() {
    add_ln703_360_fu_132222_p2 = (!sext_ln703_195_fu_132205_p1.read().is_01() || !sext_ln703_197_fu_132218_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_195_fu_132205_p1.read()) + sc_bigint<15>(sext_ln703_197_fu_132218_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_361_fu_119064_p2() {
    add_ln703_361_fu_119064_p2 = (!sext_ln1116_19_fu_118587_p1.read().is_01() || !zext_ln708_66_fu_118565_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_19_fu_118587_p1.read()) + sc_biguint<11>(zext_ln708_66_fu_118565_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_362_fu_132231_p2() {
    add_ln703_362_fu_132231_p2 = (!sext_ln1116_20_fu_128015_p1.read().is_01() || !sext_ln703_198_fu_132228_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_20_fu_128015_p1.read()) + sc_bigint<12>(sext_ln703_198_fu_132228_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_363_fu_124964_p2() {
    add_ln703_363_fu_124964_p2 = (!zext_ln1116_31_fu_120981_p1.read().is_01() || !sext_ln708_61_fu_120977_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1116_31_fu_120981_p1.read()) + sc_bigint<9>(sext_ln708_61_fu_120977_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_364_fu_132244_p2() {
    add_ln703_364_fu_132244_p2 = (!sext_ln1118_142_fu_127990_p1.read().is_01() || !sext_ln703_200_fu_132241_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_142_fu_127990_p1.read()) + sc_bigint<10>(sext_ln703_200_fu_132241_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_365_fu_132254_p2() {
    add_ln703_365_fu_132254_p2 = (!sext_ln703_199_fu_132237_p1.read().is_01() || !sext_ln703_201_fu_132250_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_199_fu_132237_p1.read()) + sc_bigint<13>(sext_ln703_201_fu_132250_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_366_fu_138368_p2() {
    add_ln703_366_fu_138368_p2 = (!add_ln703_360_reg_144213.read().is_01() || !sext_ln703_202_fu_138365_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_360_reg_144213.read()) + sc_bigint<15>(sext_ln703_202_fu_138365_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_367_fu_138373_p2() {
    add_ln703_367_fu_138373_p2 = (!sext_ln203_51_fu_135530_p1.read().is_01() || !sext_ln203_49_fu_135488_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_51_fu_135530_p1.read()) + sc_bigint<12>(sext_ln203_49_fu_135488_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_368_fu_138383_p2() {
    add_ln703_368_fu_138383_p2 = (!add_ln703_366_fu_138368_p2.read().is_01() || !sext_ln703_205_fu_138379_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_366_fu_138368_p2.read()) + sc_bigint<15>(sext_ln703_205_fu_138379_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_369_fu_138393_p2() {
    add_ln703_369_fu_138393_p2 = (!zext_ln203_18_fu_135484_p1.read().is_01() || !sext_ln203_56_fu_135597_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_18_fu_135484_p1.read()) + sc_bigint<12>(sext_ln203_56_fu_135597_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_370_fu_138403_p2() {
    add_ln703_370_fu_138403_p2 = (!sext_ln203_53_fu_135544_p1.read().is_01() || !sext_ln703_210_fu_138399_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_53_fu_135544_p1.read()) + sc_bigint<13>(sext_ln703_210_fu_138399_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_371_fu_138413_p2() {
    add_ln703_371_fu_138413_p2 = (!sext_ln703_206_fu_138389_p1.read().is_01() || !sext_ln703_214_fu_138409_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_206_fu_138389_p1.read()) + sc_bigint<16>(sext_ln703_214_fu_138409_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_372_fu_138419_p2() {
    add_ln703_372_fu_138419_p2 = (!sext_ln203_48_fu_135481_p1.read().is_01() || !zext_ln708_67_fu_135601_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_48_fu_135481_p1.read()) + sc_biguint<11>(zext_ln708_67_fu_135601_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_373_fu_138429_p2() {
    add_ln703_373_fu_138429_p2 = (!zext_ln203_19_fu_135578_p1.read().is_01() || !sext_ln703_215_fu_138425_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_19_fu_135578_p1.read()) + sc_bigint<12>(sext_ln703_215_fu_138425_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_374_fu_132260_p2() {
    add_ln703_374_fu_132260_p2 = (!sext_ln203_52_fu_128022_p1.read().is_01() || !sext_ln203_55_fu_128025_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_52_fu_128022_p1.read()) + sc_bigint<10>(sext_ln203_55_fu_128025_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_375_fu_138442_p2() {
    add_ln703_375_fu_138442_p2 = (!sext_ln203_54_fu_135548_p1.read().is_01() || !sext_ln703_217_fu_138439_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_54_fu_135548_p1.read()) + sc_bigint<11>(sext_ln703_217_fu_138439_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_376_fu_138452_p2() {
    add_ln703_376_fu_138452_p2 = (!sext_ln703_216_fu_138435_p1.read().is_01() || !sext_ln703_218_fu_138448_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_216_fu_138435_p1.read()) + sc_bigint<13>(sext_ln703_218_fu_138448_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_378_fu_124970_p2() {
    add_ln703_378_fu_124970_p2 = (!trunc_ln203_5_reg_142670.read().is_01() || !ap_const_lv9_118.is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln203_5_reg_142670.read()) + sc_bigint<9>(ap_const_lv9_118));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_379_fu_124975_p2() {
    add_ln703_379_fu_124975_p2 = (!zext_ln203_20_fu_121012_p1.read().is_01() || !add_ln703_378_fu_124970_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_20_fu_121012_p1.read()) + sc_biguint<9>(add_ln703_378_fu_124970_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_380_fu_124985_p2() {
    add_ln703_380_fu_124985_p2 = (!sext_ln703_182_fu_124981_p1.read().is_01() || !zext_ln708_68_fu_121042_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_182_fu_124981_p1.read()) + sc_biguint<11>(zext_ln708_68_fu_121042_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_381_fu_124995_p2() {
    add_ln703_381_fu_124995_p2 = (!zext_ln203_21_fu_121046_p1.read().is_01() || !sext_ln703_183_fu_124991_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_21_fu_121046_p1.read()) + sc_bigint<12>(sext_ln703_183_fu_124991_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_382_fu_125005_p2() {
    add_ln703_382_fu_125005_p2 = (!sext_ln203_57_fu_121083_p1.read().is_01() || !sext_ln703_184_fu_125001_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_57_fu_121083_p1.read()) + sc_bigint<13>(sext_ln703_184_fu_125001_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_383_fu_125011_p2() {
    add_ln703_383_fu_125011_p2 = (!trunc_ln1118_8_reg_142681.read().is_01() || !zext_ln708_69_fu_121114_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_8_reg_142681.read()) + sc_biguint<10>(zext_ln708_69_fu_121114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_384_fu_125020_p2() {
    add_ln703_384_fu_125020_p2 = (!sext_ln1118_144_fu_121118_p1.read().is_01() || !zext_ln703_46_fu_125016_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_144_fu_121118_p1.read()) + sc_biguint<12>(zext_ln703_46_fu_125016_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_385_fu_125030_p2() {
    add_ln703_385_fu_125030_p2 = (!add_ln703_382_fu_125005_p2.read().is_01() || !sext_ln703_220_fu_125026_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_382_fu_125005_p2.read()) + sc_bigint<13>(sext_ln703_220_fu_125026_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_386_fu_125040_p2() {
    add_ln703_386_fu_125040_p2 = (!sext_ln203_58_fu_121140_p1.read().is_01() || !sext_ln703_185_fu_125036_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_58_fu_121140_p1.read()) + sc_bigint<14>(sext_ln703_185_fu_125036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_387_fu_125046_p2() {
    add_ln703_387_fu_125046_p2 = (!sext_ln1118_145_fu_121136_p1.read().is_01() || !sext_ln1118_147_fu_121173_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_145_fu_121136_p1.read()) + sc_bigint<11>(sext_ln1118_147_fu_121173_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_388_fu_125056_p2() {
    add_ln703_388_fu_125056_p2 = (!sext_ln1118_148_fu_121177_p1.read().is_01() || !sext_ln703_221_fu_125052_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_148_fu_121177_p1.read()) + sc_bigint<12>(sext_ln703_221_fu_125052_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_389_fu_132269_p2() {
    add_ln703_389_fu_132269_p2 = (!add_ln703_386_reg_143571.read().is_01() || !sext_ln703_222_fu_132266_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_386_reg_143571.read()) + sc_bigint<14>(sext_ln703_222_fu_132266_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_390_fu_132274_p2() {
    add_ln703_390_fu_132274_p2 = (!zext_ln1118_285_fu_128028_p1.read().is_01() || !add_ln703_389_fu_132269_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_285_fu_128028_p1.read()) + sc_biguint<14>(add_ln703_389_fu_132269_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_391_fu_132284_p2() {
    add_ln703_391_fu_132284_p2 = (!zext_ln1118_287_fu_128061_p1.read().is_01() || !sext_ln1118_152_fu_128087_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_287_fu_128061_p1.read()) + sc_bigint<12>(sext_ln1118_152_fu_128087_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_392_fu_132294_p2() {
    add_ln703_392_fu_132294_p2 = (!sext_ln1116_7_fu_126464_p1.read().is_01() || !sext_ln703_224_fu_132290_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_7_fu_126464_p1.read()) + sc_bigint<13>(sext_ln703_224_fu_132290_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_393_fu_132304_p2() {
    add_ln703_393_fu_132304_p2 = (!sext_ln703_223_fu_132280_p1.read().is_01() || !sext_ln703_225_fu_132300_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_223_fu_132280_p1.read()) + sc_bigint<15>(sext_ln703_225_fu_132300_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_394_fu_132310_p2() {
    add_ln703_394_fu_132310_p2 = (!zext_ln1118_289_fu_128090_p1.read().is_01() || !zext_ln1118_288_fu_128083_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_289_fu_128090_p1.read()) + sc_biguint<10>(zext_ln1118_288_fu_128083_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_395_fu_132320_p2() {
    add_ln703_395_fu_132320_p2 = (!zext_ln708_70_fu_128064_p1.read().is_01() || !zext_ln703_47_fu_132316_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_70_fu_128064_p1.read()) + sc_biguint<11>(zext_ln703_47_fu_132316_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_396_fu_125062_p2() {
    add_ln703_396_fu_125062_p2 = (!sext_ln1118_149_fu_121196_p1.read().is_01() || !sext_ln1118_151_fu_121200_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_149_fu_121196_p1.read()) + sc_bigint<11>(sext_ln1118_151_fu_121200_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_397_fu_132333_p2() {
    add_ln703_397_fu_132333_p2 = (!sext_ln1118_150_fu_128057_p1.read().is_01() || !sext_ln703_226_fu_132330_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_150_fu_128057_p1.read()) + sc_bigint<12>(sext_ln703_226_fu_132330_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_398_fu_132343_p2() {
    add_ln703_398_fu_132343_p2 = (!zext_ln703_48_fu_132326_p1.read().is_01() || !sext_ln703_229_fu_132339_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_48_fu_132326_p1.read()) + sc_bigint<13>(sext_ln703_229_fu_132339_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_399_fu_132353_p2() {
    add_ln703_399_fu_132353_p2 = (!add_ln703_393_fu_132304_p2.read().is_01() || !sext_ln703_230_fu_132349_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_393_fu_132304_p2.read()) + sc_bigint<15>(sext_ln703_230_fu_132349_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_400_fu_138468_p2() {
    add_ln703_400_fu_138468_p2 = (!sext_ln203_59_fu_135614_p1.read().is_01() || !add_ln703_399_reg_144228.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_59_fu_135614_p1.read()) + sc_biguint<15>(add_ln703_399_reg_144228.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_401_fu_119070_p2() {
    add_ln703_401_fu_119070_p2 = (!grp_fu_117184_p4.read().is_01() || !zext_ln203_22_fu_118636_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117184_p4.read()) + sc_biguint<10>(zext_ln203_22_fu_118636_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_402_fu_138476_p2() {
    add_ln703_402_fu_138476_p2 = (!sext_ln203_65_fu_135732_p1.read().is_01() || !zext_ln703_49_fu_138473_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_65_fu_135732_p1.read()) + sc_biguint<12>(zext_ln703_49_fu_138473_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_403_fu_138486_p2() {
    add_ln703_403_fu_138486_p2 = (!add_ln703_400_fu_138468_p2.read().is_01() || !sext_ln703_231_fu_138482_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_400_fu_138468_p2.read()) + sc_bigint<15>(sext_ln703_231_fu_138482_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_404_fu_138496_p2() {
    add_ln703_404_fu_138496_p2 = (!sext_ln203_64_fu_135688_p1.read().is_01() || !sext_ln203_62_fu_135681_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_64_fu_135688_p1.read()) + sc_bigint<11>(sext_ln203_62_fu_135681_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_405_fu_138506_p2() {
    add_ln703_405_fu_138506_p2 = (!zext_ln203_23_fu_135766_p1.read().is_01() || !sext_ln703_235_fu_138502_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_23_fu_135766_p1.read()) + sc_bigint<12>(sext_ln703_235_fu_138502_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_406_fu_138512_p2() {
    add_ln703_406_fu_138512_p2 = (!sext_ln203_61_fu_135648_p1.read().is_01() || !sext_ln203_60_fu_135618_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_61_fu_135648_p1.read()) + sc_bigint<9>(sext_ln203_60_fu_135618_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_407_fu_138522_p2() {
    add_ln703_407_fu_138522_p2 = (!sext_ln203_66_fu_135762_p1.read().is_01() || !sext_ln703_239_fu_138518_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_66_fu_135762_p1.read()) + sc_bigint<10>(sext_ln703_239_fu_138518_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_408_fu_138532_p2() {
    add_ln703_408_fu_138532_p2 = (!add_ln703_405_fu_138506_p2.read().is_01() || !sext_ln703_240_fu_138528_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_405_fu_138506_p2.read()) + sc_bigint<12>(sext_ln703_240_fu_138528_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_410_fu_125068_p2() {
    add_ln703_410_fu_125068_p2 = (!trunc_ln1118_9_fu_121223_p4.read().is_01() || !ap_const_lv10_2B0.is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_9_fu_121223_p4.read()) + sc_bigint<10>(ap_const_lv10_2B0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_411_fu_125078_p2() {
    add_ln703_411_fu_125078_p2 = (!sext_ln203_41_fu_120373_p1.read().is_01() || !sext_ln703_244_fu_125074_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_41_fu_120373_p1.read()) + sc_bigint<12>(sext_ln703_244_fu_125074_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_412_fu_125088_p2() {
    add_ln703_412_fu_125088_p2 = (!sext_ln1118_157_fu_121270_p1.read().is_01() || !sext_ln1118_158_fu_121298_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_157_fu_121270_p1.read()) + sc_bigint<12>(sext_ln1118_158_fu_121298_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_413_fu_125098_p2() {
    add_ln703_413_fu_125098_p2 = (!sext_ln703_188_fu_125084_p1.read().is_01() || !sext_ln703_245_fu_125094_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_188_fu_125084_p1.read()) + sc_bigint<13>(sext_ln703_245_fu_125094_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_414_fu_125108_p2() {
    add_ln703_414_fu_125108_p2 = (!sext_ln1118_160_fu_121325_p1.read().is_01() || !sext_ln1118_159_fu_121302_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_160_fu_121325_p1.read()) + sc_bigint<12>(sext_ln1118_159_fu_121302_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_415_fu_125118_p2() {
    add_ln703_415_fu_125118_p2 = (!sext_ln703_189_fu_125104_p1.read().is_01() || !sext_ln703_246_fu_125114_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_189_fu_125104_p1.read()) + sc_bigint<14>(sext_ln703_246_fu_125114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_416_fu_125124_p2() {
    add_ln703_416_fu_125124_p2 = (!zext_ln1118_301_fu_121329_p1.read().is_01() || !sext_ln1118_91_fu_119943_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_301_fu_121329_p1.read()) + sc_bigint<12>(sext_ln1118_91_fu_119943_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_417_fu_125134_p2() {
    add_ln703_417_fu_125134_p2 = (!sext_ln708_62_fu_121336_p1.read().is_01() || !zext_ln708_73_fu_121332_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_62_fu_121336_p1.read()) + sc_biguint<11>(zext_ln708_73_fu_121332_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_418_fu_125144_p2() {
    add_ln703_418_fu_125144_p2 = (!sext_ln703_247_fu_125130_p1.read().is_01() || !sext_ln703_248_fu_125140_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_247_fu_125130_p1.read()) + sc_bigint<13>(sext_ln703_248_fu_125140_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_419_fu_125154_p2() {
    add_ln703_419_fu_125154_p2 = (!add_ln703_415_fu_125118_p2.read().is_01() || !sext_ln703_249_fu_125150_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_415_fu_125118_p2.read()) + sc_bigint<14>(sext_ln703_249_fu_125150_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_420_fu_138551_p2() {
    add_ln703_420_fu_138551_p2 = (!sext_ln1118_161_fu_135787_p1.read().is_01() || !zext_ln1118_302_fu_135780_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_161_fu_135787_p1.read()) + sc_biguint<12>(zext_ln1118_302_fu_135780_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_421_fu_138561_p2() {
    add_ln703_421_fu_138561_p2 = (!sext_ln703_190_fu_138548_p1.read().is_01() || !sext_ln703_252_fu_138557_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_190_fu_138548_p1.read()) + sc_bigint<15>(sext_ln703_252_fu_138557_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_422_fu_138567_p2() {
    add_ln703_422_fu_138567_p2 = (!zext_ln1118_303_fu_135784_p1.read().is_01() || !sext_ln1118_166_fu_135821_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_303_fu_135784_p1.read()) + sc_bigint<12>(sext_ln1118_166_fu_135821_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_423_fu_138577_p2() {
    add_ln703_423_fu_138577_p2 = (!sext_ln1118_162_fu_135791_p1.read().is_01() || !sext_ln703_253_fu_138573_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_162_fu_135791_p1.read()) + sc_bigint<13>(sext_ln703_253_fu_138573_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_424_fu_138587_p2() {
    add_ln703_424_fu_138587_p2 = (!add_ln703_421_fu_138561_p2.read().is_01() || !sext_ln703_256_fu_138583_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_421_fu_138561_p2.read()) + sc_bigint<15>(sext_ln703_256_fu_138583_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_425_fu_125160_p2() {
    add_ln703_425_fu_125160_p2 = (!zext_ln1118_306_fu_121371_p1.read().is_01() || !zext_ln1118_305_fu_121367_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_306_fu_121371_p1.read()) + sc_biguint<9>(zext_ln1118_305_fu_121367_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_426_fu_125170_p2() {
    add_ln703_426_fu_125170_p2 = (!zext_ln1118_304_fu_121340_p1.read().is_01() || !zext_ln703_50_fu_125166_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_304_fu_121340_p1.read()) + sc_biguint<10>(zext_ln703_50_fu_125166_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_427_fu_132362_p2() {
    add_ln703_427_fu_132362_p2 = (!zext_ln1118_310_fu_128194_p1.read().is_01() || !zext_ln1118_307_fu_128127_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_310_fu_128194_p1.read()) + sc_biguint<10>(zext_ln1118_307_fu_128127_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_428_fu_132372_p2() {
    add_ln703_428_fu_132372_p2 = (!sext_ln1118_165_fu_128170_p1.read().is_01() || !sext_ln1118_163_fu_128130_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_165_fu_128170_p1.read()) + sc_bigint<11>(sext_ln1118_163_fu_128130_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_429_fu_132382_p2() {
    add_ln703_429_fu_132382_p2 = (!zext_ln703_52_fu_132368_p1.read().is_01() || !sext_ln703_257_fu_132378_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_52_fu_132368_p1.read()) + sc_bigint<12>(sext_ln703_257_fu_132378_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_430_fu_132388_p2() {
    add_ln703_430_fu_132388_p2 = (!zext_ln703_51_fu_132359_p1.read().is_01() || !add_ln703_429_fu_132382_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_51_fu_132359_p1.read()) + sc_biguint<12>(add_ln703_429_fu_132382_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_431_fu_138596_p2() {
    add_ln703_431_fu_138596_p2 = (!add_ln703_424_fu_138587_p2.read().is_01() || !sext_ln703_260_fu_138593_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_424_fu_138587_p2.read()) + sc_bigint<15>(sext_ln703_260_fu_138593_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_432_fu_138602_p2() {
    add_ln703_432_fu_138602_p2 = (!sext_ln203_67_fu_135835_p1.read().is_01() || !add_ln703_431_fu_138596_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_67_fu_135835_p1.read()) + sc_biguint<15>(add_ln703_431_fu_138596_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_433_fu_138612_p2() {
    add_ln703_433_fu_138612_p2 = (!zext_ln203_24_fu_135839_p1.read().is_01() || !sext_ln203_72_fu_135947_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_24_fu_135839_p1.read()) + sc_bigint<12>(sext_ln203_72_fu_135947_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_434_fu_138622_p2() {
    add_ln703_434_fu_138622_p2 = (!sext_ln203_68_fu_135853_p1.read().is_01() || !sext_ln703_262_fu_138618_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_68_fu_135853_p1.read()) + sc_bigint<13>(sext_ln703_262_fu_138618_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_435_fu_138632_p2() {
    add_ln703_435_fu_138632_p2 = (!sext_ln703_261_fu_138608_p1.read().is_01() || !sext_ln703_263_fu_138628_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_261_fu_138608_p1.read()) + sc_bigint<16>(sext_ln703_263_fu_138628_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_436_fu_138638_p2() {
    add_ln703_436_fu_138638_p2 = (!zext_ln708_76_fu_135967_p1.read().is_01() || !zext_ln708_75_fu_135885_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_76_fu_135967_p1.read()) + sc_biguint<11>(zext_ln708_75_fu_135885_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_437_fu_138644_p2() {
    add_ln703_437_fu_138644_p2 = (!zext_ln708_74_fu_135881_p1.read().is_01() || !add_ln703_436_fu_138638_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_74_fu_135881_p1.read()) + sc_biguint<11>(add_ln703_436_fu_138638_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_438_fu_138654_p2() {
    add_ln703_438_fu_138654_p2 = (!sext_ln203_70_fu_135909_p1.read().is_01() || !sext_ln203_69_fu_135877_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_70_fu_135909_p1.read()) + sc_bigint<8>(sext_ln203_69_fu_135877_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_439_fu_138664_p2() {
    add_ln703_439_fu_138664_p2 = (!sext_ln203_71_fu_135943_p1.read().is_01() || !sext_ln703_264_fu_138660_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_71_fu_135943_p1.read()) + sc_bigint<9>(sext_ln703_264_fu_138660_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_440_fu_138674_p2() {
    add_ln703_440_fu_138674_p2 = (!zext_ln703_53_fu_138650_p1.read().is_01() || !sext_ln703_265_fu_138670_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_53_fu_138650_p1.read()) + sc_bigint<12>(sext_ln703_265_fu_138670_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_442_fu_125176_p2() {
    add_ln703_442_fu_125176_p2 = (!zext_ln203_25_fu_121405_p1.read().is_01() || !sext_ln203_73_fu_121401_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_25_fu_121405_p1.read()) + sc_bigint<12>(sext_ln203_73_fu_121401_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_443_fu_125182_p2() {
    add_ln703_443_fu_125182_p2 = (!zext_ln708_77_fu_121432_p1.read().is_01() || !ap_const_lv11_760.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_77_fu_121432_p1.read()) + sc_bigint<11>(ap_const_lv11_760));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_444_fu_125192_p2() {
    add_ln703_444_fu_125192_p2 = (!add_ln703_442_fu_125176_p2.read().is_01() || !sext_ln703_269_fu_125188_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_442_fu_125176_p2.read()) + sc_bigint<12>(sext_ln703_269_fu_125188_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_445_fu_125202_p2() {
    add_ln703_445_fu_125202_p2 = (!sext_ln1118_168_fu_121467_p1.read().is_01() || !zext_ln1118_315_fu_121436_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_168_fu_121467_p1.read()) + sc_biguint<12>(zext_ln1118_315_fu_121436_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_446_fu_125212_p2() {
    add_ln703_446_fu_125212_p2 = (!sext_ln703_192_fu_125198_p1.read().is_01() || !sext_ln703_273_fu_125208_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_192_fu_125198_p1.read()) + sc_bigint<13>(sext_ln703_273_fu_125208_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_447_fu_125222_p2() {
    add_ln703_447_fu_125222_p2 = (!sext_ln1118_91_fu_119943_p1.read().is_01() || !sext_ln708_63_fu_121486_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_91_fu_119943_p1.read()) + sc_bigint<12>(sext_ln708_63_fu_121486_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_448_fu_125232_p2() {
    add_ln703_448_fu_125232_p2 = (!sext_ln703_193_fu_125218_p1.read().is_01() || !sext_ln703_274_fu_125228_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_193_fu_125218_p1.read()) + sc_bigint<14>(sext_ln703_274_fu_125228_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_449_fu_125238_p2() {
    add_ln703_449_fu_125238_p2 = (!sext_ln1118_170_fu_121530_p1.read().is_01() || !zext_ln708_78_fu_121544_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_170_fu_121530_p1.read()) + sc_biguint<11>(zext_ln708_78_fu_121544_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_450_fu_125244_p2() {
    add_ln703_450_fu_125244_p2 = (!zext_ln1118_317_fu_121490_p1.read().is_01() || !sext_ln1118_171_fu_121564_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_317_fu_121490_p1.read()) + sc_bigint<9>(sext_ln1118_171_fu_121564_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_451_fu_125254_p2() {
    add_ln703_451_fu_125254_p2 = (!add_ln703_449_fu_125238_p2.read().is_01() || !sext_ln703_275_fu_125250_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_449_fu_125238_p2.read()) + sc_bigint<11>(sext_ln703_275_fu_125250_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_452_fu_132397_p2() {
    add_ln703_452_fu_132397_p2 = (!add_ln703_448_reg_143596.read().is_01() || !sext_ln703_276_fu_132394_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_448_reg_143596.read()) + sc_bigint<14>(sext_ln703_276_fu_132394_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_453_fu_132402_p2() {
    add_ln703_453_fu_132402_p2 = (!sext_ln1118_172_fu_128204_p1.read().is_01() || !add_ln703_452_fu_132397_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_172_fu_128204_p1.read()) + sc_biguint<14>(add_ln703_452_fu_132397_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_454_fu_132412_p2() {
    add_ln703_454_fu_132412_p2 = (!zext_ln1118_320_fu_128233_p1.read().is_01() || !sext_ln1118_176_fu_128302_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_320_fu_128233_p1.read()) + sc_bigint<12>(sext_ln1118_176_fu_128302_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_455_fu_132422_p2() {
    add_ln703_455_fu_132422_p2 = (!sext_ln1118_175_fu_128298_p1.read().is_01() || !sext_ln703_278_fu_132418_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_175_fu_128298_p1.read()) + sc_bigint<13>(sext_ln703_278_fu_132418_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_456_fu_132432_p2() {
    add_ln703_456_fu_132432_p2 = (!sext_ln703_277_fu_132408_p1.read().is_01() || !sext_ln703_279_fu_132428_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_277_fu_132408_p1.read()) + sc_bigint<15>(sext_ln703_279_fu_132428_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_457_fu_132438_p2() {
    add_ln703_457_fu_132438_p2 = (!zext_ln1118_326_fu_128328_p1.read().is_01() || !trunc_ln1118_1_reg_143179.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_326_fu_128328_p1.read()) + sc_biguint<10>(trunc_ln1118_1_reg_143179.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_458_fu_132447_p2() {
    add_ln703_458_fu_132447_p2 = (!zext_ln708_79_fu_128275_p1.read().is_01() || !zext_ln703_54_fu_132443_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_79_fu_128275_p1.read()) + sc_biguint<11>(zext_ln703_54_fu_132443_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_459_fu_132457_p2() {
    add_ln703_459_fu_132457_p2 = (!sext_ln1118_177_fu_128352_p1.read().is_01() || !sext_ln1118_174_fu_128272_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_177_fu_128352_p1.read()) + sc_bigint<11>(sext_ln1118_174_fu_128272_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_460_fu_132467_p2() {
    add_ln703_460_fu_132467_p2 = (!sext_ln1118_173_fu_128268_p1.read().is_01() || !sext_ln703_280_fu_132463_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_173_fu_128268_p1.read()) + sc_bigint<12>(sext_ln703_280_fu_132463_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_461_fu_132477_p2() {
    add_ln703_461_fu_132477_p2 = (!zext_ln703_55_fu_132453_p1.read().is_01() || !sext_ln703_281_fu_132473_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_55_fu_132453_p1.read()) + sc_bigint<13>(sext_ln703_281_fu_132473_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_462_fu_132487_p2() {
    add_ln703_462_fu_132487_p2 = (!add_ln703_456_fu_132432_p2.read().is_01() || !sext_ln703_282_fu_132483_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_456_fu_132432_p2.read()) + sc_bigint<15>(sext_ln703_282_fu_132483_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_463_fu_138690_p2() {
    add_ln703_463_fu_138690_p2 = (!zext_ln203_18_fu_135484_p1.read().is_01() || !sext_ln203_75_fu_136004_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_18_fu_135484_p1.read()) + sc_bigint<12>(sext_ln203_75_fu_136004_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_464_fu_138700_p2() {
    add_ln703_464_fu_138700_p2 = (!add_ln703_462_reg_144238.read().is_01() || !sext_ln703_283_fu_138696_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_462_reg_144238.read()) + sc_bigint<15>(sext_ln703_283_fu_138696_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_465_fu_138705_p2() {
    add_ln703_465_fu_138705_p2 = (!zext_ln203_27_fu_135981_p1.read().is_01() || !zext_ln203_26_fu_135978_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_27_fu_135981_p1.read()) + sc_biguint<10>(zext_ln203_26_fu_135978_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_466_fu_138715_p2() {
    add_ln703_466_fu_138715_p2 = (!zext_ln708_80_fu_135974_p1.read().is_01() || !zext_ln703_56_fu_138711_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_80_fu_135974_p1.read()) + sc_biguint<11>(zext_ln703_56_fu_138711_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_467_fu_138725_p2() {
    add_ln703_467_fu_138725_p2 = (!add_ln703_464_fu_138700_p2.read().is_01() || !zext_ln703_57_fu_138721_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_464_fu_138700_p2.read()) + sc_biguint<15>(zext_ln703_57_fu_138721_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_468_fu_138735_p2() {
    add_ln703_468_fu_138735_p2 = (!zext_ln708_83_fu_135991_p1.read().is_01() || !zext_ln708_82_fu_135987_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_83_fu_135991_p1.read()) + sc_biguint<11>(zext_ln708_82_fu_135987_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_469_fu_138741_p2() {
    add_ln703_469_fu_138741_p2 = (!zext_ln708_81_fu_135984_p1.read().is_01() || !add_ln703_468_fu_138735_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_81_fu_135984_p1.read()) + sc_biguint<11>(add_ln703_468_fu_138735_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_470_fu_138751_p2() {
    add_ln703_470_fu_138751_p2 = (!sext_ln203_60_fu_135618_p1.read().is_01() || !sext_ln203_74_fu_135971_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_60_fu_135618_p1.read()) + sc_bigint<9>(sext_ln203_74_fu_135971_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_471_fu_138761_p2() {
    add_ln703_471_fu_138761_p2 = (!zext_ln203_28_fu_136008_p1.read().is_01() || !sext_ln703_285_fu_138757_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_28_fu_136008_p1.read()) + sc_bigint<12>(sext_ln703_285_fu_138757_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_472_fu_138771_p2() {
    add_ln703_472_fu_138771_p2 = (!zext_ln703_58_fu_138747_p1.read().is_01() || !sext_ln703_286_fu_138767_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_58_fu_138747_p1.read()) + sc_bigint<13>(sext_ln703_286_fu_138767_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_474_fu_125260_p2() {
    add_ln703_474_fu_125260_p2 = (!zext_ln708_85_fu_121622_p1.read().is_01() || !ap_const_lv11_70.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_85_fu_121622_p1.read()) + sc_biguint<11>(ap_const_lv11_70));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_475_fu_125270_p2() {
    add_ln703_475_fu_125270_p2 = (!sext_ln1116_21_fu_121667_p1.read().is_01() || !sext_ln1118_179_fu_121681_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_21_fu_121667_p1.read()) + sc_bigint<10>(sext_ln1118_179_fu_121681_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_476_fu_125280_p2() {
    add_ln703_476_fu_125280_p2 = (!zext_ln703_59_fu_125266_p1.read().is_01() || !sext_ln703_288_fu_125276_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_59_fu_125266_p1.read()) + sc_bigint<12>(sext_ln703_288_fu_125276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_477_fu_125290_p2() {
    add_ln703_477_fu_125290_p2 = (!sext_ln708_64_fu_121734_p1.read().is_01() || !sext_ln1116_22_fu_121703_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_64_fu_121734_p1.read()) + sc_bigint<12>(sext_ln1116_22_fu_121703_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_478_fu_125300_p2() {
    add_ln703_478_fu_125300_p2 = (!sext_ln703_289_fu_125286_p1.read().is_01() || !sext_ln703_290_fu_125296_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_289_fu_125286_p1.read()) + sc_bigint<13>(sext_ln703_290_fu_125296_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_479_fu_125306_p2() {
    add_ln703_479_fu_125306_p2 = (!sext_ln1118_180_fu_121685_p1.read().is_01() || !zext_ln1118_20_fu_119226_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_180_fu_121685_p1.read()) + sc_biguint<12>(zext_ln1118_20_fu_119226_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_480_fu_125316_p2() {
    add_ln703_480_fu_125316_p2 = (!zext_ln1118_331_fu_121689_p1.read().is_01() || !sext_ln703_292_fu_125312_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_331_fu_121689_p1.read()) + sc_bigint<13>(sext_ln703_292_fu_125312_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_481_fu_132499_p2() {
    add_ln703_481_fu_132499_p2 = (!sext_ln703_291_fu_132493_p1.read().is_01() || !sext_ln703_293_fu_132496_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_291_fu_132493_p1.read()) + sc_bigint<14>(sext_ln703_293_fu_132496_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_482_fu_125322_p2() {
    add_ln703_482_fu_125322_p2 = (!sext_ln1118_181_fu_121791_p1.read().is_01() || !zext_ln708_86_fu_121747_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_181_fu_121791_p1.read()) + sc_biguint<12>(zext_ln708_86_fu_121747_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_483_fu_132508_p2() {
    add_ln703_483_fu_132508_p2 = (!add_ln703_481_fu_132499_p2.read().is_01() || !sext_ln703_294_fu_132505_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_481_fu_132499_p2.read()) + sc_bigint<14>(sext_ln703_294_fu_132505_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_484_fu_132518_p2() {
    add_ln703_484_fu_132518_p2 = (!zext_ln708_88_fu_128421_p1.read().is_01() || !trunc_ln1116_s_reg_143223.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_88_fu_128421_p1.read()) + sc_biguint<10>(trunc_ln1116_s_reg_143223.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_485_fu_125328_p2() {
    add_ln703_485_fu_125328_p2 = (!zext_ln1116_37_fu_121816_p1.read().is_01() || !zext_ln1118_337_fu_121812_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_37_fu_121816_p1.read()) + sc_biguint<10>(zext_ln1118_337_fu_121812_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_486_fu_132530_p2() {
    add_ln703_486_fu_132530_p2 = (!zext_ln703_60_fu_132523_p1.read().is_01() || !zext_ln703_61_fu_132527_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_60_fu_132523_p1.read()) + sc_biguint<11>(zext_ln703_61_fu_132527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_487_fu_132540_p2() {
    add_ln703_487_fu_132540_p2 = (!sext_ln703_295_fu_132514_p1.read().is_01() || !zext_ln703_62_fu_132536_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_295_fu_132514_p1.read()) + sc_biguint<15>(zext_ln703_62_fu_132536_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_488_fu_125334_p2() {
    add_ln703_488_fu_125334_p2 = (!zext_ln708_92_fu_121872_p1.read().is_01() || !zext_ln708_91_fu_121848_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_92_fu_121872_p1.read()) + sc_biguint<11>(zext_ln708_91_fu_121848_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_489_fu_125340_p2() {
    add_ln703_489_fu_125340_p2 = (!zext_ln708_90_fu_121844_p1.read().is_01() || !add_ln703_488_fu_125334_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_90_fu_121844_p1.read()) + sc_biguint<11>(add_ln703_488_fu_125334_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_490_fu_125350_p2() {
    add_ln703_490_fu_125350_p2 = (!sext_ln1118_184_fu_121868_p1.read().is_01() || !sext_ln1118_182_fu_121798_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_184_fu_121868_p1.read()) + sc_bigint<11>(sext_ln1118_182_fu_121798_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_491_fu_125360_p2() {
    add_ln703_491_fu_125360_p2 = (!sext_ln1118_183_fu_121840_p1.read().is_01() || !zext_ln708_89_fu_121795_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_183_fu_121840_p1.read()) + sc_biguint<8>(zext_ln708_89_fu_121795_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_492_fu_125370_p2() {
    add_ln703_492_fu_125370_p2 = (!sext_ln703_296_fu_125356_p1.read().is_01() || !sext_ln703_297_fu_125366_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_296_fu_125356_p1.read()) + sc_bigint<12>(sext_ln703_297_fu_125366_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_493_fu_125380_p2() {
    add_ln703_493_fu_125380_p2 = (!zext_ln703_63_fu_125346_p1.read().is_01() || !sext_ln703_298_fu_125376_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_63_fu_125346_p1.read()) + sc_bigint<13>(sext_ln703_298_fu_125376_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_494_fu_132549_p2() {
    add_ln703_494_fu_132549_p2 = (!add_ln703_487_fu_132540_p2.read().is_01() || !sext_ln703_299_fu_132546_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_487_fu_132540_p2.read()) + sc_bigint<15>(sext_ln703_299_fu_132546_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_495_fu_138787_p2() {
    add_ln703_495_fu_138787_p2 = (!sext_ln203_76_fu_136042_p1.read().is_01() || !sext_ln1118_166_fu_135821_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_76_fu_136042_p1.read()) + sc_bigint<12>(sext_ln1118_166_fu_135821_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_496_fu_138797_p2() {
    add_ln703_496_fu_138797_p2 = (!add_ln703_494_reg_144243.read().is_01() || !sext_ln703_300_fu_138793_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_494_reg_144243.read()) + sc_bigint<15>(sext_ln703_300_fu_138793_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_497_fu_125386_p2() {
    add_ln703_497_fu_125386_p2 = (!zext_ln203_29_fu_121876_p1.read().is_01() || !sext_ln203_81_fu_121888_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_29_fu_121876_p1.read()) + sc_bigint<12>(sext_ln203_81_fu_121888_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_498_fu_138805_p2() {
    add_ln703_498_fu_138805_p2 = (!sext_ln203_79_fu_136074_p1.read().is_01() || !sext_ln703_301_fu_138802_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_79_fu_136074_p1.read()) + sc_bigint<13>(sext_ln703_301_fu_138802_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_499_fu_138815_p2() {
    add_ln703_499_fu_138815_p2 = (!add_ln703_496_fu_138797_p2.read().is_01() || !sext_ln703_302_fu_138811_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_496_fu_138797_p2.read()) + sc_bigint<15>(sext_ln703_302_fu_138811_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_500_fu_138825_p2() {
    add_ln703_500_fu_138825_p2 = (!grp_fu_117364_p4.read().is_01() || !zext_ln203_31_fu_136094_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117364_p4.read()) + sc_biguint<10>(zext_ln203_31_fu_136094_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_501_fu_138831_p2() {
    add_ln703_501_fu_138831_p2 = (!zext_ln203_30_fu_136062_p1.read().is_01() || !add_ln703_500_fu_138825_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_30_fu_136062_p1.read()) + sc_biguint<10>(add_ln703_500_fu_138825_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_502_fu_125392_p2() {
    add_ln703_502_fu_125392_p2 = (!sext_ln203_78_fu_121884_p1.read().is_01() || !sext_ln203_77_fu_121880_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_78_fu_121884_p1.read()) + sc_bigint<10>(sext_ln203_77_fu_121880_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_503_fu_138844_p2() {
    add_ln703_503_fu_138844_p2 = (!sext_ln203_80_fu_136102_p1.read().is_01() || !sext_ln703_304_fu_138841_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_80_fu_136102_p1.read()) + sc_bigint<11>(sext_ln703_304_fu_138841_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_504_fu_138854_p2() {
    add_ln703_504_fu_138854_p2 = (!zext_ln703_64_fu_138837_p1.read().is_01() || !sext_ln703_305_fu_138850_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_64_fu_138837_p1.read()) + sc_bigint<12>(sext_ln703_305_fu_138850_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_506_fu_125398_p2() {
    add_ln703_506_fu_125398_p2 = (!sext_ln1118_113_fu_120206_p1.read().is_01() || !ap_const_lv11_7A0.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_113_fu_120206_p1.read()) + sc_bigint<11>(ap_const_lv11_7A0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_507_fu_125408_p2() {
    add_ln703_507_fu_125408_p2 = (!zext_ln203_32_fu_121892_p1.read().is_01() || !sext_ln703_307_fu_125404_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_32_fu_121892_p1.read()) + sc_bigint<12>(sext_ln703_307_fu_125404_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_508_fu_125414_p2() {
    add_ln703_508_fu_125414_p2 = (!sext_ln1118_185_fu_121920_p1.read().is_01() || !zext_ln708_93_fu_121896_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_185_fu_121920_p1.read()) + sc_biguint<11>(zext_ln708_93_fu_121896_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_509_fu_125424_p2() {
    add_ln703_509_fu_125424_p2 = (!add_ln703_507_fu_125408_p2.read().is_01() || !sext_ln703_308_fu_125420_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_507_fu_125408_p2.read()) + sc_bigint<12>(sext_ln703_308_fu_125420_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_510_fu_125434_p2() {
    add_ln703_510_fu_125434_p2 = (!zext_ln708_94_fu_121950_p1.read().is_01() || !sext_ln708_65_fu_121946_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_94_fu_121950_p1.read()) + sc_bigint<12>(sext_ln708_65_fu_121946_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_511_fu_125444_p2() {
    add_ln703_511_fu_125444_p2 = (!sext_ln703_309_fu_125430_p1.read().is_01() || !sext_ln703_310_fu_125440_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_309_fu_125430_p1.read()) + sc_bigint<13>(sext_ln703_310_fu_125440_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_512_fu_125450_p2() {
    add_ln703_512_fu_125450_p2 = (!sext_ln1118_187_fu_121938_p1.read().is_01() || !sext_ln1118_188_fu_121942_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_187_fu_121938_p1.read()) + sc_bigint<11>(sext_ln1118_188_fu_121942_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_513_fu_125456_p2() {
    add_ln703_513_fu_125456_p2 = (!zext_ln1118_342_fu_121954_p1.read().is_01() || !sext_ln1118_186_fu_121934_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_342_fu_121954_p1.read()) + sc_bigint<9>(sext_ln1118_186_fu_121934_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_514_fu_125466_p2() {
    add_ln703_514_fu_125466_p2 = (!add_ln703_512_fu_125450_p2.read().is_01() || !sext_ln703_312_fu_125462_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_512_fu_125450_p2.read()) + sc_bigint<11>(sext_ln703_312_fu_125462_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_515_fu_132561_p2() {
    add_ln703_515_fu_132561_p2 = (!sext_ln703_311_fu_132555_p1.read().is_01() || !sext_ln703_313_fu_132558_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_311_fu_132555_p1.read()) + sc_bigint<14>(sext_ln703_313_fu_132558_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_516_fu_132567_p2() {
    add_ln703_516_fu_132567_p2 = (!zext_ln708_96_fu_128440_p1.read().is_01() || !add_ln703_515_fu_132561_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln708_96_fu_128440_p1.read()) + sc_biguint<14>(add_ln703_515_fu_132561_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_517_fu_125472_p2() {
    add_ln703_517_fu_125472_p2 = (!zext_ln1118_343_fu_121967_p1.read().is_01() || !sext_ln1118_190_fu_121971_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_343_fu_121967_p1.read()) + sc_bigint<12>(sext_ln1118_190_fu_121971_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_518_fu_132580_p2() {
    add_ln703_518_fu_132580_p2 = (!sext_ln1118_189_fu_128548_p1.read().is_01() || !sext_ln703_315_fu_132577_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_189_fu_128548_p1.read()) + sc_bigint<13>(sext_ln703_315_fu_132577_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_519_fu_132590_p2() {
    add_ln703_519_fu_132590_p2 = (!sext_ln703_314_fu_132573_p1.read().is_01() || !sext_ln703_316_fu_132586_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_314_fu_132573_p1.read()) + sc_bigint<15>(sext_ln703_316_fu_132586_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_520_fu_132596_p2() {
    add_ln703_520_fu_132596_p2 = (!sext_ln1118_191_fu_128552_p1.read().is_01() || !zext_ln708_97_fu_128460_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_191_fu_128552_p1.read()) + sc_biguint<10>(zext_ln708_97_fu_128460_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_521_fu_132602_p2() {
    add_ln703_521_fu_132602_p2 = (!zext_ln1118_345_fu_128524_p1.read().is_01() || !add_ln703_520_fu_132596_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_345_fu_128524_p1.read()) + sc_biguint<10>(add_ln703_520_fu_132596_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_522_fu_132612_p2() {
    add_ln703_522_fu_132612_p2 = (!sext_ln1118_193_fu_128586_p1.read().is_01() || !sext_ln708_67_fu_128493_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_193_fu_128586_p1.read()) + sc_bigint<9>(sext_ln708_67_fu_128493_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_523_fu_132622_p2() {
    add_ln703_523_fu_132622_p2 = (!sext_ln708_66_fu_128464_p1.read().is_01() || !sext_ln703_318_fu_132618_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_66_fu_128464_p1.read()) + sc_bigint<10>(sext_ln703_318_fu_132618_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_524_fu_132632_p2() {
    add_ln703_524_fu_132632_p2 = (!sext_ln703_317_fu_132608_p1.read().is_01() || !sext_ln703_319_fu_132628_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_317_fu_132608_p1.read()) + sc_bigint<11>(sext_ln703_319_fu_132628_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_525_fu_138873_p2() {
    add_ln703_525_fu_138873_p2 = (!add_ln703_519_reg_144248.read().is_01() || !sext_ln703_320_fu_138870_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_519_reg_144248.read()) + sc_bigint<15>(sext_ln703_320_fu_138870_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_526_fu_138878_p2() {
    add_ln703_526_fu_138878_p2 = (!sext_ln203_84_fu_136145_p1.read().is_01() || !sext_ln203_83_fu_136128_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_84_fu_136145_p1.read()) + sc_bigint<12>(sext_ln203_83_fu_136128_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_527_fu_138888_p2() {
    add_ln703_527_fu_138888_p2 = (!add_ln703_525_fu_138873_p2.read().is_01() || !sext_ln703_321_fu_138884_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_525_fu_138873_p2.read()) + sc_bigint<15>(sext_ln703_321_fu_138884_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_528_fu_138894_p2() {
    add_ln703_528_fu_138894_p2 = (!zext_ln203_33_fu_136173_p1.read().is_01() || !zext_ln203_26_fu_135978_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_33_fu_136173_p1.read()) + sc_biguint<10>(zext_ln203_26_fu_135978_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_529_fu_138904_p2() {
    add_ln703_529_fu_138904_p2 = (!sext_ln203_86_fu_136218_p1.read().is_01() || !zext_ln703_65_fu_138900_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_86_fu_136218_p1.read()) + sc_biguint<12>(zext_ln703_65_fu_138900_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_530_fu_138914_p2() {
    add_ln703_530_fu_138914_p2 = (!add_ln703_527_fu_138888_p2.read().is_01() || !sext_ln703_322_fu_138910_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_527_fu_138888_p2.read()) + sc_bigint<15>(sext_ln703_322_fu_138910_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_531_fu_138920_p2() {
    add_ln703_531_fu_138920_p2 = (!sext_ln203_63_fu_135685_p1.read().is_01() || !sext_ln203_82_fu_136109_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_63_fu_135685_p1.read()) + sc_bigint<10>(sext_ln203_82_fu_136109_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_532_fu_138930_p2() {
    add_ln703_532_fu_138930_p2 = (!zext_ln708_100_fu_136204_p1.read().is_01() || !sext_ln703_323_fu_138926_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_100_fu_136204_p1.read()) + sc_bigint<11>(sext_ln703_323_fu_138926_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_533_fu_138940_p2() {
    add_ln703_533_fu_138940_p2 = (!sext_ln203_87_fu_136238_p1.read().is_01() || !sext_ln203_85_fu_136169_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln203_87_fu_136238_p1.read()) + sc_bigint<7>(sext_ln203_85_fu_136169_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_534_fu_138950_p2() {
    add_ln703_534_fu_138950_p2 = (!zext_ln708_99_fu_136132_p1.read().is_01() || !sext_ln703_325_fu_138946_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln708_99_fu_136132_p1.read()) + sc_bigint<8>(sext_ln703_325_fu_138946_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_535_fu_138960_p2() {
    add_ln703_535_fu_138960_p2 = (!sext_ln703_324_fu_138936_p1.read().is_01() || !sext_ln703_326_fu_138956_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_324_fu_138936_p1.read()) + sc_bigint<12>(sext_ln703_326_fu_138956_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_537_fu_125478_p2() {
    add_ln703_537_fu_125478_p2 = (!sext_ln203_41_fu_120373_p1.read().is_01() || !ap_const_lv12_C70.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_41_fu_120373_p1.read()) + sc_bigint<12>(ap_const_lv12_C70));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_538_fu_125484_p2() {
    add_ln703_538_fu_125484_p2 = (!zext_ln708_102_fu_122006_p1.read().is_01() || !zext_ln708_101_fu_122002_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_102_fu_122006_p1.read()) + sc_biguint<11>(zext_ln708_101_fu_122002_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_539_fu_125494_p2() {
    add_ln703_539_fu_125494_p2 = (!add_ln703_537_fu_125478_p2.read().is_01() || !zext_ln703_66_fu_125490_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_537_fu_125478_p2.read()) + sc_biguint<12>(zext_ln703_66_fu_125490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_540_fu_125504_p2() {
    add_ln703_540_fu_125504_p2 = (!sext_ln1118_195_fu_122040_p1.read().is_01() || !sext_ln1118_194_fu_122036_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_195_fu_122040_p1.read()) + sc_bigint<11>(sext_ln1118_194_fu_122036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_541_fu_125514_p2() {
    add_ln703_541_fu_125514_p2 = (!sext_ln703_203_fu_125500_p1.read().is_01() || !sext_ln703_329_fu_125510_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_203_fu_125500_p1.read()) + sc_bigint<13>(sext_ln703_329_fu_125510_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_542_fu_125520_p2() {
    add_ln703_542_fu_125520_p2 = (!sext_ln708_68_fu_122093_p1.read().is_01() || !sext_ln1118_196_fu_122071_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_68_fu_122093_p1.read()) + sc_bigint<12>(sext_ln1118_196_fu_122071_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_543_fu_132644_p2() {
    add_ln703_543_fu_132644_p2 = (!sext_ln703_204_fu_132638_p1.read().is_01() || !sext_ln703_330_fu_132641_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_204_fu_132638_p1.read()) + sc_bigint<14>(sext_ln703_330_fu_132641_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_544_fu_125526_p2() {
    add_ln703_544_fu_125526_p2 = (!sext_ln1118_197_fu_122075_p1.read().is_01() || !zext_ln1118_355_fu_122097_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_197_fu_122075_p1.read()) + sc_biguint<12>(zext_ln1118_355_fu_122097_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_545_fu_125532_p2() {
    add_ln703_545_fu_125532_p2 = (!zext_ln1118_354_fu_122089_p1.read().is_01() || !add_ln703_544_fu_125526_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_354_fu_122089_p1.read()) + sc_biguint<12>(add_ln703_544_fu_125526_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_546_fu_132653_p2() {
    add_ln703_546_fu_132653_p2 = (!add_ln703_543_fu_132644_p2.read().is_01() || !sext_ln703_331_fu_132650_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_543_fu_132644_p2.read()) + sc_bigint<14>(sext_ln703_331_fu_132650_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_547_fu_132659_p2() {
    add_ln703_547_fu_132659_p2 = (!sext_ln708_69_fu_128616_p1.read().is_01() || !add_ln703_546_fu_132653_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln708_69_fu_128616_p1.read()) + sc_biguint<14>(add_ln703_546_fu_132653_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_548_fu_132669_p2() {
    add_ln703_548_fu_132669_p2 = (!sext_ln708_71_fu_128622_p1.read().is_01() || !sext_ln1118_132_fu_127726_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_71_fu_128622_p1.read()) + sc_bigint<12>(sext_ln1118_132_fu_127726_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_549_fu_132679_p2() {
    add_ln703_549_fu_132679_p2 = (!sext_ln708_70_fu_128619_p1.read().is_01() || !sext_ln703_333_fu_132675_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln708_70_fu_128619_p1.read()) + sc_bigint<13>(sext_ln703_333_fu_132675_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_550_fu_132689_p2() {
    add_ln703_550_fu_132689_p2 = (!sext_ln703_332_fu_132665_p1.read().is_01() || !sext_ln703_334_fu_132685_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_332_fu_132665_p1.read()) + sc_bigint<15>(sext_ln703_334_fu_132685_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_551_fu_125538_p2() {
    add_ln703_551_fu_125538_p2 = (!zext_ln708_104_fu_122155_p1.read().is_01() || !zext_ln708_103_fu_122136_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_104_fu_122155_p1.read()) + sc_biguint<11>(zext_ln708_103_fu_122136_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_552_fu_125548_p2() {
    add_ln703_552_fu_125548_p2 = (!zext_ln1118_357_fu_122132_p1.read().is_01() || !zext_ln703_67_fu_125544_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_357_fu_122132_p1.read()) + sc_biguint<12>(zext_ln703_67_fu_125544_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_553_fu_125558_p2() {
    add_ln703_553_fu_125558_p2 = (!sext_ln1118_198_fu_122128_p1.read().is_01() || !zext_ln708_106_fu_122183_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_198_fu_122128_p1.read()) + sc_biguint<11>(zext_ln708_106_fu_122183_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_554_fu_125568_p2() {
    add_ln703_554_fu_125568_p2 = (!zext_ln1118_358_fu_122159_p1.read().is_01() || !sext_ln703_335_fu_125564_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_358_fu_122159_p1.read()) + sc_bigint<12>(sext_ln703_335_fu_125564_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_555_fu_125578_p2() {
    add_ln703_555_fu_125578_p2 = (!zext_ln703_68_fu_125554_p1.read().is_01() || !sext_ln703_336_fu_125574_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_68_fu_125554_p1.read()) + sc_bigint<13>(sext_ln703_336_fu_125574_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_556_fu_138983_p2() {
    add_ln703_556_fu_138983_p2 = (!add_ln703_550_reg_144258.read().is_01() || !sext_ln703_337_fu_138980_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_550_reg_144258.read()) + sc_bigint<15>(sext_ln703_337_fu_138980_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_557_fu_138988_p2() {
    add_ln703_557_fu_138988_p2 = (!sext_ln203_89_fu_136350_p1.read().is_01() || !sext_ln203_88_fu_136252_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_89_fu_136350_p1.read()) + sc_bigint<12>(sext_ln203_88_fu_136252_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_558_fu_138998_p2() {
    add_ln703_558_fu_138998_p2 = (!add_ln703_556_fu_138983_p2.read().is_01() || !sext_ln703_338_fu_138994_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_556_fu_138983_p2.read()) + sc_bigint<15>(sext_ln703_338_fu_138994_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_559_fu_139008_p2() {
    add_ln703_559_fu_139008_p2 = (!zext_ln708_110_fu_136279_p1.read().is_01() || !zext_ln708_109_fu_136275_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_110_fu_136279_p1.read()) + sc_biguint<11>(zext_ln708_109_fu_136275_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_560_fu_139014_p2() {
    add_ln703_560_fu_139014_p2 = (!zext_ln708_108_fu_136256_p1.read().is_01() || !add_ln703_559_fu_139008_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_108_fu_136256_p1.read()) + sc_biguint<11>(add_ln703_559_fu_139008_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_561_fu_139024_p2() {
    add_ln703_561_fu_139024_p2 = (!sext_ln703_339_fu_139004_p1.read().is_01() || !zext_ln703_69_fu_139020_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_339_fu_139004_p1.read()) + sc_biguint<16>(zext_ln703_69_fu_139020_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_562_fu_139030_p2() {
    add_ln703_562_fu_139030_p2 = (!zext_ln708_112_fu_136313_p1.read().is_01() || !zext_ln708_111_fu_136287_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_112_fu_136313_p1.read()) + sc_biguint<11>(zext_ln708_111_fu_136287_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_563_fu_139040_p2() {
    add_ln703_563_fu_139040_p2 = (!zext_ln203_34_fu_136283_p1.read().is_01() || !zext_ln703_70_fu_139036_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_34_fu_136283_p1.read()) + sc_biguint<12>(zext_ln703_70_fu_139036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_564_fu_139046_p2() {
    add_ln703_564_fu_139046_p2 = (!zext_ln203_36_fu_136336_p1.read().is_01() || !zext_ln203_35_fu_136317_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_36_fu_136336_p1.read()) + sc_biguint<9>(zext_ln203_35_fu_136317_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_565_fu_139056_p2() {
    add_ln703_565_fu_139056_p2 = (!zext_ln203_37_fu_136354_p1.read().is_01() || !tmp_156_reg_143210.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_37_fu_136354_p1.read()) + sc_biguint<10>(tmp_156_reg_143210.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_566_fu_139065_p2() {
    add_ln703_566_fu_139065_p2 = (!zext_ln703_71_fu_139052_p1.read().is_01() || !zext_ln703_72_fu_139061_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_71_fu_139052_p1.read()) + sc_biguint<11>(zext_ln703_72_fu_139061_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_567_fu_139075_p2() {
    add_ln703_567_fu_139075_p2 = (!add_ln703_563_fu_139040_p2.read().is_01() || !zext_ln703_73_fu_139071_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_563_fu_139040_p2.read()) + sc_biguint<12>(zext_ln703_73_fu_139071_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_569_fu_125584_p2() {
    add_ln703_569_fu_125584_p2 = (!trunc_ln1118_10_fu_122201_p4.read().is_01() || !ap_const_lv10_50.is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_10_fu_122201_p4.read()) + sc_biguint<10>(ap_const_lv10_50));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_570_fu_125594_p2() {
    add_ln703_570_fu_125594_p2 = (!sext_ln203_41_fu_120373_p1.read().is_01() || !zext_ln703_75_fu_125590_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_41_fu_120373_p1.read()) + sc_biguint<12>(zext_ln703_75_fu_125590_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_571_fu_125604_p2() {
    add_ln703_571_fu_125604_p2 = (!sext_ln203_90_fu_122230_p1.read().is_01() || !sext_ln703_207_fu_125600_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_90_fu_122230_p1.read()) + sc_bigint<13>(sext_ln703_207_fu_125600_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_572_fu_125610_p2() {
    add_ln703_572_fu_125610_p2 = (!zext_ln1118_362_fu_122254_p1.read().is_01() || !trunc_ln1118_11_fu_122244_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_362_fu_122254_p1.read()) + sc_biguint<10>(trunc_ln1118_11_fu_122244_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_573_fu_125620_p2() {
    add_ln703_573_fu_125620_p2 = (!add_ln703_571_fu_125604_p2.read().is_01() || !zext_ln703_76_fu_125616_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_571_fu_125604_p2.read()) + sc_biguint<13>(zext_ln703_76_fu_125616_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_574_fu_125630_p2() {
    add_ln703_574_fu_125630_p2 = (!zext_ln1118_365_fu_122316_p1.read().is_01() || !sext_ln1118_201_fu_122371_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_365_fu_122316_p1.read()) + sc_bigint<12>(sext_ln1118_201_fu_122371_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_575_fu_125640_p2() {
    add_ln703_575_fu_125640_p2 = (!sext_ln703_208_fu_125626_p1.read().is_01() || !sext_ln703_340_fu_125636_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_208_fu_125626_p1.read()) + sc_bigint<14>(sext_ln703_340_fu_125636_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_576_fu_125646_p2() {
    add_ln703_576_fu_125646_p2 = (!zext_ln1118_369_fu_122395_p1.read().is_01() || !zext_ln1118_366_fu_122343_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_369_fu_122395_p1.read()) + sc_biguint<10>(zext_ln1118_366_fu_122343_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_577_fu_125656_p2() {
    add_ln703_577_fu_125656_p2 = (!sext_ln1118_200_fu_122347_p1.read().is_01() || !sext_ln1118_199_fu_122289_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_200_fu_122347_p1.read()) + sc_bigint<11>(sext_ln1118_199_fu_122289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_578_fu_125666_p2() {
    add_ln703_578_fu_125666_p2 = (!zext_ln703_77_fu_125652_p1.read().is_01() || !sext_ln703_341_fu_125662_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_77_fu_125652_p1.read()) + sc_bigint<12>(sext_ln703_341_fu_125662_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_579_fu_125676_p2() {
    add_ln703_579_fu_125676_p2 = (!add_ln703_575_fu_125640_p2.read().is_01() || !sext_ln703_342_fu_125672_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_575_fu_125640_p2.read()) + sc_bigint<14>(sext_ln703_342_fu_125672_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_580_fu_139094_p2() {
    add_ln703_580_fu_139094_p2 = (!sext_ln1118_202_fu_136357_p1.read().is_01() || !zext_ln708_95_fu_136106_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_202_fu_136357_p1.read()) + sc_biguint<12>(zext_ln708_95_fu_136106_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_581_fu_139104_p2() {
    add_ln703_581_fu_139104_p2 = (!sext_ln703_209_fu_139091_p1.read().is_01() || !sext_ln703_343_fu_139100_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_209_fu_139091_p1.read()) + sc_bigint<15>(sext_ln703_343_fu_139100_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_582_fu_132695_p2() {
    add_ln703_582_fu_132695_p2 = (!sext_ln1118_205_fu_128734_p1.read().is_01() || !sext_ln1118_204_fu_128709_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_205_fu_128734_p1.read()) + sc_bigint<12>(sext_ln1118_204_fu_128709_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_583_fu_132705_p2() {
    add_ln703_583_fu_132705_p2 = (!sext_ln1116_7_fu_126464_p1.read().is_01() || !sext_ln703_344_fu_132701_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_7_fu_126464_p1.read()) + sc_bigint<13>(sext_ln703_344_fu_132701_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_584_fu_139113_p2() {
    add_ln703_584_fu_139113_p2 = (!add_ln703_581_fu_139104_p2.read().is_01() || !sext_ln703_345_fu_139110_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_581_fu_139104_p2.read()) + sc_bigint<15>(sext_ln703_345_fu_139110_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_585_fu_132711_p2() {
    add_ln703_585_fu_132711_p2 = (!zext_ln1118_373_fu_128712_p1.read().is_01() || !zext_ln1118_371_fu_128705_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_373_fu_128712_p1.read()) + sc_biguint<10>(zext_ln1118_371_fu_128705_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_586_fu_132721_p2() {
    add_ln703_586_fu_132721_p2 = (!sext_ln203_43_fu_127795_p1.read().is_01() || !zext_ln703_78_fu_132717_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_43_fu_127795_p1.read()) + sc_biguint<12>(zext_ln703_78_fu_132717_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_587_fu_132731_p2() {
    add_ln703_587_fu_132731_p2 = (!zext_ln1118_375_fu_128768_p1.read().is_01() || !zext_ln1118_374_fu_128715_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_375_fu_128768_p1.read()) + sc_biguint<9>(zext_ln1118_374_fu_128715_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_588_fu_125682_p2() {
    add_ln703_588_fu_125682_p2 = (!sext_ln1118_206_fu_122429_p1.read().is_01() || !sext_ln1118_203_fu_122399_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_206_fu_122429_p1.read()) + sc_bigint<11>(sext_ln1118_203_fu_122399_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_589_fu_132744_p2() {
    add_ln703_589_fu_132744_p2 = (!zext_ln703_79_fu_132737_p1.read().is_01() || !sext_ln703_347_fu_132741_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_79_fu_132737_p1.read()) + sc_bigint<12>(sext_ln703_347_fu_132741_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_590_fu_132754_p2() {
    add_ln703_590_fu_132754_p2 = (!sext_ln703_346_fu_132727_p1.read().is_01() || !sext_ln703_348_fu_132750_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_346_fu_132727_p1.read()) + sc_bigint<13>(sext_ln703_348_fu_132750_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_591_fu_139122_p2() {
    add_ln703_591_fu_139122_p2 = (!add_ln703_584_fu_139113_p2.read().is_01() || !sext_ln703_349_fu_139119_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_584_fu_139113_p2.read()) + sc_bigint<15>(sext_ln703_349_fu_139119_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_592_fu_139128_p2() {
    add_ln703_592_fu_139128_p2 = (!sext_ln203_91_fu_136371_p1.read().is_01() || !add_ln703_591_fu_139122_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_91_fu_136371_p1.read()) + sc_biguint<15>(add_ln703_591_fu_139122_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_593_fu_139138_p2() {
    add_ln703_593_fu_139138_p2 = (!sext_ln203_93_fu_136426_p1.read().is_01() || !sext_ln203_92_fu_136402_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_93_fu_136426_p1.read()) + sc_bigint<12>(sext_ln203_92_fu_136402_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_594_fu_139148_p2() {
    add_ln703_594_fu_139148_p2 = (!sext_ln203_50_fu_135526_p1.read().is_01() || !sext_ln703_351_fu_139144_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_50_fu_135526_p1.read()) + sc_bigint<13>(sext_ln703_351_fu_139144_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_595_fu_139158_p2() {
    add_ln703_595_fu_139158_p2 = (!sext_ln703_350_fu_139134_p1.read().is_01() || !sext_ln703_352_fu_139154_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_350_fu_139134_p1.read()) + sc_bigint<16>(sext_ln703_352_fu_139154_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_596_fu_139164_p2() {
    add_ln703_596_fu_139164_p2 = (!zext_ln203_39_fu_136433_p1.read().is_01() || !sext_ln203_94_fu_136464_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_39_fu_136433_p1.read()) + sc_bigint<12>(sext_ln203_94_fu_136464_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_597_fu_139174_p2() {
    add_ln703_597_fu_139174_p2 = (!zext_ln203_38_fu_136430_p1.read().is_01() || !sext_ln203_95_fu_136468_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln203_38_fu_136430_p1.read()) + sc_bigint<11>(sext_ln203_95_fu_136468_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_598_fu_139180_p2() {
    add_ln703_598_fu_139180_p2 = (!zext_ln708_118_fu_136492_p1.read().is_01() || !add_ln703_597_fu_139174_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_118_fu_136492_p1.read()) + sc_biguint<11>(add_ln703_597_fu_139174_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_599_fu_139190_p2() {
    add_ln703_599_fu_139190_p2 = (!sext_ln703_353_fu_139170_p1.read().is_01() || !sext_ln703_354_fu_139186_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_353_fu_139170_p1.read()) + sc_bigint<13>(sext_ln703_354_fu_139186_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_601_fu_125688_p2() {
    add_ln703_601_fu_125688_p2 = (!sext_ln203_96_fu_122463_p1.read().is_01() || !ap_const_lv12_DE0.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_96_fu_122463_p1.read()) + sc_bigint<12>(ap_const_lv12_DE0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_602_fu_125694_p2() {
    add_ln703_602_fu_125694_p2 = (!zext_ln708_120_fu_122473_p1.read().is_01() || !grp_fu_117374_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln708_120_fu_122473_p1.read()) + sc_biguint<8>(grp_fu_117374_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_603_fu_125704_p2() {
    add_ln703_603_fu_125704_p2 = (!grp_fu_117364_p4.read().is_01() || !zext_ln703_80_fu_125700_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117364_p4.read()) + sc_biguint<10>(zext_ln703_80_fu_125700_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_604_fu_125714_p2() {
    add_ln703_604_fu_125714_p2 = (!add_ln703_601_fu_125688_p2.read().is_01() || !zext_ln703_81_fu_125710_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_601_fu_125688_p2.read()) + sc_biguint<12>(zext_ln703_81_fu_125710_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_605_fu_132763_p2() {
    add_ln703_605_fu_132763_p2 = (!zext_ln203_40_fu_128772_p1.read().is_01() || !sext_ln703_211_fu_132760_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln203_40_fu_128772_p1.read()) + sc_bigint<13>(sext_ln703_211_fu_132760_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_606_fu_125720_p2() {
    add_ln703_606_fu_125720_p2 = (!zext_ln1116_40_fu_122476_p1.read().is_01() || !sext_ln1116_23_fu_122490_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_40_fu_122476_p1.read()) + sc_bigint<12>(sext_ln1116_23_fu_122490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_607_fu_132772_p2() {
    add_ln703_607_fu_132772_p2 = (!add_ln703_605_fu_132763_p2.read().is_01() || !sext_ln703_356_fu_132769_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_605_fu_132763_p2.read()) + sc_bigint<13>(sext_ln703_356_fu_132769_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_608_fu_132782_p2() {
    add_ln703_608_fu_132782_p2 = (!zext_ln203_41_fu_128775_p1.read().is_01() || !sext_ln703_212_fu_132778_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln203_41_fu_128775_p1.read()) + sc_bigint<14>(sext_ln703_212_fu_132778_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_609_fu_125726_p2() {
    add_ln703_609_fu_125726_p2 = (!sext_ln1116_24_fu_122518_p1.read().is_01() || !zext_ln1116_41_fu_122514_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_24_fu_122518_p1.read()) + sc_biguint<12>(zext_ln1116_41_fu_122514_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_610_fu_125736_p2() {
    add_ln703_610_fu_125736_p2 = (!sext_ln1116_25_fu_122522_p1.read().is_01() || !sext_ln703_357_fu_125732_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_25_fu_122522_p1.read()) + sc_bigint<13>(sext_ln703_357_fu_125732_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_611_fu_132791_p2() {
    add_ln703_611_fu_132791_p2 = (!add_ln703_608_fu_132782_p2.read().is_01() || !sext_ln703_358_fu_132788_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_608_fu_132782_p2.read()) + sc_bigint<14>(sext_ln703_358_fu_132788_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_612_fu_132801_p2() {
    add_ln703_612_fu_132801_p2 = (!sext_ln203_97_fu_128781_p1.read().is_01() || !sext_ln703_213_fu_132797_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_97_fu_128781_p1.read()) + sc_bigint<15>(sext_ln703_213_fu_132797_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_613_fu_125742_p2() {
    add_ln703_613_fu_125742_p2 = (!sext_ln1118_208_fu_122551_p1.read().is_01() || !sext_ln1116_27_fu_122547_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_208_fu_122551_p1.read()) + sc_bigint<12>(sext_ln1116_27_fu_122547_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_614_fu_125752_p2() {
    add_ln703_614_fu_125752_p2 = (!sext_ln708_72_fu_122526_p1.read().is_01() || !sext_ln703_359_fu_125748_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln708_72_fu_122526_p1.read()) + sc_bigint<13>(sext_ln703_359_fu_125748_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_615_fu_132810_p2() {
    add_ln703_615_fu_132810_p2 = (!add_ln703_612_fu_132801_p2.read().is_01() || !sext_ln703_360_fu_132807_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_612_fu_132801_p2.read()) + sc_bigint<15>(sext_ln703_360_fu_132807_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_616_fu_125758_p2() {
    add_ln703_616_fu_125758_p2 = (!zext_ln708_124_fu_122543_p1.read().is_01() || !zext_ln708_123_fu_122539_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_124_fu_122543_p1.read()) + sc_biguint<11>(zext_ln708_123_fu_122539_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_617_fu_132819_p2() {
    add_ln703_617_fu_132819_p2 = (!sext_ln708_73_fu_128837_p1.read().is_01() || !sext_ln1116_26_fu_128801_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_73_fu_128837_p1.read()) + sc_bigint<10>(sext_ln1116_26_fu_128801_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_618_fu_132829_p2() {
    add_ln703_618_fu_132829_p2 = (!zext_ln708_125_fu_128805_p1.read().is_01() || !sext_ln703_361_fu_132825_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_125_fu_128805_p1.read()) + sc_bigint<11>(sext_ln703_361_fu_132825_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_619_fu_132839_p2() {
    add_ln703_619_fu_132839_p2 = (!zext_ln703_82_fu_132816_p1.read().is_01() || !sext_ln703_362_fu_132835_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_82_fu_132816_p1.read()) + sc_bigint<12>(sext_ln703_362_fu_132835_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_620_fu_132849_p2() {
    add_ln703_620_fu_132849_p2 = (!add_ln703_615_fu_132810_p2.read().is_01() || !sext_ln703_363_fu_132845_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_615_fu_132810_p2.read()) + sc_bigint<15>(sext_ln703_363_fu_132845_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_621_fu_132855_p2() {
    add_ln703_621_fu_132855_p2 = (!sext_ln203_98_fu_128894_p1.read().is_01() || !zext_ln203_42_fu_128856_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_98_fu_128894_p1.read()) + sc_biguint<12>(zext_ln203_42_fu_128856_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_622_fu_132865_p2() {
    add_ln703_622_fu_132865_p2 = (!add_ln703_620_fu_132849_p2.read().is_01() || !sext_ln703_364_fu_132861_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_620_fu_132849_p2.read()) + sc_bigint<15>(sext_ln703_364_fu_132861_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_623_fu_139209_p2() {
    add_ln703_623_fu_139209_p2 = (!sext_ln203_102_fu_136537_p1.read().is_01() || !sext_ln203_101_fu_136533_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_102_fu_136537_p1.read()) + sc_bigint<12>(sext_ln203_101_fu_136533_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_624_fu_139219_p2() {
    add_ln703_624_fu_139219_p2 = (!sext_ln203_100_fu_136526_p1.read().is_01() || !sext_ln703_366_fu_139215_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_100_fu_136526_p1.read()) + sc_bigint<13>(sext_ln703_366_fu_139215_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_625_fu_139229_p2() {
    add_ln703_625_fu_139229_p2 = (!sext_ln703_365_fu_139206_p1.read().is_01() || !sext_ln703_367_fu_139225_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_365_fu_139206_p1.read()) + sc_bigint<16>(sext_ln703_367_fu_139225_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_626_fu_139235_p2() {
    add_ln703_626_fu_139235_p2 = (!zext_ln203_44_fu_136530_p1.read().is_01() || !zext_ln203_43_fu_136512_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_44_fu_136530_p1.read()) + sc_biguint<10>(zext_ln203_43_fu_136512_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_627_fu_139245_p2() {
    add_ln703_627_fu_139245_p2 = (!sext_ln203_103_fu_136574_p1.read().is_01() || !zext_ln703_83_fu_139241_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_103_fu_136574_p1.read()) + sc_biguint<12>(zext_ln703_83_fu_139241_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_628_fu_139255_p2() {
    add_ln703_628_fu_139255_p2 = (!zext_ln203_13_fu_135354_p1.read().is_01() || !zext_ln203_45_fu_136544_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_13_fu_135354_p1.read()) + sc_biguint<10>(zext_ln203_45_fu_136544_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_629_fu_125764_p2() {
    add_ln703_629_fu_125764_p2 = (!sext_ln203_99_fu_122585_p1.read().is_01() || !zext_ln203_46_fu_122593_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_99_fu_122585_p1.read()) + sc_biguint<10>(zext_ln203_46_fu_122593_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_630_fu_139268_p2() {
    add_ln703_630_fu_139268_p2 = (!zext_ln703_84_fu_139261_p1.read().is_01() || !sext_ln703_369_fu_139265_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_84_fu_139261_p1.read()) + sc_bigint<12>(sext_ln703_369_fu_139265_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_631_fu_139278_p2() {
    add_ln703_631_fu_139278_p2 = (!sext_ln703_368_fu_139251_p1.read().is_01() || !sext_ln703_370_fu_139274_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_368_fu_139251_p1.read()) + sc_bigint<13>(sext_ln703_370_fu_139274_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_633_fu_125770_p2() {
    add_ln703_633_fu_125770_p2 = (!sext_ln1118_212_fu_122628_p1.read().is_01() || !ap_const_lv9_180.is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_212_fu_122628_p1.read()) + sc_bigint<9>(ap_const_lv9_180));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_634_fu_125780_p2() {
    add_ln703_634_fu_125780_p2 = (!sext_ln1118_213_fu_122648_p1.read().is_01() || !sext_ln1118_214_fu_122668_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_213_fu_122648_p1.read()) + sc_bigint<10>(sext_ln1118_214_fu_122668_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_635_fu_125786_p2() {
    add_ln703_635_fu_125786_p2 = (!sext_ln703_372_fu_125776_p1.read().is_01() || !add_ln703_634_fu_125780_p2.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln703_372_fu_125776_p1.read()) + sc_biguint<10>(add_ln703_634_fu_125780_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_636_fu_125796_p2() {
    add_ln703_636_fu_125796_p2 = (!sext_ln1118_217_fu_122739_p1.read().is_01() || !sext_ln703_373_fu_125792_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_217_fu_122739_p1.read()) + sc_bigint<12>(sext_ln703_373_fu_125792_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_637_fu_125802_p2() {
    add_ln703_637_fu_125802_p2 = (!zext_ln1118_388_fu_122706_p1.read().is_01() || !trunc_ln1118_12_fu_122696_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_388_fu_122706_p1.read()) + sc_biguint<9>(trunc_ln1118_12_fu_122696_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_638_fu_125812_p2() {
    add_ln703_638_fu_125812_p2 = (!add_ln703_636_fu_125796_p2.read().is_01() || !zext_ln703_85_fu_125808_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_636_fu_125796_p2.read()) + sc_biguint<12>(zext_ln703_85_fu_125808_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_639_fu_125822_p2() {
    add_ln703_639_fu_125822_p2 = (!sext_ln1118_218_fu_122743_p1.read().is_01() || !zext_ln708_127_fu_122770_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_218_fu_122743_p1.read()) + sc_biguint<11>(zext_ln708_127_fu_122770_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_640_fu_125828_p2() {
    add_ln703_640_fu_125828_p2 = (!sext_ln1118_215_fu_122692_p1.read().is_01() || !sext_ln1118_220_fu_122747_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_215_fu_122692_p1.read()) + sc_bigint<8>(sext_ln1118_220_fu_122747_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_641_fu_125838_p2() {
    add_ln703_641_fu_125838_p2 = (!add_ln703_639_fu_125822_p2.read().is_01() || !sext_ln703_375_fu_125834_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_639_fu_125822_p2.read()) + sc_bigint<11>(sext_ln703_375_fu_125834_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_642_fu_125848_p2() {
    add_ln703_642_fu_125848_p2 = (!sext_ln703_374_fu_125818_p1.read().is_01() || !sext_ln703_376_fu_125844_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_374_fu_125818_p1.read()) + sc_bigint<13>(sext_ln703_376_fu_125844_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_643_fu_125854_p2() {
    add_ln703_643_fu_125854_p2 = (!zext_ln708_128_fu_122794_p1.read().is_01() || !add_ln703_642_fu_125848_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln708_128_fu_122794_p1.read()) + sc_biguint<13>(add_ln703_642_fu_125848_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_644_fu_132874_p2() {
    add_ln703_644_fu_132874_p2 = (!sext_ln1118_223_fu_128927_p1.read().is_01() || !sext_ln1118_221_fu_128898_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_223_fu_128927_p1.read()) + sc_bigint<11>(sext_ln1118_221_fu_128898_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_645_fu_132884_p2() {
    add_ln703_645_fu_132884_p2 = (!zext_ln1118_395_fu_128931_p1.read().is_01() || !sext_ln703_378_fu_132880_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_395_fu_128931_p1.read()) + sc_bigint<12>(sext_ln703_378_fu_132880_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_646_fu_132894_p2() {
    add_ln703_646_fu_132894_p2 = (!sext_ln703_377_fu_132871_p1.read().is_01() || !sext_ln703_379_fu_132890_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_377_fu_132871_p1.read()) + sc_bigint<14>(sext_ln703_379_fu_132890_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_647_fu_125860_p2() {
    add_ln703_647_fu_125860_p2 = (!sext_ln1118_229_fu_122868_p1.read().is_01() || !sext_ln1118_228_fu_122864_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_229_fu_122868_p1.read()) + sc_bigint<11>(sext_ln1118_228_fu_122864_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_648_fu_125870_p2() {
    add_ln703_648_fu_125870_p2 = (!sext_ln1118_225_fu_122815_p1.read().is_01() || !sext_ln703_380_fu_125866_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_225_fu_122815_p1.read()) + sc_bigint<12>(sext_ln703_380_fu_125866_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_649_fu_125876_p2() {
    add_ln703_649_fu_125876_p2 = (!zext_ln1118_392_fu_122798_p1.read().is_01() || !sext_ln1118_224_fu_122811_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_392_fu_122798_p1.read()) + sc_bigint<9>(sext_ln1118_224_fu_122811_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_650_fu_125886_p2() {
    add_ln703_650_fu_125886_p2 = (!sext_ln1118_227_fu_122860_p1.read().is_01() || !sext_ln703_381_fu_125882_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_227_fu_122860_p1.read()) + sc_bigint<10>(sext_ln703_381_fu_125882_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_651_fu_125896_p2() {
    add_ln703_651_fu_125896_p2 = (!add_ln703_648_fu_125870_p2.read().is_01() || !sext_ln703_382_fu_125892_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_648_fu_125870_p2.read()) + sc_bigint<12>(sext_ln703_382_fu_125892_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_652_fu_132903_p2() {
    add_ln703_652_fu_132903_p2 = (!add_ln703_646_fu_132894_p2.read().is_01() || !sext_ln703_383_fu_132900_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_646_fu_132894_p2.read()) + sc_bigint<14>(sext_ln703_383_fu_132900_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_653_fu_139297_p2() {
    add_ln703_653_fu_139297_p2 = (!sext_ln203_110_fu_136601_p1.read().is_01() || !sext_ln203_108_fu_136584_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_110_fu_136601_p1.read()) + sc_bigint<12>(sext_ln203_108_fu_136584_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_654_fu_139307_p2() {
    add_ln703_654_fu_139307_p2 = (!sext_ln703_384_fu_139294_p1.read().is_01() || !sext_ln703_385_fu_139303_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_384_fu_139294_p1.read()) + sc_bigint<15>(sext_ln703_385_fu_139303_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_655_fu_139313_p2() {
    add_ln703_655_fu_139313_p2 = (!zext_ln203_49_fu_136656_p1.read().is_01() || !zext_ln203_48_fu_136624_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_49_fu_136656_p1.read()) + sc_biguint<9>(zext_ln203_48_fu_136624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_656_fu_139319_p2() {
    add_ln703_656_fu_139319_p2 = (!zext_ln203_47_fu_136581_p1.read().is_01() || !add_ln703_655_fu_139313_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_47_fu_136581_p1.read()) + sc_biguint<9>(add_ln703_655_fu_139313_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_657_fu_139329_p2() {
    add_ln703_657_fu_139329_p2 = (!add_ln703_654_fu_139307_p2.read().is_01() || !zext_ln703_86_fu_139325_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_654_fu_139307_p2.read()) + sc_biguint<15>(zext_ln703_86_fu_139325_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_658_fu_125902_p2() {
    add_ln703_658_fu_125902_p2 = (!sext_ln203_107_fu_122886_p1.read().is_01() || !sext_ln203_106_fu_122882_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_107_fu_122886_p1.read()) + sc_bigint<11>(sext_ln203_106_fu_122882_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_659_fu_132912_p2() {
    add_ln703_659_fu_132912_p2 = (!sext_ln203_104_fu_128954_p1.read().is_01() || !sext_ln703_386_fu_132909_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_104_fu_128954_p1.read()) + sc_bigint<12>(sext_ln703_386_fu_132909_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_660_fu_139338_p2() {
    add_ln703_660_fu_139338_p2 = (!sext_ln203_105_fu_136578_p1.read().is_01() || !sext_ln203_111_fu_136628_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_105_fu_136578_p1.read()) + sc_bigint<11>(sext_ln203_111_fu_136628_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_661_fu_139344_p2() {
    add_ln703_661_fu_139344_p2 = (!sext_ln203_112_fu_136652_p1.read().is_01() || !sext_ln203_109_fu_136588_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_112_fu_136652_p1.read()) + sc_bigint<9>(sext_ln203_109_fu_136588_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_662_fu_139354_p2() {
    add_ln703_662_fu_139354_p2 = (!add_ln703_660_fu_139338_p2.read().is_01() || !sext_ln703_388_fu_139350_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_660_fu_139338_p2.read()) + sc_bigint<11>(sext_ln703_388_fu_139350_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_663_fu_139364_p2() {
    add_ln703_663_fu_139364_p2 = (!sext_ln703_387_fu_139335_p1.read().is_01() || !sext_ln703_389_fu_139360_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_387_fu_139335_p1.read()) + sc_bigint<13>(sext_ln703_389_fu_139360_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_665_fu_125908_p2() {
    add_ln703_665_fu_125908_p2 = (!sext_ln1118_211_fu_122624_p1.read().is_01() || !ap_const_lv10_218.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_211_fu_122624_p1.read()) + sc_bigint<10>(ap_const_lv10_218));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_666_fu_125918_p2() {
    add_ln703_666_fu_125918_p2 = (!sext_ln1118_231_fu_122890_p1.read().is_01() || !sext_ln1118_232_fu_122894_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_231_fu_122890_p1.read()) + sc_bigint<12>(sext_ln1118_232_fu_122894_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_667_fu_125928_p2() {
    add_ln703_667_fu_125928_p2 = (!zext_ln703_87_fu_125914_p1.read().is_01() || !sext_ln703_392_fu_125924_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_87_fu_125914_p1.read()) + sc_bigint<13>(sext_ln703_392_fu_125924_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_668_fu_125934_p2() {
    add_ln703_668_fu_125934_p2 = (!zext_ln1118_402_fu_122917_p1.read().is_01() || !sext_ln1118_233_fu_122913_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_402_fu_122917_p1.read()) + sc_bigint<12>(sext_ln1118_233_fu_122913_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_669_fu_125944_p2() {
    add_ln703_669_fu_125944_p2 = (!add_ln703_667_fu_125928_p2.read().is_01() || !sext_ln703_393_fu_125940_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_667_fu_125928_p2.read()) + sc_bigint<13>(sext_ln703_393_fu_125940_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_670_fu_125954_p2() {
    add_ln703_670_fu_125954_p2 = (!sext_ln1118_234_fu_122941_p1.read().is_01() || !sext_ln1118_235_fu_122959_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_234_fu_122941_p1.read()) + sc_bigint<10>(sext_ln1118_235_fu_122959_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_671_fu_125964_p2() {
    add_ln703_671_fu_125964_p2 = (!zext_ln708_129_fu_122955_p1.read().is_01() || !sext_ln703_395_fu_125960_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_129_fu_122955_p1.read()) + sc_bigint<11>(sext_ln703_395_fu_125960_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_672_fu_125974_p2() {
    add_ln703_672_fu_125974_p2 = (!sext_ln703_394_fu_125950_p1.read().is_01() || !sext_ln703_396_fu_125970_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_394_fu_125950_p1.read()) + sc_bigint<14>(sext_ln703_396_fu_125970_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_673_fu_125980_p2() {
    add_ln703_673_fu_125980_p2 = (!sext_ln1116_8_fu_119315_p1.read().is_01() || !sext_ln1118_201_fu_122371_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_8_fu_119315_p1.read()) + sc_bigint<12>(sext_ln1118_201_fu_122371_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_674_fu_125990_p2() {
    add_ln703_674_fu_125990_p2 = (!add_ln703_672_fu_125974_p2.read().is_01() || !sext_ln703_397_fu_125986_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_672_fu_125974_p2.read()) + sc_bigint<14>(sext_ln703_397_fu_125986_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_675_fu_132921_p2() {
    add_ln703_675_fu_132921_p2 = (!sext_ln1118_239_fu_129094_p1.read().is_01() || !sext_ln1118_237_fu_129084_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_239_fu_129094_p1.read()) + sc_bigint<12>(sext_ln1118_237_fu_129084_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_676_fu_125996_p2() {
    add_ln703_676_fu_125996_p2 = (!zext_ln1118_404_fu_122963_p1.read().is_01() || !sext_ln1118_240_fu_122967_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_404_fu_122963_p1.read()) + sc_bigint<12>(sext_ln1118_240_fu_122967_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_677_fu_132934_p2() {
    add_ln703_677_fu_132934_p2 = (!sext_ln703_399_fu_132927_p1.read().is_01() || !sext_ln703_400_fu_132931_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_399_fu_132927_p1.read()) + sc_bigint<13>(sext_ln703_400_fu_132931_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_678_fu_132944_p2() {
    add_ln703_678_fu_132944_p2 = (!sext_ln703_398_fu_132918_p1.read().is_01() || !sext_ln703_401_fu_132940_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_398_fu_132918_p1.read()) + sc_bigint<15>(sext_ln703_401_fu_132940_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_679_fu_132950_p2() {
    add_ln703_679_fu_132950_p2 = (!zext_ln1118_408_fu_129087_p1.read().is_01() || !zext_ln1118_407_fu_129081_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_408_fu_129087_p1.read()) + sc_biguint<9>(zext_ln1118_407_fu_129081_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_680_fu_132960_p2() {
    add_ln703_680_fu_132960_p2 = (!zext_ln708_130_fu_129073_p1.read().is_01() || !zext_ln703_88_fu_132956_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_130_fu_129073_p1.read()) + sc_biguint<11>(zext_ln703_88_fu_132956_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_681_fu_132970_p2() {
    add_ln703_681_fu_132970_p2 = (!sext_ln1118_236_fu_129047_p1.read().is_01() || !zext_ln708_131_fu_129114_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_236_fu_129047_p1.read()) + sc_biguint<11>(zext_ln708_131_fu_129114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_682_fu_132976_p2() {
    add_ln703_682_fu_132976_p2 = (!sext_ln1118_238_fu_129090_p1.read().is_01() || !zext_ln1118_406_fu_129077_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_238_fu_129090_p1.read()) + sc_biguint<9>(zext_ln1118_406_fu_129077_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_683_fu_132986_p2() {
    add_ln703_683_fu_132986_p2 = (!add_ln703_681_fu_132970_p2.read().is_01() || !sext_ln703_402_fu_132982_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_681_fu_132970_p2.read()) + sc_bigint<11>(sext_ln703_402_fu_132982_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_684_fu_132996_p2() {
    add_ln703_684_fu_132996_p2 = (!zext_ln703_89_fu_132966_p1.read().is_01() || !sext_ln703_403_fu_132992_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_89_fu_132966_p1.read()) + sc_bigint<13>(sext_ln703_403_fu_132992_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_685_fu_133006_p2() {
    add_ln703_685_fu_133006_p2 = (!add_ln703_678_fu_132944_p2.read().is_01() || !sext_ln703_404_fu_133002_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_678_fu_132944_p2.read()) + sc_bigint<15>(sext_ln703_404_fu_133002_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_686_fu_139384_p2() {
    add_ln703_686_fu_139384_p2 = (!sext_ln203_114_fu_136659_p1.read().is_01() || !add_ln703_685_reg_144288.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_114_fu_136659_p1.read()) + sc_biguint<15>(add_ln703_685_reg_144288.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_687_fu_126002_p2() {
    add_ln703_687_fu_126002_p2 = (!sext_ln203_116_fu_122975_p1.read().is_01() || !sext_ln203_115_fu_122971_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_116_fu_122975_p1.read()) + sc_bigint<12>(sext_ln203_115_fu_122971_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_688_fu_139392_p2() {
    add_ln703_688_fu_139392_p2 = (!sext_ln203_50_fu_135526_p1.read().is_01() || !sext_ln703_405_fu_139389_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_50_fu_135526_p1.read()) + sc_bigint<13>(sext_ln703_405_fu_139389_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_689_fu_139402_p2() {
    add_ln703_689_fu_139402_p2 = (!add_ln703_686_fu_139384_p2.read().is_01() || !sext_ln703_406_fu_139398_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_686_fu_139384_p2.read()) + sc_bigint<15>(sext_ln703_406_fu_139398_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_690_fu_126008_p2() {
    add_ln703_690_fu_126008_p2 = (!sext_ln203_119_fu_122999_p1.read().is_01() || !zext_ln708_132_fu_123003_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_119_fu_122999_p1.read()) + sc_biguint<11>(zext_ln708_132_fu_123003_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_691_fu_139415_p2() {
    add_ln703_691_fu_139415_p2 = (!sext_ln203_94_fu_136464_p1.read().is_01() || !sext_ln703_408_fu_139412_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_94_fu_136464_p1.read()) + sc_bigint<12>(sext_ln703_408_fu_139412_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_692_fu_133012_p2() {
    add_ln703_692_fu_133012_p2 = (!sext_ln203_118_fu_129181_p1.read().is_01() || !sext_ln203_117_fu_129177_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_118_fu_129181_p1.read()) + sc_bigint<9>(sext_ln203_117_fu_129177_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_693_fu_133022_p2() {
    add_ln703_693_fu_133022_p2 = (!sext_ln203_113_fu_129154_p1.read().is_01() || !sext_ln703_410_fu_133018_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_113_fu_129154_p1.read()) + sc_bigint<10>(sext_ln703_410_fu_133018_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_694_fu_139428_p2() {
    add_ln703_694_fu_139428_p2 = (!sext_ln703_409_fu_139421_p1.read().is_01() || !sext_ln703_411_fu_139425_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_409_fu_139421_p1.read()) + sc_bigint<13>(sext_ln703_411_fu_139425_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_696_fu_126014_p2() {
    add_ln703_696_fu_126014_p2 = (!zext_ln203_50_fu_123021_p1.read().is_01() || !sext_ln203_120_fu_123017_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_50_fu_123021_p1.read()) + sc_bigint<12>(sext_ln203_120_fu_123017_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_697_fu_126020_p2() {
    add_ln703_697_fu_126020_p2 = (!zext_ln1118_412_fu_123055_p1.read().is_01() || !ap_const_lv10_290.is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_412_fu_123055_p1.read()) + sc_bigint<10>(ap_const_lv10_290));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_698_fu_126030_p2() {
    add_ln703_698_fu_126030_p2 = (!zext_ln708_133_fu_123024_p1.read().is_01() || !sext_ln703_413_fu_126026_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_133_fu_123024_p1.read()) + sc_bigint<11>(sext_ln703_413_fu_126026_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_699_fu_126040_p2() {
    add_ln703_699_fu_126040_p2 = (!add_ln703_696_fu_126014_p2.read().is_01() || !sext_ln703_414_fu_126036_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_696_fu_126014_p2.read()) + sc_bigint<12>(sext_ln703_414_fu_126036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_700_fu_126046_p2() {
    add_ln703_700_fu_126046_p2 = (!zext_ln1118_414_fu_123106_p1.read().is_01() || !add_ln703_699_fu_126040_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_414_fu_123106_p1.read()) + sc_biguint<12>(add_ln703_699_fu_126040_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_701_fu_126056_p2() {
    add_ln703_701_fu_126056_p2 = (!sext_ln1118_242_fu_123086_p1.read().is_01() || !sext_ln1118_243_fu_123130_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_242_fu_123086_p1.read()) + sc_bigint<11>(sext_ln1118_243_fu_123130_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_702_fu_126066_p2() {
    add_ln703_702_fu_126066_p2 = (!sext_ln703_415_fu_126052_p1.read().is_01() || !sext_ln703_416_fu_126062_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_415_fu_126052_p1.read()) + sc_bigint<13>(sext_ln703_416_fu_126062_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_703_fu_126072_p2() {
    add_ln703_703_fu_126072_p2 = (!sext_ln1118_244_fu_123134_p1.read().is_01() || !add_ln703_702_fu_126066_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_244_fu_123134_p1.read()) + sc_biguint<13>(add_ln703_702_fu_126066_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_704_fu_126078_p2() {
    add_ln703_704_fu_126078_p2 = (!sext_ln1118_247_fu_123199_p1.read().is_01() || !zext_ln708_134_fu_123203_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_247_fu_123199_p1.read()) + sc_biguint<10>(zext_ln708_134_fu_123203_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_705_fu_126088_p2() {
    add_ln703_705_fu_126088_p2 = (!sext_ln1118_246_fu_123175_p1.read().is_01() || !sext_ln703_418_fu_126084_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_246_fu_123175_p1.read()) + sc_bigint<12>(sext_ln703_418_fu_126084_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_706_fu_133034_p2() {
    add_ln703_706_fu_133034_p2 = (!sext_ln703_417_fu_133028_p1.read().is_01() || !sext_ln703_419_fu_133031_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_417_fu_133028_p1.read()) + sc_bigint<14>(sext_ln703_419_fu_133031_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_707_fu_133040_p2() {
    add_ln703_707_fu_133040_p2 = (!zext_ln708_136_fu_129204_p1.read().is_01() || !zext_ln708_135_fu_129200_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_136_fu_129204_p1.read()) + sc_biguint<11>(zext_ln708_135_fu_129200_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_708_fu_133050_p2() {
    add_ln703_708_fu_133050_p2 = (!add_ln703_706_fu_133034_p2.read().is_01() || !zext_ln703_90_fu_133046_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_706_fu_133034_p2.read()) + sc_biguint<14>(zext_ln703_90_fu_133046_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_709_fu_126094_p2() {
    add_ln703_709_fu_126094_p2 = (!zext_ln708_139_fu_123235_p1.read().is_01() || !zext_ln708_138_fu_123231_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_139_fu_123235_p1.read()) + sc_biguint<11>(zext_ln708_138_fu_123231_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_710_fu_126104_p2() {
    add_ln703_710_fu_126104_p2 = (!zext_ln1118_421_fu_123227_p1.read().is_01() || !zext_ln703_91_fu_126100_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_421_fu_123227_p1.read()) + sc_biguint<12>(zext_ln703_91_fu_126100_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_711_fu_133063_p2() {
    add_ln703_711_fu_133063_p2 = (!sext_ln703_420_fu_133056_p1.read().is_01() || !zext_ln703_92_fu_133060_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_420_fu_133056_p1.read()) + sc_biguint<15>(zext_ln703_92_fu_133060_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_712_fu_133069_p2() {
    add_ln703_712_fu_133069_p2 = (!sext_ln708_74_fu_129237_p1.read().is_01() || !sext_ln1118_248_fu_129244_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_74_fu_129237_p1.read()) + sc_bigint<11>(sext_ln1118_248_fu_129244_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_713_fu_139447_p2() {
    add_ln703_713_fu_139447_p2 = (!zext_ln1118_422_fu_136663_p1.read().is_01() || !sext_ln703_421_fu_139444_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_422_fu_136663_p1.read()) + sc_bigint<12>(sext_ln703_421_fu_139444_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_714_fu_133075_p2() {
    add_ln703_714_fu_133075_p2 = (!sext_ln1118_249_fu_129294_p1.read().is_01() || !zext_ln1118_420_fu_129241_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_249_fu_129294_p1.read()) + sc_biguint<9>(zext_ln1118_420_fu_129241_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_715_fu_133085_p2() {
    add_ln703_715_fu_133085_p2 = (!sext_ln708_75_fu_129263_p1.read().is_01() || !sext_ln703_422_fu_133081_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_75_fu_129263_p1.read()) + sc_bigint<10>(sext_ln703_422_fu_133081_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_716_fu_139456_p2() {
    add_ln703_716_fu_139456_p2 = (!add_ln703_713_fu_139447_p2.read().is_01() || !sext_ln703_423_fu_139453_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_713_fu_139447_p2.read()) + sc_bigint<12>(sext_ln703_423_fu_139453_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_717_fu_139466_p2() {
    add_ln703_717_fu_139466_p2 = (!add_ln703_711_reg_144298.read().is_01() || !sext_ln703_424_fu_139462_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_711_reg_144298.read()) + sc_bigint<15>(sext_ln703_424_fu_139462_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_718_fu_139471_p2() {
    add_ln703_718_fu_139471_p2 = (!sext_ln203_121_fu_136667_p1.read().is_01() || !add_ln703_717_fu_139466_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_121_fu_136667_p1.read()) + sc_biguint<15>(add_ln703_717_fu_139466_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_719_fu_139477_p2() {
    add_ln703_719_fu_139477_p2 = (!zext_ln203_51_fu_136675_p1.read().is_01() || !grp_fu_117264_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_51_fu_136675_p1.read()) + sc_biguint<10>(grp_fu_117264_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_720_fu_139487_p2() {
    add_ln703_720_fu_139487_p2 = (!zext_ln708_140_fu_136671_p1.read().is_01() || !zext_ln703_93_fu_139483_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_140_fu_136671_p1.read()) + sc_biguint<11>(zext_ln703_93_fu_139483_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_721_fu_139497_p2() {
    add_ln703_721_fu_139497_p2 = (!add_ln703_718_fu_139471_p2.read().is_01() || !zext_ln703_94_fu_139493_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_718_fu_139471_p2.read()) + sc_biguint<15>(zext_ln703_94_fu_139493_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_722_fu_139503_p2() {
    add_ln703_722_fu_139503_p2 = (!zext_ln708_142_fu_136692_p1.read().is_01() || !zext_ln708_141_fu_136688_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_142_fu_136692_p1.read()) + sc_biguint<11>(zext_ln708_141_fu_136688_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_723_fu_139509_p2() {
    add_ln703_723_fu_139509_p2 = (!zext_ln708_126_fu_136541_p1.read().is_01() || !add_ln703_722_fu_139503_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_126_fu_136541_p1.read()) + sc_biguint<11>(add_ln703_722_fu_139503_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_724_fu_133091_p2() {
    add_ln703_724_fu_133091_p2 = (!sext_ln203_122_fu_129314_p1.read().is_01() || !zext_ln203_52_fu_129318_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln203_122_fu_129314_p1.read()) + sc_biguint<7>(zext_ln203_52_fu_129318_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_725_fu_139522_p2() {
    add_ln703_725_fu_139522_p2 = (!sext_ln203_60_fu_135618_p1.read().is_01() || !sext_ln703_425_fu_139519_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_60_fu_135618_p1.read()) + sc_bigint<9>(sext_ln703_425_fu_139519_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_726_fu_139532_p2() {
    add_ln703_726_fu_139532_p2 = (!zext_ln703_95_fu_139515_p1.read().is_01() || !sext_ln703_426_fu_139528_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_95_fu_139515_p1.read()) + sc_bigint<12>(sext_ln703_426_fu_139528_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_728_fu_126110_p2() {
    add_ln703_728_fu_126110_p2 = (!zext_ln708_144_fu_123259_p1.read().is_01() || !ap_const_lv11_468.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_144_fu_123259_p1.read()) + sc_bigint<11>(ap_const_lv11_468));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_729_fu_126120_p2() {
    add_ln703_729_fu_126120_p2 = (!sext_ln203_123_fu_123279_p1.read().is_01() || !sext_ln703_227_fu_126116_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_123_fu_123279_p1.read()) + sc_bigint<12>(sext_ln703_227_fu_126116_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_730_fu_126130_p2() {
    add_ln703_730_fu_126130_p2 = (!zext_ln1116_43_fu_123286_p1.read().is_01() || !sext_ln1116_28_fu_123310_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_43_fu_123286_p1.read()) + sc_bigint<12>(sext_ln1116_28_fu_123310_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_731_fu_126140_p2() {
    add_ln703_731_fu_126140_p2 = (!sext_ln703_228_fu_126126_p1.read().is_01() || !sext_ln703_429_fu_126136_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_228_fu_126126_p1.read()) + sc_bigint<13>(sext_ln703_429_fu_126136_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_732_fu_126146_p2() {
    add_ln703_732_fu_126146_p2 = (!sext_ln1118_250_fu_123283_p1.read().is_01() || !zext_ln708_146_fu_123318_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_250_fu_123283_p1.read()) + sc_biguint<11>(zext_ln708_146_fu_123318_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_733_fu_126152_p2() {
    add_ln703_733_fu_126152_p2 = (!zext_ln708_145_fu_123314_p1.read().is_01() || !add_ln703_732_fu_126146_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_145_fu_123314_p1.read()) + sc_biguint<11>(add_ln703_732_fu_126146_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_734_fu_126162_p2() {
    add_ln703_734_fu_126162_p2 = (!add_ln703_731_fu_126140_p2.read().is_01() || !sext_ln703_430_fu_126158_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_731_fu_126140_p2.read()) + sc_bigint<13>(sext_ln703_430_fu_126158_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_735_fu_126168_p2() {
    add_ln703_735_fu_126168_p2 = (!sext_ln1118_252_fu_123342_p1.read().is_01() || !add_ln703_734_fu_126162_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_252_fu_123342_p1.read()) + sc_biguint<13>(add_ln703_734_fu_126162_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_736_fu_133100_p2() {
    add_ln703_736_fu_133100_p2 = (!sext_ln1116_29_fu_129358_p1.read().is_01() || !sext_ln1118_253_fu_129321_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_29_fu_129358_p1.read()) + sc_bigint<12>(sext_ln1118_253_fu_129321_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_737_fu_133110_p2() {
    add_ln703_737_fu_133110_p2 = (!sext_ln703_431_fu_133097_p1.read().is_01() || !sext_ln703_432_fu_133106_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_431_fu_133097_p1.read()) + sc_bigint<14>(sext_ln703_432_fu_133106_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_738_fu_126174_p2() {
    add_ln703_738_fu_126174_p2 = (!zext_ln1118_428_fu_123400_p1.read().is_01() || !zext_ln1118_427_fu_123396_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_428_fu_123400_p1.read()) + sc_biguint<9>(zext_ln1118_427_fu_123396_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_739_fu_126184_p2() {
    add_ln703_739_fu_126184_p2 = (!sext_ln1118_255_fu_123372_p1.read().is_01() || !zext_ln708_147_fu_123414_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_255_fu_123372_p1.read()) + sc_biguint<11>(zext_ln708_147_fu_123414_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_740_fu_126190_p2() {
    add_ln703_740_fu_126190_p2 = (!zext_ln703_96_fu_126180_p1.read().is_01() || !add_ln703_739_fu_126184_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_96_fu_126180_p1.read()) + sc_biguint<11>(add_ln703_739_fu_126184_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_741_fu_133119_p2() {
    add_ln703_741_fu_133119_p2 = (!add_ln703_737_fu_133110_p2.read().is_01() || !sext_ln703_433_fu_133116_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_737_fu_133110_p2.read()) + sc_bigint<14>(sext_ln703_433_fu_133116_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_742_fu_133125_p2() {
    add_ln703_742_fu_133125_p2 = (!zext_ln1118_431_fu_129362_p1.read().is_01() || !add_ln703_741_fu_133119_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_431_fu_129362_p1.read()) + sc_biguint<14>(add_ln703_741_fu_133119_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_743_fu_126196_p2() {
    add_ln703_743_fu_126196_p2 = (!zext_ln708_150_fu_123488_p1.read().is_01() || !zext_ln708_149_fu_123438_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_150_fu_123488_p1.read()) + sc_biguint<11>(zext_ln708_149_fu_123438_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_744_fu_126202_p2() {
    add_ln703_744_fu_126202_p2 = (!zext_ln708_148_fu_123434_p1.read().is_01() || !add_ln703_743_fu_126196_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_148_fu_123434_p1.read()) + sc_biguint<11>(add_ln703_743_fu_126196_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_745_fu_139558_p2() {
    add_ln703_745_fu_139558_p2 = (!sext_ln703_434_fu_139552_p1.read().is_01() || !zext_ln703_97_fu_139555_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_434_fu_139552_p1.read()) + sc_biguint<15>(zext_ln703_97_fu_139555_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_746_fu_133131_p2() {
    add_ln703_746_fu_133131_p2 = (!sext_ln1118_258_fu_129399_p1.read().is_01() || !sext_ln1116_30_fu_129395_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_258_fu_129399_p1.read()) + sc_bigint<10>(sext_ln1116_30_fu_129395_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_747_fu_133141_p2() {
    add_ln703_747_fu_133141_p2 = (!zext_ln708_151_fu_129440_p1.read().is_01() || !sext_ln703_435_fu_133137_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_151_fu_129440_p1.read()) + sc_bigint<11>(sext_ln703_435_fu_133137_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_748_fu_133147_p2() {
    add_ln703_748_fu_133147_p2 = (!sext_ln1116_31_fu_129402_p1.read().is_01() || !sext_ln708_76_fu_129410_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1116_31_fu_129402_p1.read()) + sc_bigint<9>(sext_ln708_76_fu_129410_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_749_fu_133157_p2() {
    add_ln703_749_fu_133157_p2 = (!sext_ln1118_259_fu_129406_p1.read().is_01() || !sext_ln703_436_fu_133153_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_259_fu_129406_p1.read()) + sc_bigint<10>(sext_ln703_436_fu_133153_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_750_fu_133167_p2() {
    add_ln703_750_fu_133167_p2 = (!add_ln703_747_fu_133141_p2.read().is_01() || !sext_ln703_437_fu_133163_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_747_fu_133141_p2.read()) + sc_bigint<11>(sext_ln703_437_fu_133163_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_751_fu_139567_p2() {
    add_ln703_751_fu_139567_p2 = (!add_ln703_745_fu_139558_p2.read().is_01() || !sext_ln703_438_fu_139564_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_745_fu_139558_p2.read()) + sc_bigint<15>(sext_ln703_438_fu_139564_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_752_fu_139573_p2() {
    add_ln703_752_fu_139573_p2 = (!zext_ln203_53_fu_136696_p1.read().is_01() || !add_ln703_751_fu_139567_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_53_fu_136696_p1.read()) + sc_biguint<15>(add_ln703_751_fu_139567_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_753_fu_139579_p2() {
    add_ln703_753_fu_139579_p2 = (!zext_ln203_54_fu_136716_p1.read().is_01() || !sext_ln203_125_fu_136734_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_54_fu_136716_p1.read()) + sc_bigint<12>(sext_ln203_125_fu_136734_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_754_fu_139589_p2() {
    add_ln703_754_fu_139589_p2 = (!add_ln703_752_fu_139573_p2.read().is_01() || !sext_ln703_439_fu_139585_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_752_fu_139573_p2.read()) + sc_bigint<15>(sext_ln703_439_fu_139585_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_755_fu_139595_p2() {
    add_ln703_755_fu_139595_p2 = (!trunc_ln203_1_fu_136772_p4.read().is_01() || !zext_ln203_55_fu_136754_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln203_1_fu_136772_p4.read()) + sc_biguint<10>(zext_ln203_55_fu_136754_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_756_fu_139605_p2() {
    add_ln703_756_fu_139605_p2 = (!sext_ln203_124_fu_136720_p1.read().is_01() || !zext_ln708_154_fu_136786_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_124_fu_136720_p1.read()) + sc_biguint<11>(zext_ln708_154_fu_136786_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_757_fu_139615_p2() {
    add_ln703_757_fu_139615_p2 = (!zext_ln203_56_fu_136782_p1.read().is_01() || !sext_ln703_440_fu_139611_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_56_fu_136782_p1.read()) + sc_bigint<12>(sext_ln703_440_fu_139611_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_758_fu_139621_p2() {
    add_ln703_758_fu_139621_p2 = (!zext_ln703_98_fu_139601_p1.read().is_01() || !add_ln703_757_fu_139615_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_98_fu_139601_p1.read()) + sc_biguint<12>(add_ln703_757_fu_139615_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_760_fu_126208_p2() {
    add_ln703_760_fu_126208_p2 = (!zext_ln708_155_fu_123496_p1.read().is_01() || !ap_const_lv11_438.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_155_fu_123496_p1.read()) + sc_bigint<11>(ap_const_lv11_438));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_761_fu_126218_p2() {
    add_ln703_761_fu_126218_p2 = (!sext_ln1118_261_fu_123492_p1.read().is_01() || !zext_ln708_156_fu_123527_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_261_fu_123492_p1.read()) + sc_biguint<11>(zext_ln708_156_fu_123527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_762_fu_126228_p2() {
    add_ln703_762_fu_126228_p2 = (!zext_ln203_57_fu_123500_p1.read().is_01() || !sext_ln703_444_fu_126224_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_57_fu_123500_p1.read()) + sc_bigint<12>(sext_ln703_444_fu_126224_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_763_fu_126234_p2() {
    add_ln703_763_fu_126234_p2 = (!sext_ln703_443_fu_126214_p1.read().is_01() || !add_ln703_762_fu_126228_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_443_fu_126214_p1.read()) + sc_biguint<12>(add_ln703_762_fu_126228_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_764_fu_126244_p2() {
    add_ln703_764_fu_126244_p2 = (!sext_ln203_126_fu_123535_p1.read().is_01() || !sext_ln703_232_fu_126240_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_126_fu_123535_p1.read()) + sc_bigint<13>(sext_ln703_232_fu_126240_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_765_fu_126250_p2() {
    add_ln703_765_fu_126250_p2 = (!sext_ln1118_262_fu_123531_p1.read().is_01() || !zext_ln1118_435_fu_123555_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_262_fu_123531_p1.read()) + sc_biguint<10>(zext_ln1118_435_fu_123555_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_766_fu_126260_p2() {
    add_ln703_766_fu_126260_p2 = (!add_ln703_764_fu_126244_p2.read().is_01() || !sext_ln703_445_fu_126256_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_764_fu_126244_p2.read()) + sc_bigint<13>(sext_ln703_445_fu_126256_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_767_fu_133176_p2() {
    add_ln703_767_fu_133176_p2 = (!sext_ln1118_264_fu_129451_p1.read().is_01() || !sext_ln1118_263_fu_129444_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_264_fu_129451_p1.read()) + sc_bigint<12>(sext_ln1118_263_fu_129444_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_768_fu_133186_p2() {
    add_ln703_768_fu_133186_p2 = (!sext_ln703_233_fu_133173_p1.read().is_01() || !sext_ln703_446_fu_133182_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_233_fu_133173_p1.read()) + sc_bigint<14>(sext_ln703_446_fu_133182_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_769_fu_133192_p2() {
    add_ln703_769_fu_133192_p2 = (!zext_ln1118_436_fu_129448_p1.read().is_01() || !sext_ln708_77_fu_129459_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_436_fu_129448_p1.read()) + sc_bigint<12>(sext_ln708_77_fu_129459_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_770_fu_133202_p2() {
    add_ln703_770_fu_133202_p2 = (!grp_fu_116554_p4.read().is_01() || !zext_ln1118_437_fu_129455_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_116554_p4.read()) + sc_biguint<10>(zext_ln1118_437_fu_129455_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_771_fu_133212_p2() {
    add_ln703_771_fu_133212_p2 = (!sext_ln703_447_fu_133198_p1.read().is_01() || !zext_ln703_99_fu_133208_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_447_fu_133198_p1.read()) + sc_biguint<13>(zext_ln703_99_fu_133208_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_772_fu_139644_p2() {
    add_ln703_772_fu_139644_p2 = (!add_ln703_768_reg_144328.read().is_01() || !sext_ln703_448_fu_139641_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_768_reg_144328.read()) + sc_bigint<14>(sext_ln703_448_fu_139641_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_773_fu_139649_p2() {
    add_ln703_773_fu_139649_p2 = (!sext_ln1118_267_fu_136800_p1.read().is_01() || !add_ln703_772_fu_139644_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_267_fu_136800_p1.read()) + sc_biguint<14>(add_ln703_772_fu_139644_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_774_fu_133218_p2() {
    add_ln703_774_fu_133218_p2 = (!zext_ln1118_438_fu_129466_p1.read().is_01() || !sext_ln1118_269_fu_129532_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_438_fu_129466_p1.read()) + sc_bigint<12>(sext_ln1118_269_fu_129532_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_775_fu_139662_p2() {
    add_ln703_775_fu_139662_p2 = (!sext_ln703_449_fu_139655_p1.read().is_01() || !sext_ln703_450_fu_139659_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_449_fu_139655_p1.read()) + sc_bigint<15>(sext_ln703_450_fu_139659_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_776_fu_139668_p2() {
    add_ln703_776_fu_139668_p2 = (!grp_fu_116404_p4.read().is_01() || !zext_ln1118_439_fu_136804_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(grp_fu_116404_p4.read()) + sc_biguint<8>(zext_ln1118_439_fu_136804_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_777_fu_133224_p2() {
    add_ln703_777_fu_133224_p2 = (!trunc_ln1118_15_fu_129541_p4.read().is_01() || !zext_ln1118_442_fu_129509_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln1118_15_fu_129541_p4.read()) + sc_biguint<9>(zext_ln1118_442_fu_129509_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_778_fu_133230_p2() {
    add_ln703_778_fu_133230_p2 = (!zext_ln1118_441_fu_129489_p1.read().is_01() || !add_ln703_777_fu_133224_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_441_fu_129489_p1.read()) + sc_biguint<9>(add_ln703_777_fu_133224_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_779_fu_139681_p2() {
    add_ln703_779_fu_139681_p2 = (!zext_ln703_100_fu_139674_p1.read().is_01() || !zext_ln703_101_fu_139678_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln703_100_fu_139674_p1.read()) + sc_biguint<10>(zext_ln703_101_fu_139678_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_780_fu_139691_p2() {
    add_ln703_780_fu_139691_p2 = (!add_ln703_775_fu_139662_p2.read().is_01() || !zext_ln703_102_fu_139687_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_775_fu_139662_p2.read()) + sc_biguint<15>(zext_ln703_102_fu_139687_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_781_fu_133236_p2() {
    add_ln703_781_fu_133236_p2 = (!grp_fu_117564_p4.read().is_01() || !zext_ln1118_444_fu_129578_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_117564_p4.read()) + sc_biguint<10>(zext_ln1118_444_fu_129578_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_782_fu_133246_p2() {
    add_ln703_782_fu_133246_p2 = (!zext_ln708_159_fu_129600_p1.read().is_01() || !zext_ln708_158_fu_129586_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_159_fu_129600_p1.read()) + sc_biguint<11>(zext_ln708_158_fu_129586_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_783_fu_133252_p2() {
    add_ln703_783_fu_133252_p2 = (!zext_ln708_157_fu_129582_p1.read().is_01() || !add_ln703_782_fu_133246_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_157_fu_129582_p1.read()) + sc_biguint<11>(add_ln703_782_fu_133246_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_784_fu_133262_p2() {
    add_ln703_784_fu_133262_p2 = (!zext_ln703_103_fu_133242_p1.read().is_01() || !zext_ln703_104_fu_133258_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_103_fu_133242_p1.read()) + sc_biguint<12>(zext_ln703_104_fu_133258_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_785_fu_133268_p2() {
    add_ln703_785_fu_133268_p2 = (!zext_ln708_160_fu_129612_p1.read().is_01() || !zext_ln1118_445_fu_129608_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_160_fu_129612_p1.read()) + sc_biguint<10>(zext_ln1118_445_fu_129608_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_786_fu_133274_p2() {
    add_ln703_786_fu_133274_p2 = (!sext_ln1118_270_fu_129604_p1.read().is_01() || !sext_ln1118_266_fu_129463_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_270_fu_129604_p1.read()) + sc_bigint<10>(sext_ln1118_266_fu_129463_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_787_fu_139706_p2() {
    add_ln703_787_fu_139706_p2 = (!zext_ln1118_446_fu_136807_p1.read().is_01() || !sext_ln703_451_fu_139703_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_446_fu_136807_p1.read()) + sc_bigint<12>(sext_ln703_451_fu_139703_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_788_fu_139712_p2() {
    add_ln703_788_fu_139712_p2 = (!zext_ln703_106_fu_139700_p1.read().is_01() || !add_ln703_787_fu_139706_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_106_fu_139700_p1.read()) + sc_biguint<12>(add_ln703_787_fu_139706_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_789_fu_139722_p2() {
    add_ln703_789_fu_139722_p2 = (!zext_ln703_105_fu_139697_p1.read().is_01() || !sext_ln703_452_fu_139718_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_105_fu_139697_p1.read()) + sc_bigint<13>(sext_ln703_452_fu_139718_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_790_fu_139732_p2() {
    add_ln703_790_fu_139732_p2 = (!add_ln703_780_fu_139691_p2.read().is_01() || !sext_ln703_453_fu_139728_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_780_fu_139691_p2.read()) + sc_bigint<15>(sext_ln703_453_fu_139728_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_792_fu_126266_p2() {
    add_ln703_792_fu_126266_p2 = (!zext_ln708_15_fu_119366_p1.read().is_01() || !ap_const_lv11_5E0.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_15_fu_119366_p1.read()) + sc_bigint<11>(ap_const_lv11_5E0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_793_fu_126276_p2() {
    add_ln703_793_fu_126276_p2 = (!sext_ln203_128_fu_123601_p1.read().is_01() || !sext_ln703_236_fu_126272_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_128_fu_123601_p1.read()) + sc_bigint<12>(sext_ln703_236_fu_126272_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_794_fu_133283_p2() {
    add_ln703_794_fu_133283_p2 = (!sext_ln1118_272_fu_129616_p1.read().is_01() || !sext_ln708_78_fu_129619_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_272_fu_129616_p1.read()) + sc_bigint<12>(sext_ln708_78_fu_129619_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_795_fu_133293_p2() {
    add_ln703_795_fu_133293_p2 = (!sext_ln703_237_fu_133280_p1.read().is_01() || !sext_ln703_455_fu_133289_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_237_fu_133280_p1.read()) + sc_bigint<13>(sext_ln703_455_fu_133289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_796_fu_133303_p2() {
    add_ln703_796_fu_133303_p2 = (!sext_ln708_79_fu_129631_p1.read().is_01() || !zext_ln708_161_fu_129623_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_79_fu_129631_p1.read()) + sc_biguint<12>(zext_ln708_161_fu_129623_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_797_fu_133313_p2() {
    add_ln703_797_fu_133313_p2 = (!sext_ln703_238_fu_133299_p1.read().is_01() || !sext_ln703_456_fu_133309_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_238_fu_133299_p1.read()) + sc_bigint<14>(sext_ln703_456_fu_133309_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_798_fu_133319_p2() {
    add_ln703_798_fu_133319_p2 = (!zext_ln708_162_fu_129635_p1.read().is_01() || !zext_ln708_2_reg_142952.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_162_fu_129635_p1.read()) + sc_biguint<11>(zext_ln708_2_reg_142952.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_799_fu_133328_p2() {
    add_ln703_799_fu_133328_p2 = (!zext_ln1118_448_fu_129627_p1.read().is_01() || !zext_ln703_107_fu_133324_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_448_fu_129627_p1.read()) + sc_biguint<12>(zext_ln703_107_fu_133324_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_800_fu_139751_p2() {
    add_ln703_800_fu_139751_p2 = (!add_ln703_797_reg_144363.read().is_01() || !zext_ln703_108_fu_139748_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_797_reg_144363.read()) + sc_biguint<14>(zext_ln703_108_fu_139748_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_801_fu_139756_p2() {
    add_ln703_801_fu_139756_p2 = (!zext_ln708_163_fu_136815_p1.read().is_01() || !add_ln703_800_fu_139751_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln708_163_fu_136815_p1.read()) + sc_biguint<14>(add_ln703_800_fu_139751_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_802_fu_133334_p2() {
    add_ln703_802_fu_133334_p2 = (!grp_fu_116414_p4.read().is_01() || !zext_ln708_165_fu_129668_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_116414_p4.read()) + sc_biguint<10>(zext_ln708_165_fu_129668_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_803_fu_133344_p2() {
    add_ln703_803_fu_133344_p2 = (!zext_ln708_164_fu_129664_p1.read().is_01() || !zext_ln703_109_fu_133340_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_164_fu_129664_p1.read()) + sc_biguint<11>(zext_ln703_109_fu_133340_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_804_fu_139769_p2() {
    add_ln703_804_fu_139769_p2 = (!sext_ln703_457_fu_139762_p1.read().is_01() || !zext_ln703_110_fu_139766_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_457_fu_139762_p1.read()) + sc_biguint<15>(zext_ln703_110_fu_139766_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_805_fu_133350_p2() {
    add_ln703_805_fu_133350_p2 = (!sext_ln1118_274_fu_129672_p1.read().is_01() || !zext_ln1118_449_fu_129698_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_274_fu_129672_p1.read()) + sc_biguint<12>(zext_ln1118_449_fu_129698_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_806_fu_133360_p2() {
    add_ln703_806_fu_133360_p2 = (!zext_ln708_166_fu_129694_p1.read().is_01() || !sext_ln703_458_fu_133356_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln708_166_fu_129694_p1.read()) + sc_bigint<13>(sext_ln703_458_fu_133356_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_807_fu_126282_p2() {
    add_ln703_807_fu_126282_p2 = (!sext_ln708_80_fu_123651_p1.read().is_01() || !sext_ln1118_273_fu_123637_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln708_80_fu_123651_p1.read()) + sc_bigint<9>(sext_ln1118_273_fu_123637_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_808_fu_133369_p2() {
    add_ln703_808_fu_133369_p2 = (!sext_ln1118_275_fu_129675_p1.read().is_01() || !sext_ln703_459_fu_133366_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_275_fu_129675_p1.read()) + sc_bigint<11>(sext_ln703_459_fu_133366_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_809_fu_133379_p2() {
    add_ln703_809_fu_133379_p2 = (!add_ln703_806_fu_133360_p2.read().is_01() || !sext_ln703_460_fu_133375_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_806_fu_133360_p2.read()) + sc_bigint<13>(sext_ln703_460_fu_133375_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_810_fu_139778_p2() {
    add_ln703_810_fu_139778_p2 = (!add_ln703_804_fu_139769_p2.read().is_01() || !sext_ln703_461_fu_139775_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_804_fu_139769_p2.read()) + sc_bigint<15>(sext_ln703_461_fu_139775_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_811_fu_139784_p2() {
    add_ln703_811_fu_139784_p2 = (!sext_ln203_136_fu_136905_p1.read().is_01() || !sext_ln203_134_fu_136852_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_136_fu_136905_p1.read()) + sc_bigint<12>(sext_ln203_134_fu_136852_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_812_fu_139794_p2() {
    add_ln703_812_fu_139794_p2 = (!add_ln703_810_fu_139778_p2.read().is_01() || !sext_ln703_462_fu_139790_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_810_fu_139778_p2.read()) + sc_bigint<15>(sext_ln703_462_fu_139790_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_813_fu_133385_p2() {
    add_ln703_813_fu_133385_p2 = (!zext_ln203_58_fu_129780_p1.read().is_01() || !grp_fu_116314_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_58_fu_129780_p1.read()) + sc_biguint<10>(grp_fu_116314_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_814_fu_139803_p2() {
    add_ln703_814_fu_139803_p2 = (!zext_ln708_170_fu_136887_p1.read().is_01() || !zext_ln708_169_fu_136822_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_170_fu_136887_p1.read()) + sc_biguint<11>(zext_ln708_169_fu_136822_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_815_fu_139809_p2() {
    add_ln703_815_fu_139809_p2 = (!zext_ln703_111_fu_139800_p1.read().is_01() || !add_ln703_814_fu_139803_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_111_fu_139800_p1.read()) + sc_biguint<11>(add_ln703_814_fu_139803_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_816_fu_139819_p2() {
    add_ln703_816_fu_139819_p2 = (!add_ln703_812_fu_139794_p2.read().is_01() || !zext_ln703_112_fu_139815_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_812_fu_139794_p2.read()) + sc_biguint<15>(zext_ln703_112_fu_139815_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_817_fu_133391_p2() {
    add_ln703_817_fu_133391_p2 = (!sext_ln203_133_fu_129825_p1.read().is_01() || !sext_ln203_131_fu_129784_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_133_fu_129825_p1.read()) + sc_bigint<11>(sext_ln203_131_fu_129784_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_818_fu_133401_p2() {
    add_ln703_818_fu_133401_p2 = (!sext_ln203_129_fu_129732_p1.read().is_01() || !sext_ln703_464_fu_133397_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_129_fu_129732_p1.read()) + sc_bigint<12>(sext_ln703_464_fu_133397_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_819_fu_133407_p2() {
    add_ln703_819_fu_133407_p2 = (!sext_ln203_130_fu_129756_p1.read().is_01() || !zext_ln708_167_fu_129752_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_130_fu_129756_p1.read()) + sc_biguint<10>(zext_ln708_167_fu_129752_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_820_fu_139835_p2() {
    add_ln703_820_fu_139835_p2 = (!sext_ln203_135_fu_136883_p1.read().is_01() || !sext_ln203_132_fu_136818_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_135_fu_136883_p1.read()) + sc_bigint<9>(sext_ln203_132_fu_136818_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_821_fu_139845_p2() {
    add_ln703_821_fu_139845_p2 = (!sext_ln703_466_fu_139832_p1.read().is_01() || !sext_ln703_467_fu_139841_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_466_fu_139832_p1.read()) + sc_bigint<11>(sext_ln703_467_fu_139841_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_822_fu_139855_p2() {
    add_ln703_822_fu_139855_p2 = (!sext_ln703_465_fu_139829_p1.read().is_01() || !sext_ln703_468_fu_139851_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_465_fu_139829_p1.read()) + sc_bigint<13>(sext_ln703_468_fu_139851_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_824_fu_133413_p2() {
    add_ln703_824_fu_133413_p2 = (!zext_ln1118_454_fu_129844_p1.read().is_01() || !ap_const_lv8_90.is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln1118_454_fu_129844_p1.read()) + sc_bigint<8>(ap_const_lv8_90));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_825_fu_133427_p2() {
    add_ln703_825_fu_133427_p2 = (!sext_ln203_17_reg_143026.read().is_01() || !zext_ln703_113_fu_133423_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_17_reg_143026.read()) + sc_biguint<12>(zext_ln703_113_fu_133423_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_826_fu_133436_p2() {
    add_ln703_826_fu_133436_p2 = (!sext_ln1118_280_fu_129860_p1.read().is_01() || !sext_ln1118_279_fu_129847_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_280_fu_129860_p1.read()) + sc_bigint<12>(sext_ln1118_279_fu_129847_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_827_fu_133446_p2() {
    add_ln703_827_fu_133446_p2 = (!sext_ln703_241_fu_133432_p1.read().is_01() || !sext_ln703_471_fu_133442_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_241_fu_133432_p1.read()) + sc_bigint<13>(sext_ln703_471_fu_133442_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_828_fu_126288_p2() {
    add_ln703_828_fu_126288_p2 = (!sext_ln1118_251_fu_123338_p1.read().is_01() || !sext_ln1118_160_fu_121325_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_251_fu_123338_p1.read()) + sc_bigint<12>(sext_ln1118_160_fu_121325_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_829_fu_133459_p2() {
    add_ln703_829_fu_133459_p2 = (!sext_ln703_242_fu_133452_p1.read().is_01() || !sext_ln703_472_fu_133456_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_242_fu_133452_p1.read()) + sc_bigint<14>(sext_ln703_472_fu_133456_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_830_fu_133465_p2() {
    add_ln703_830_fu_133465_p2 = (!sext_ln1118_282_fu_129882_p1.read().is_01() || !sext_ln1118_281_fu_129864_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_282_fu_129882_p1.read()) + sc_bigint<11>(sext_ln1118_281_fu_129864_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_831_fu_133471_p2() {
    add_ln703_831_fu_133471_p2 = (!zext_ln708_171_fu_129878_p1.read().is_01() || !add_ln703_830_fu_133465_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_171_fu_129878_p1.read()) + sc_biguint<11>(add_ln703_830_fu_133465_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_832_fu_139874_p2() {
    add_ln703_832_fu_139874_p2 = (!add_ln703_829_reg_144398.read().is_01() || !sext_ln703_473_fu_139871_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_829_reg_144398.read()) + sc_bigint<14>(sext_ln703_473_fu_139871_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_833_fu_139879_p2() {
    add_ln703_833_fu_139879_p2 = (!sext_ln1118_283_fu_136909_p1.read().is_01() || !add_ln703_832_fu_139874_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_283_fu_136909_p1.read()) + sc_biguint<14>(add_ln703_832_fu_139874_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_834_fu_139889_p2() {
    add_ln703_834_fu_139889_p2 = (!zext_ln708_172_fu_136913_p1.read().is_01() || !sext_ln1118_285_fu_136931_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_172_fu_136913_p1.read()) + sc_bigint<12>(sext_ln1118_285_fu_136931_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_835_fu_139899_p2() {
    add_ln703_835_fu_139899_p2 = (!sext_ln703_474_fu_139885_p1.read().is_01() || !sext_ln703_475_fu_139895_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_474_fu_139885_p1.read()) + sc_bigint<15>(sext_ln703_475_fu_139895_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_836_fu_139905_p2() {
    add_ln703_836_fu_139905_p2 = (!sext_ln1118_284_fu_136917_p1.read().is_01() || !zext_ln708_95_fu_136106_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_284_fu_136917_p1.read()) + sc_biguint<12>(zext_ln708_95_fu_136106_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_837_fu_133477_p2() {
    add_ln703_837_fu_133477_p2 = (!sext_ln1118_286_fu_129885_p1.read().is_01() || !sext_ln1118_227_reg_143320.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_286_fu_129885_p1.read()) + sc_bigint<10>(sext_ln1118_227_reg_143320.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_838_fu_133486_p2() {
    add_ln703_838_fu_133486_p2 = (!sext_ln1118_287_fu_129909_p1.read().is_01() || !sext_ln703_476_fu_133482_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_287_fu_129909_p1.read()) + sc_bigint<11>(sext_ln703_476_fu_133482_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_839_fu_139914_p2() {
    add_ln703_839_fu_139914_p2 = (!add_ln703_836_fu_139905_p2.read().is_01() || !sext_ln703_477_fu_139911_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_836_fu_139905_p2.read()) + sc_bigint<12>(sext_ln703_477_fu_139911_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_840_fu_139924_p2() {
    add_ln703_840_fu_139924_p2 = (!add_ln703_835_fu_139899_p2.read().is_01() || !sext_ln703_478_fu_139920_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_835_fu_139899_p2.read()) + sc_bigint<15>(sext_ln703_478_fu_139920_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_841_fu_139930_p2() {
    add_ln703_841_fu_139930_p2 = (!sext_ln203_137_fu_136935_p1.read().is_01() || !add_ln703_840_fu_139924_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_137_fu_136935_p1.read()) + sc_biguint<15>(add_ln703_840_fu_139924_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_842_fu_139936_p2() {
    add_ln703_842_fu_139936_p2 = (!sext_ln203_139_fu_136941_p1.read().is_01() || !sext_ln203_138_fu_136938_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_139_fu_136941_p1.read()) + sc_bigint<12>(sext_ln203_138_fu_136938_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_843_fu_139946_p2() {
    add_ln703_843_fu_139946_p2 = (!add_ln703_841_fu_139930_p2.read().is_01() || !sext_ln703_479_fu_139942_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_841_fu_139930_p2.read()) + sc_bigint<15>(sext_ln703_479_fu_139942_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_844_fu_139956_p2() {
    add_ln703_844_fu_139956_p2 = (!sext_ln203_142_fu_136989_p1.read().is_01() || !sext_ln203_141_fu_136948_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_142_fu_136989_p1.read()) + sc_bigint<12>(sext_ln203_141_fu_136948_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_845_fu_139966_p2() {
    add_ln703_845_fu_139966_p2 = (!sext_ln203_144_fu_137038_p1.read().is_01() || !sext_ln203_143_fu_136993_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_144_fu_137038_p1.read()) + sc_bigint<12>(sext_ln203_143_fu_136993_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_846_fu_139976_p2() {
    add_ln703_846_fu_139976_p2 = (!sext_ln703_481_fu_139962_p1.read().is_01() || !sext_ln703_482_fu_139972_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_481_fu_139962_p1.read()) + sc_bigint<13>(sext_ln703_482_fu_139972_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_847_fu_139986_p2() {
    add_ln703_847_fu_139986_p2 = (!sext_ln703_480_fu_139952_p1.read().is_01() || !sext_ln703_483_fu_139982_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_480_fu_139952_p1.read()) + sc_bigint<16>(sext_ln703_483_fu_139982_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_848_fu_139992_p2() {
    add_ln703_848_fu_139992_p2 = (!sext_ln203_147_fu_137094_p1.read().is_01() || !sext_ln203_146_fu_137083_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_147_fu_137094_p1.read()) + sc_bigint<12>(sext_ln203_146_fu_137083_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_849_fu_140002_p2() {
    add_ln703_849_fu_140002_p2 = (!zext_ln203_60_fu_137090_p1.read().is_01() || !zext_ln203_59_fu_137087_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_60_fu_137090_p1.read()) + sc_biguint<10>(zext_ln203_59_fu_137087_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_850_fu_140012_p2() {
    add_ln703_850_fu_140012_p2 = (!sext_ln703_484_fu_139998_p1.read().is_01() || !zext_ln703_114_fu_140008_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_484_fu_139998_p1.read()) + sc_biguint<13>(zext_ln703_114_fu_140008_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_851_fu_140018_p2() {
    add_ln703_851_fu_140018_p2 = (!sext_ln203_145_fu_137069_p1.read().is_01() || !zext_ln708_173_fu_137118_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_145_fu_137069_p1.read()) + sc_biguint<11>(zext_ln708_173_fu_137118_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_852_fu_140024_p2() {
    add_ln703_852_fu_140024_p2 = (!sext_ln203_148_fu_137114_p1.read().is_01() || !sext_ln203_140_fu_136945_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_148_fu_137114_p1.read()) + sc_bigint<9>(sext_ln203_140_fu_136945_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_853_fu_140034_p2() {
    add_ln703_853_fu_140034_p2 = (!add_ln703_851_fu_140018_p2.read().is_01() || !sext_ln703_485_fu_140030_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_851_fu_140018_p2.read()) + sc_bigint<11>(sext_ln703_485_fu_140030_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_854_fu_140044_p2() {
    add_ln703_854_fu_140044_p2 = (!add_ln703_850_fu_140012_p2.read().is_01() || !sext_ln703_486_fu_140040_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_850_fu_140012_p2.read()) + sc_bigint<13>(sext_ln703_486_fu_140040_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_856_fu_133492_p2() {
    add_ln703_856_fu_133492_p2 = (!sext_ln203_17_reg_143026.read().is_01() || !ap_const_lv12_10.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_17_reg_143026.read()) + sc_biguint<12>(ap_const_lv12_10));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_857_fu_133497_p2() {
    add_ln703_857_fu_133497_p2 = (!zext_ln1116_44_fu_129996_p1.read().is_01() || !add_ln703_856_fu_133492_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_44_fu_129996_p1.read()) + sc_biguint<12>(add_ln703_856_fu_133492_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_858_fu_133507_p2() {
    add_ln703_858_fu_133507_p2 = (!sext_ln1118_290_fu_129999_p1.read().is_01() || !sext_ln708_81_fu_129992_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_290_fu_129999_p1.read()) + sc_bigint<11>(sext_ln708_81_fu_129992_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_859_fu_133517_p2() {
    add_ln703_859_fu_133517_p2 = (!zext_ln1116_45_fu_130003_p1.read().is_01() || !sext_ln703_489_fu_133513_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_45_fu_130003_p1.read()) + sc_bigint<12>(sext_ln703_489_fu_133513_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_860_fu_133527_p2() {
    add_ln703_860_fu_133527_p2 = (!sext_ln703_488_fu_133503_p1.read().is_01() || !sext_ln703_490_fu_133523_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_488_fu_133503_p1.read()) + sc_bigint<13>(sext_ln703_490_fu_133523_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_861_fu_133533_p2() {
    add_ln703_861_fu_133533_p2 = (!sext_ln1116_32_fu_130007_p1.read().is_01() || !add_ln703_860_fu_133527_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_32_fu_130007_p1.read()) + sc_biguint<13>(add_ln703_860_fu_133527_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_862_fu_126294_p2() {
    add_ln703_862_fu_126294_p2 = (!sext_ln1118_187_fu_121938_p1.read().is_01() || !sext_ln1118_199_fu_122289_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_187_fu_121938_p1.read()) + sc_bigint<11>(sext_ln1118_199_fu_122289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_863_fu_133542_p2() {
    add_ln703_863_fu_133542_p2 = (!sext_ln1116_33_fu_130010_p1.read().is_01() || !sext_ln703_492_fu_133539_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_33_fu_130010_p1.read()) + sc_bigint<12>(sext_ln703_492_fu_133539_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_864_fu_140066_p2() {
    add_ln703_864_fu_140066_p2 = (!sext_ln703_491_fu_140060_p1.read().is_01() || !sext_ln703_493_fu_140063_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_491_fu_140060_p1.read()) + sc_bigint<14>(sext_ln703_493_fu_140063_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_865_fu_140072_p2() {
    add_ln703_865_fu_140072_p2 = (!sext_ln1116_35_fu_137122_p1.read().is_01() || !add_ln703_864_fu_140066_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1116_35_fu_137122_p1.read()) + sc_biguint<14>(add_ln703_864_fu_140066_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_866_fu_133548_p2() {
    add_ln703_866_fu_133548_p2 = (!zext_ln1116_46_fu_130033_p1.read().is_01() || !sext_ln708_83_fu_130067_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_46_fu_130033_p1.read()) + sc_bigint<12>(sext_ln708_83_fu_130067_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_867_fu_133558_p2() {
    add_ln703_867_fu_133558_p2 = (!sext_ln1116_36_fu_130037_p1.read().is_01() || !sext_ln703_495_fu_133554_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_36_fu_130037_p1.read()) + sc_bigint<13>(sext_ln703_495_fu_133554_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_868_fu_140085_p2() {
    add_ln703_868_fu_140085_p2 = (!sext_ln703_494_fu_140078_p1.read().is_01() || !sext_ln703_496_fu_140082_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_494_fu_140078_p1.read()) + sc_bigint<15>(sext_ln703_496_fu_140082_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_869_fu_133564_p2() {
    add_ln703_869_fu_133564_p2 = (!sext_ln1116_34_fu_130014_p1.read().is_01() || !zext_ln708_175_fu_130063_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_34_fu_130014_p1.read()) + sc_biguint<11>(zext_ln708_175_fu_130063_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_870_fu_126300_p2() {
    add_ln703_870_fu_126300_p2 = (!sext_ln1118_291_fu_123755_p1.read().is_01() || !zext_ln1116_47_fu_123763_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_291_fu_123755_p1.read()) + sc_biguint<7>(zext_ln1116_47_fu_123763_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_871_fu_126310_p2() {
    add_ln703_871_fu_126310_p2 = (!sext_ln708_82_fu_123759_p1.read().is_01() || !sext_ln703_498_fu_126306_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_82_fu_123759_p1.read()) + sc_bigint<11>(sext_ln703_498_fu_126306_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_872_fu_133577_p2() {
    add_ln703_872_fu_133577_p2 = (!sext_ln703_497_fu_133570_p1.read().is_01() || !sext_ln703_499_fu_133574_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_497_fu_133570_p1.read()) + sc_bigint<12>(sext_ln703_499_fu_133574_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_873_fu_140094_p2() {
    add_ln703_873_fu_140094_p2 = (!add_ln703_868_fu_140085_p2.read().is_01() || !sext_ln703_500_fu_140091_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_868_fu_140085_p2.read()) + sc_bigint<15>(sext_ln703_500_fu_140091_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_874_fu_140100_p2() {
    add_ln703_874_fu_140100_p2 = (!sext_ln203_151_fu_137132_p1.read().is_01() || !zext_ln203_61_fu_137125_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_151_fu_137132_p1.read()) + sc_biguint<12>(zext_ln203_61_fu_137125_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_875_fu_140110_p2() {
    add_ln703_875_fu_140110_p2 = (!add_ln703_873_fu_140094_p2.read().is_01() || !sext_ln703_501_fu_140106_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_873_fu_140094_p2.read()) + sc_bigint<15>(sext_ln703_501_fu_140106_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_876_fu_140120_p2() {
    add_ln703_876_fu_140120_p2 = (!sext_ln203_92_fu_136402_p1.read().is_01() || !sext_ln203_152_fu_137139_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_92_fu_136402_p1.read()) + sc_bigint<12>(sext_ln203_152_fu_137139_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_877_fu_140130_p2() {
    add_ln703_877_fu_140130_p2 = (!sext_ln203_155_fu_137177_p1.read().is_01() || !sext_ln203_154_fu_137174_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_155_fu_137177_p1.read()) + sc_bigint<12>(sext_ln203_154_fu_137174_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_878_fu_140140_p2() {
    add_ln703_878_fu_140140_p2 = (!sext_ln703_503_fu_140126_p1.read().is_01() || !sext_ln703_504_fu_140136_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_503_fu_140126_p1.read()) + sc_bigint<13>(sext_ln703_504_fu_140136_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_879_fu_140150_p2() {
    add_ln703_879_fu_140150_p2 = (!sext_ln703_502_fu_140116_p1.read().is_01() || !sext_ln703_505_fu_140146_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_502_fu_140116_p1.read()) + sc_bigint<16>(sext_ln703_505_fu_140146_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_880_fu_133583_p2() {
    add_ln703_880_fu_133583_p2 = (!zext_ln708_177_fu_130094_p1.read().is_01() || !zext_ln708_176_fu_130090_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_177_fu_130094_p1.read()) + sc_biguint<11>(zext_ln708_176_fu_130090_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_881_fu_133593_p2() {
    add_ln703_881_fu_133593_p2 = (!sext_ln203_149_fu_130086_p1.read().is_01() || !zext_ln203_63_fu_130123_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_149_fu_130086_p1.read()) + sc_biguint<12>(zext_ln203_63_fu_130123_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_882_fu_133603_p2() {
    add_ln703_882_fu_133603_p2 = (!zext_ln703_115_fu_133589_p1.read().is_01() || !sext_ln703_506_fu_133599_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_115_fu_133589_p1.read()) + sc_bigint<13>(sext_ln703_506_fu_133599_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_883_fu_140159_p2() {
    add_ln703_883_fu_140159_p2 = (!sext_ln203_153_fu_137170_p1.read().is_01() || !sext_ln203_150_fu_137129_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_153_fu_137170_p1.read()) + sc_bigint<11>(sext_ln203_150_fu_137129_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_884_fu_140169_p2() {
    add_ln703_884_fu_140169_p2 = (!zext_ln203_62_fu_137136_p1.read().is_01() || !sext_ln203_156_fu_137181_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln203_62_fu_137136_p1.read()) + sc_bigint<11>(sext_ln203_156_fu_137181_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_885_fu_140179_p2() {
    add_ln703_885_fu_140179_p2 = (!sext_ln703_508_fu_140165_p1.read().is_01() || !sext_ln703_509_fu_140175_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_508_fu_140165_p1.read()) + sc_bigint<12>(sext_ln703_509_fu_140175_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_886_fu_140189_p2() {
    add_ln703_886_fu_140189_p2 = (!sext_ln703_507_fu_140156_p1.read().is_01() || !sext_ln703_510_fu_140185_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_507_fu_140156_p1.read()) + sc_bigint<14>(sext_ln703_510_fu_140185_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_888_fu_119086_p2() {
    add_ln703_888_fu_119086_p2 = (!sext_ln703_512_fu_119082_p1.read().is_01() || !zext_ln1118_465_fu_118854_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln703_512_fu_119082_p1.read()) + sc_biguint<10>(zext_ln1118_465_fu_118854_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_889_fu_126319_p2() {
    add_ln703_889_fu_126319_p2 = (!sext_ln1118_114_fu_120210_p1.read().is_01() || !sext_ln703_513_fu_126316_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_114_fu_120210_p1.read()) + sc_bigint<12>(sext_ln703_513_fu_126316_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_890_fu_133612_p2() {
    add_ln703_890_fu_133612_p2 = (!sext_ln203_157_fu_130145_p1.read().is_01() || !sext_ln703_250_fu_133609_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_157_fu_130145_p1.read()) + sc_bigint<13>(sext_ln703_250_fu_133609_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_891_fu_133618_p2() {
    add_ln703_891_fu_133618_p2 = (!sext_ln1118_293_fu_130127_p1.read().is_01() || !zext_ln708_178_fu_130149_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_293_fu_130127_p1.read()) + sc_biguint<11>(zext_ln708_178_fu_130149_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_892_fu_133628_p2() {
    add_ln703_892_fu_133628_p2 = (!zext_ln1118_466_fu_130131_p1.read().is_01() || !sext_ln703_514_fu_133624_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_466_fu_130131_p1.read()) + sc_bigint<12>(sext_ln703_514_fu_133624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_893_fu_133638_p2() {
    add_ln703_893_fu_133638_p2 = (!add_ln703_890_fu_133612_p2.read().is_01() || !sext_ln703_515_fu_133634_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_890_fu_133612_p2.read()) + sc_bigint<13>(sext_ln703_515_fu_133634_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_894_fu_133644_p2() {
    add_ln703_894_fu_133644_p2 = (!sext_ln1118_295_fu_130164_p1.read().is_01() || !sext_ln708_84_fu_130157_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_295_fu_130164_p1.read()) + sc_bigint<12>(sext_ln708_84_fu_130157_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_895_fu_140211_p2() {
    add_ln703_895_fu_140211_p2 = (!sext_ln703_251_fu_140205_p1.read().is_01() || !sext_ln703_516_fu_140208_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_251_fu_140205_p1.read()) + sc_bigint<14>(sext_ln703_516_fu_140208_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_896_fu_133650_p2() {
    add_ln703_896_fu_133650_p2 = (!grp_fu_116684_p4.read().is_01() || !zext_ln1118_467_fu_130161_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(grp_fu_116684_p4.read()) + sc_biguint<8>(zext_ln1118_467_fu_130161_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_897_fu_133660_p2() {
    add_ln703_897_fu_133660_p2 = (!sext_ln1118_294_fu_130153_p1.read().is_01() || !zext_ln708_179_fu_130184_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_294_fu_130153_p1.read()) + sc_biguint<11>(zext_ln708_179_fu_130184_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_898_fu_133666_p2() {
    add_ln703_898_fu_133666_p2 = (!zext_ln703_116_fu_133656_p1.read().is_01() || !add_ln703_897_fu_133660_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_116_fu_133656_p1.read()) + sc_biguint<11>(add_ln703_897_fu_133660_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_899_fu_140220_p2() {
    add_ln703_899_fu_140220_p2 = (!add_ln703_895_fu_140211_p2.read().is_01() || !sext_ln703_517_fu_140217_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_895_fu_140211_p2.read()) + sc_bigint<14>(sext_ln703_517_fu_140217_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_900_fu_140226_p2() {
    add_ln703_900_fu_140226_p2 = (!sext_ln1118_296_fu_137184_p1.read().is_01() || !add_ln703_899_fu_140220_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_296_fu_137184_p1.read()) + sc_biguint<14>(add_ln703_899_fu_140220_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_901_fu_133672_p2() {
    add_ln703_901_fu_133672_p2 = (!zext_ln1118_469_fu_130234_p1.read().is_01() || !zext_ln1118_468_fu_130208_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_469_fu_130234_p1.read()) + sc_biguint<10>(zext_ln1118_468_fu_130208_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_902_fu_133682_p2() {
    add_ln703_902_fu_133682_p2 = (!sext_ln1118_297_fu_130204_p1.read().is_01() || !zext_ln703_117_fu_133678_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_297_fu_130204_p1.read()) + sc_biguint<12>(zext_ln703_117_fu_133678_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_903_fu_140239_p2() {
    add_ln703_903_fu_140239_p2 = (!sext_ln703_518_fu_140232_p1.read().is_01() || !sext_ln703_519_fu_140236_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_518_fu_140232_p1.read()) + sc_bigint<15>(sext_ln703_519_fu_140236_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_904_fu_140245_p2() {
    add_ln703_904_fu_140245_p2 = (!sext_ln1118_298_fu_137187_p1.read().is_01() || !zext_ln1118_472_fu_137210_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_298_fu_137187_p1.read()) + sc_biguint<12>(zext_ln1118_472_fu_137210_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_905_fu_140255_p2() {
    add_ln703_905_fu_140255_p2 = (!zext_ln1118_470_fu_137191_p1.read().is_01() || !sext_ln703_520_fu_140251_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_470_fu_137191_p1.read()) + sc_bigint<13>(sext_ln703_520_fu_140251_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_906_fu_133688_p2() {
    add_ln703_906_fu_133688_p2 = (!sext_ln1118_301_fu_130289_p1.read().is_01() || !sext_ln1118_238_fu_129090_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_301_fu_130289_p1.read()) + sc_bigint<9>(sext_ln1118_238_fu_129090_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_907_fu_133698_p2() {
    add_ln703_907_fu_133698_p2 = (!sext_ln1118_299_fu_130265_p1.read().is_01() || !sext_ln703_521_fu_133694_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_299_fu_130265_p1.read()) + sc_bigint<10>(sext_ln703_521_fu_133694_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_908_fu_140264_p2() {
    add_ln703_908_fu_140264_p2 = (!add_ln703_905_fu_140255_p2.read().is_01() || !sext_ln703_522_fu_140261_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_905_fu_140255_p2.read()) + sc_bigint<13>(sext_ln703_522_fu_140261_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_909_fu_140274_p2() {
    add_ln703_909_fu_140274_p2 = (!add_ln703_903_fu_140239_p2.read().is_01() || !sext_ln703_523_fu_140270_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_903_fu_140239_p2.read()) + sc_bigint<15>(sext_ln703_523_fu_140270_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_910_fu_140280_p2() {
    add_ln703_910_fu_140280_p2 = (!sext_ln203_160_fu_137245_p1.read().is_01() || !add_ln703_909_fu_140274_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_160_fu_137245_p1.read()) + sc_biguint<15>(add_ln703_909_fu_140274_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_911_fu_140286_p2() {
    add_ln703_911_fu_140286_p2 = (!zext_ln203_67_fu_137297_p1.read().is_01() || !zext_ln203_65_fu_137263_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_67_fu_137297_p1.read()) + sc_biguint<10>(zext_ln203_65_fu_137263_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_912_fu_140292_p2() {
    add_ln703_912_fu_140292_p2 = (!zext_ln203_64_fu_137234_p1.read().is_01() || !add_ln703_911_fu_140286_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_64_fu_137234_p1.read()) + sc_biguint<10>(add_ln703_911_fu_140286_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_913_fu_140302_p2() {
    add_ln703_913_fu_140302_p2 = (!add_ln703_910_fu_140280_p2.read().is_01() || !zext_ln703_118_fu_140298_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_910_fu_140280_p2.read()) + sc_biguint<15>(zext_ln703_118_fu_140298_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_914_fu_140308_p2() {
    add_ln703_914_fu_140308_p2 = (!sext_ln203_161_fu_137259_p1.read().is_01() || !sext_ln203_159_fu_137242_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_161_fu_137259_p1.read()) + sc_bigint<11>(sext_ln203_159_fu_137242_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_915_fu_140318_p2() {
    add_ln703_915_fu_140318_p2 = (!sext_ln203_158_fu_137238_p1.read().is_01() || !sext_ln203_60_fu_135618_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_158_fu_137238_p1.read()) + sc_bigint<9>(sext_ln203_60_fu_135618_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_916_fu_140324_p2() {
    add_ln703_916_fu_140324_p2 = (!zext_ln203_66_fu_137293_p1.read().is_01() || !add_ln703_915_fu_140318_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_66_fu_137293_p1.read()) + sc_biguint<9>(add_ln703_915_fu_140318_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_917_fu_140334_p2() {
    add_ln703_917_fu_140334_p2 = (!sext_ln703_524_fu_140314_p1.read().is_01() || !sext_ln703_525_fu_140330_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_524_fu_140314_p1.read()) + sc_bigint<12>(sext_ln703_525_fu_140330_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_919_fu_133704_p2() {
    add_ln703_919_fu_133704_p2 = (!sext_ln203_162_fu_130324_p1.read().is_01() || !ap_const_lv12_C00.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_162_fu_130324_p1.read()) + sc_bigint<12>(ap_const_lv12_C00));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_920_fu_133714_p2() {
    add_ln703_920_fu_133714_p2 = (!sext_ln203_163_fu_130328_p1.read().is_01() || !sext_ln703_254_fu_133710_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_163_fu_130328_p1.read()) + sc_bigint<13>(sext_ln703_254_fu_133710_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_921_fu_126325_p2() {
    add_ln703_921_fu_126325_p2 = (!zext_ln1118_476_fu_123813_p1.read().is_01() || !sext_ln708_85_fu_123809_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_476_fu_123813_p1.read()) + sc_bigint<10>(sext_ln708_85_fu_123809_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_922_fu_133723_p2() {
    add_ln703_922_fu_133723_p2 = (!add_ln703_920_fu_133714_p2.read().is_01() || !sext_ln703_528_fu_133720_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_920_fu_133714_p2.read()) + sc_bigint<13>(sext_ln703_528_fu_133720_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_923_fu_133733_p2() {
    add_ln703_923_fu_133733_p2 = (!sext_ln203_164_fu_130339_p1.read().is_01() || !sext_ln703_255_fu_133729_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_164_fu_130339_p1.read()) + sc_bigint<14>(sext_ln703_255_fu_133729_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_924_fu_133739_p2() {
    add_ln703_924_fu_133739_p2 = (!sext_ln1118_303_fu_130361_p1.read().is_01() || !sext_ln1118_302_fu_130342_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_303_fu_130361_p1.read()) + sc_bigint<12>(sext_ln1118_302_fu_130342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_925_fu_133749_p2() {
    add_ln703_925_fu_133749_p2 = (!add_ln703_923_fu_133733_p2.read().is_01() || !sext_ln703_529_fu_133745_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_923_fu_133733_p2.read()) + sc_bigint<14>(sext_ln703_529_fu_133745_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_926_fu_133755_p2() {
    add_ln703_926_fu_133755_p2 = (!zext_ln708_183_fu_130365_p1.read().is_01() || !zext_ln708_182_fu_130335_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_183_fu_130365_p1.read()) + sc_biguint<11>(zext_ln708_182_fu_130335_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_927_fu_133765_p2() {
    add_ln703_927_fu_133765_p2 = (!sext_ln708_86_fu_130331_p1.read().is_01() || !zext_ln708_185_fu_130410_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_86_fu_130331_p1.read()) + sc_biguint<11>(zext_ln708_185_fu_130410_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_928_fu_133771_p2() {
    add_ln703_928_fu_133771_p2 = (!zext_ln708_184_fu_130379_p1.read().is_01() || !add_ln703_927_fu_133765_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_184_fu_130379_p1.read()) + sc_biguint<11>(add_ln703_927_fu_133765_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_929_fu_133781_p2() {
    add_ln703_929_fu_133781_p2 = (!zext_ln703_119_fu_133761_p1.read().is_01() || !sext_ln703_530_fu_133777_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_119_fu_133761_p1.read()) + sc_bigint<13>(sext_ln703_530_fu_133777_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_92_fu_124135_p2() {
    add_ln703_92_fu_124135_p2 = (!zext_ln703_fu_124131_p1.read().is_01() || !sext_ln203_fu_119109_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_fu_124131_p1.read()) + sc_bigint<13>(sext_ln203_fu_119109_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_930_fu_140357_p2() {
    add_ln703_930_fu_140357_p2 = (!add_ln703_925_reg_144463.read().is_01() || !sext_ln703_531_fu_140354_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_925_reg_144463.read()) + sc_bigint<14>(sext_ln703_531_fu_140354_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_931_fu_133787_p2() {
    add_ln703_931_fu_133787_p2 = (!zext_ln708_188_fu_130445_p1.read().is_01() || !zext_ln708_186_fu_130414_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_188_fu_130445_p1.read()) + sc_biguint<11>(zext_ln708_186_fu_130414_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_932_fu_140365_p2() {
    add_ln703_932_fu_140365_p2 = (!add_ln703_930_fu_140357_p2.read().is_01() || !zext_ln703_120_fu_140362_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_930_fu_140357_p2.read()) + sc_biguint<14>(zext_ln703_120_fu_140362_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_933_fu_133793_p2() {
    add_ln703_933_fu_133793_p2 = (!zext_ln1118_480_fu_130484_p1.read().is_01() || !grp_fu_117184_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_480_fu_130484_p1.read()) + sc_biguint<10>(grp_fu_117184_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_934_fu_133803_p2() {
    add_ln703_934_fu_133803_p2 = (!zext_ln708_190_fu_130460_p1.read().is_01() || !zext_ln703_121_fu_133799_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_190_fu_130460_p1.read()) + sc_biguint<11>(zext_ln703_121_fu_133799_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_935_fu_140378_p2() {
    add_ln703_935_fu_140378_p2 = (!sext_ln703_532_fu_140371_p1.read().is_01() || !zext_ln703_122_fu_140375_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_532_fu_140371_p1.read()) + sc_biguint<15>(zext_ln703_122_fu_140375_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_936_fu_133809_p2() {
    add_ln703_936_fu_133809_p2 = (!sext_ln1118_305_fu_130498_p1.read().is_01() || !sext_ln1118_228_reg_143330.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_305_fu_130498_p1.read()) + sc_bigint<11>(sext_ln1118_228_reg_143330.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_937_fu_133818_p2() {
    add_ln703_937_fu_133818_p2 = (!zext_ln708_191_fu_130526_p1.read().is_01() || !sext_ln703_533_fu_133814_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_191_fu_130526_p1.read()) + sc_bigint<12>(sext_ln703_533_fu_133814_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_938_fu_133824_p2() {
    add_ln703_938_fu_133824_p2 = (!sext_ln708_87_fu_130453_p1.read().is_01() || !sext_ln1118_304_fu_130449_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_87_fu_130453_p1.read()) + sc_bigint<10>(sext_ln1118_304_fu_130449_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_939_fu_133834_p2() {
    add_ln703_939_fu_133834_p2 = (!sext_ln1118_306_fu_130522_p1.read().is_01() || !zext_ln708_189_fu_130457_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_306_fu_130522_p1.read()) + sc_biguint<7>(zext_ln708_189_fu_130457_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_93_fu_124141_p2() {
    add_ln703_93_fu_124141_p2 = (!zext_ln1116_4_fu_119146_p1.read().is_01() || !sext_ln1116_fu_119103_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_4_fu_119146_p1.read()) + sc_bigint<12>(sext_ln1116_fu_119103_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_940_fu_133844_p2() {
    add_ln703_940_fu_133844_p2 = (!sext_ln703_534_fu_133830_p1.read().is_01() || !sext_ln703_535_fu_133840_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_534_fu_133830_p1.read()) + sc_bigint<11>(sext_ln703_535_fu_133840_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_941_fu_133854_p2() {
    add_ln703_941_fu_133854_p2 = (!add_ln703_937_fu_133818_p2.read().is_01() || !sext_ln703_536_fu_133850_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_937_fu_133818_p2.read()) + sc_bigint<12>(sext_ln703_536_fu_133850_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_942_fu_140387_p2() {
    add_ln703_942_fu_140387_p2 = (!add_ln703_935_fu_140378_p2.read().is_01() || !sext_ln703_537_fu_140384_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_935_fu_140378_p2.read()) + sc_bigint<15>(sext_ln703_537_fu_140384_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_943_fu_140393_p2() {
    add_ln703_943_fu_140393_p2 = (!zext_ln203_68_fu_137305_p1.read().is_01() || !add_ln703_942_fu_140387_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_68_fu_137305_p1.read()) + sc_biguint<15>(add_ln703_942_fu_140387_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_944_fu_140399_p2() {
    add_ln703_944_fu_140399_p2 = (!zext_ln203_69_fu_137329_p1.read().is_01() || !sext_ln203_167_fu_137409_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_69_fu_137329_p1.read()) + sc_bigint<12>(sext_ln203_167_fu_137409_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_945_fu_140409_p2() {
    add_ln703_945_fu_140409_p2 = (!add_ln703_943_fu_140393_p2.read().is_01() || !sext_ln703_538_fu_140405_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_943_fu_140393_p2.read()) + sc_bigint<15>(sext_ln703_538_fu_140405_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_946_fu_140419_p2() {
    add_ln703_946_fu_140419_p2 = (!zext_ln708_194_fu_137347_p1.read().is_01() || !zext_ln708_193_fu_137333_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_194_fu_137347_p1.read()) + sc_biguint<11>(zext_ln708_193_fu_137333_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_947_fu_140429_p2() {
    add_ln703_947_fu_140429_p2 = (!sext_ln203_165_fu_137371_p1.read().is_01() || !sext_ln203_166_fu_137375_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_165_fu_137371_p1.read()) + sc_bigint<11>(sext_ln203_166_fu_137375_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_948_fu_140439_p2() {
    add_ln703_948_fu_140439_p2 = (!zext_ln203_70_fu_137351_p1.read().is_01() || !sext_ln703_540_fu_140435_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_70_fu_137351_p1.read()) + sc_bigint<12>(sext_ln703_540_fu_140435_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_949_fu_140449_p2() {
    add_ln703_949_fu_140449_p2 = (!zext_ln703_123_fu_140425_p1.read().is_01() || !sext_ln703_541_fu_140445_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_123_fu_140425_p1.read()) + sc_bigint<13>(sext_ln703_541_fu_140445_p1.read()));
}

}

