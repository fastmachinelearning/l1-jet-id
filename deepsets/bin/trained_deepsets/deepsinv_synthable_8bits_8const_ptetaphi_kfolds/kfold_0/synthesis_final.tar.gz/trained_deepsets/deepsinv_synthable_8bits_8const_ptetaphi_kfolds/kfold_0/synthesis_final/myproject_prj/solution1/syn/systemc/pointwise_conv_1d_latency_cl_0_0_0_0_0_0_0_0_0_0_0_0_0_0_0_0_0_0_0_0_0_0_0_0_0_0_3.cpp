#include "pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_0_V_fu_136948_p2() {
    acc_0_0_V_fu_136948_p2 = (!add_ln703_25_fu_136907_p2.read().is_01() || !sext_ln703_27_fu_136944_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_25_fu_136907_p2.read()) + sc_bigint<15>(sext_ln703_27_fu_136944_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_10_V_fu_137734_p2() {
    acc_0_10_V_fu_137734_p2 = (!add_ln703_346_fu_137718_p2.read().is_01() || !sext_ln703_227_fu_137730_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_346_fu_137718_p2.read()) + sc_bigint<15>(sext_ln703_227_fu_137730_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_11_V_fu_137793_p2() {
    acc_0_11_V_fu_137793_p2 = (!add_ln703_375_fu_137757_p2.read().is_01() || !sext_ln703_246_fu_137789_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_375_fu_137757_p2.read()) + sc_bigint<15>(sext_ln703_246_fu_137789_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_12_V_fu_137906_p2() {
    acc_0_12_V_fu_137906_p2 = (!add_ln703_406_fu_137860_p2.read().is_01() || !sext_ln703_263_fu_137902_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_406_fu_137860_p2.read()) + sc_bigint<16>(sext_ln703_263_fu_137902_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_13_V_fu_137977_p2() {
    acc_0_13_V_fu_137977_p2 = (!sext_ln703_274_fu_137933_p1.read().is_01() || !sext_ln703_277_fu_137973_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_274_fu_137933_p1.read()) + sc_bigint<16>(sext_ln703_277_fu_137973_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_14_V_fu_138044_p2() {
    acc_0_14_V_fu_138044_p2 = (!sext_ln703_288_fu_138004_p1.read().is_01() || !sext_ln703_291_fu_138040_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_288_fu_138004_p1.read()) + sc_bigint<16>(sext_ln703_291_fu_138040_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_15_V_fu_138117_p2() {
    acc_0_15_V_fu_138117_p2 = (!add_ln703_502_fu_138078_p2.read().is_01() || !sext_ln703_309_fu_138113_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_502_fu_138078_p2.read()) + sc_bigint<15>(sext_ln703_309_fu_138113_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_16_V_fu_138184_p2() {
    acc_0_16_V_fu_138184_p2 = (!add_ln703_534_fu_138155_p2.read().is_01() || !sext_ln703_328_fu_138180_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_534_fu_138155_p2.read()) + sc_bigint<15>(sext_ln703_328_fu_138180_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_17_V_fu_138280_p2() {
    acc_0_17_V_fu_138280_p2 = (!add_ln703_565_fu_138254_p2.read().is_01() || !sext_ln703_345_fu_138276_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_565_fu_138254_p2.read()) + sc_bigint<15>(sext_ln703_345_fu_138276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_18_V_fu_138392_p2() {
    acc_0_18_V_fu_138392_p2 = (!add_ln703_594_fu_138340_p2.read().is_01() || !sext_ln703_361_fu_138388_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_594_fu_138340_p2.read()) + sc_bigint<15>(sext_ln703_361_fu_138388_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_19_V_fu_138472_p2() {
    acc_0_19_V_fu_138472_p2 = (!add_ln703_627_fu_138426_p2.read().is_01() || !sext_ln703_379_fu_138468_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_627_fu_138426_p2.read()) + sc_bigint<15>(sext_ln703_379_fu_138468_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_1_V_fu_136964_p2() {
    acc_0_1_V_fu_136964_p2 = (!sext_ln703_46_fu_136958_p1.read().is_01() || !sext_ln703_50_fu_136961_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_46_fu_136958_p1.read()) + sc_bigint<16>(sext_ln703_50_fu_136961_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_20_V_fu_138580_p2() {
    acc_0_20_V_fu_138580_p2 = (!add_ln703_659_fu_138544_p2.read().is_01() || !sext_ln703_395_fu_138576_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_659_fu_138544_p2.read()) + sc_bigint<15>(sext_ln703_395_fu_138576_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_21_V_fu_138739_p2() {
    acc_0_21_V_fu_138739_p2 = (!add_ln703_690_fu_138693_p2.read().is_01() || !sext_ln703_409_fu_138735_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_690_fu_138693_p2.read()) + sc_bigint<15>(sext_ln703_409_fu_138735_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_22_V_fu_138848_p2() {
    acc_0_22_V_fu_138848_p2 = (!sext_ln703_426_fu_138805_p1.read().is_01() || !sext_ln703_429_fu_138844_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_426_fu_138805_p1.read()) + sc_bigint<16>(sext_ln703_429_fu_138844_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_23_V_fu_138978_p2() {
    acc_0_23_V_fu_138978_p2 = (!add_ln703_753_fu_138932_p2.read().is_01() || !sext_ln703_445_fu_138974_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_753_fu_138932_p2.read()) + sc_bigint<15>(sext_ln703_445_fu_138974_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_24_V_fu_139118_p2() {
    acc_0_24_V_fu_139118_p2 = (!add_ln703_788_fu_139102_p2.read().is_01() || !sext_ln703_461_fu_139114_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_788_fu_139102_p2.read()) + sc_bigint<15>(sext_ln703_461_fu_139114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_25_V_fu_139239_p2() {
    acc_0_25_V_fu_139239_p2 = (!add_ln703_818_fu_139203_p2.read().is_01() || !sext_ln703_474_fu_139235_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_818_fu_139203_p2.read()) + sc_bigint<15>(sext_ln703_474_fu_139235_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_26_V_fu_139384_p2() {
    acc_0_26_V_fu_139384_p2 = (!add_ln703_851_fu_139358_p2.read().is_01() || !sext_ln703_486_fu_139380_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_851_fu_139358_p2.read()) + sc_bigint<15>(sext_ln703_486_fu_139380_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_27_V_fu_139514_p2() {
    acc_0_27_V_fu_139514_p2 = (!add_ln703_880_fu_139479_p2.read().is_01() || !sext_ln703_502_fu_139510_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_880_fu_139479_p2.read()) + sc_bigint<15>(sext_ln703_502_fu_139510_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_28_V_fu_139650_p2() {
    acc_0_28_V_fu_139650_p2 = (!add_ln703_915_fu_139628_p2.read().is_01() || !sext_ln703_519_fu_139646_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_915_fu_139628_p2.read()) + sc_bigint<15>(sext_ln703_519_fu_139646_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_29_V_fu_139793_p2() {
    acc_0_29_V_fu_139793_p2 = (!sext_ln703_534_fu_139747_p1.read().is_01() || !sext_ln703_536_fu_139789_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_534_fu_139747_p1.read()) + sc_bigint<16>(sext_ln703_536_fu_139789_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_2_V_fu_137001_p2() {
    acc_0_2_V_fu_137001_p2 = (!add_ln703_91_fu_136980_p2.read().is_01() || !sext_ln703_73_fu_136997_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_91_fu_136980_p2.read()) + sc_bigint<15>(sext_ln703_73_fu_136997_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_30_V_fu_139927_p2() {
    acc_0_30_V_fu_139927_p2 = (!add_ln703_976_fu_139879_p2.read().is_01() || !sext_ln703_555_fu_139923_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_976_fu_139879_p2.read()) + sc_bigint<15>(sext_ln703_555_fu_139923_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_31_V_fu_140067_p2() {
    acc_0_31_V_fu_140067_p2 = (!add_ln703_1011_fu_140048_p2.read().is_01() || !sext_ln703_568_fu_140063_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1011_fu_140048_p2.read()) + sc_bigint<15>(sext_ln703_568_fu_140063_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_3_V_fu_137076_p2() {
    acc_0_3_V_fu_137076_p2 = (!sext_ln703_95_fu_137011_p1.read().is_01() || !sext_ln703_104_fu_137072_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_95_fu_137011_p1.read()) + sc_bigint<16>(sext_ln703_104_fu_137072_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_4_V_fu_137168_p2() {
    acc_0_4_V_fu_137168_p2 = (!add_ln703_152_fu_137120_p2.read().is_01() || !sext_ln703_128_fu_137164_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_152_fu_137120_p2.read()) + sc_bigint<15>(sext_ln703_128_fu_137164_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_5_V_fu_137238_p2() {
    acc_0_5_V_fu_137238_p2 = (!add_ln703_185_fu_137206_p2.read().is_01() || !zext_ln703_30_fu_137234_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_185_fu_137206_p2.read()) + sc_biguint<15>(zext_ln703_30_fu_137234_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_6_V_fu_137382_p2() {
    acc_0_6_V_fu_137382_p2 = (!add_ln703_219_fu_137366_p2.read().is_01() || !zext_ln703_39_fu_137378_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_219_fu_137366_p2.read()) + sc_biguint<15>(zext_ln703_39_fu_137378_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_7_V_fu_137524_p2() {
    acc_0_7_V_fu_137524_p2 = (!add_ln703_246_fu_137469_p2.read().is_01() || !sext_ln703_180_fu_137520_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_246_fu_137469_p2.read()) + sc_bigint<15>(sext_ln703_180_fu_137520_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_8_V_fu_137587_p2() {
    acc_0_8_V_fu_137587_p2 = (!add_ln703_281_fu_137565_p2.read().is_01() || !sext_ln703_197_fu_137583_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_281_fu_137565_p2.read()) + sc_bigint<15>(sext_ln703_197_fu_137583_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_acc_0_9_V_fu_137657_p2() {
    acc_0_9_V_fu_137657_p2 = (!add_ln703_312_fu_137621_p2.read().is_01() || !sext_ln703_213_fu_137653_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_312_fu_137621_p2.read()) + sc_bigint<15>(sext_ln703_213_fu_137653_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_10_fu_134313_p2() {
    add_ln1118_10_fu_134313_p2 = (!zext_ln1118_466_fu_134310_p1.read().is_01() || !zext_ln1118_463_fu_134306_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_466_fu_134310_p1.read()) + sc_biguint<14>(zext_ln1118_463_fu_134306_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_11_fu_119564_p2() {
    add_ln1118_11_fu_119564_p2 = (!zext_ln1118_81_fu_119424_p1.read().is_01() || !zext_ln1118_470_fu_119560_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_81_fu_119424_p1.read()) + sc_biguint<12>(zext_ln1118_470_fu_119560_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_12_fu_119818_p2() {
    add_ln1118_12_fu_119818_p2 = (!zext_ln1118_527_fu_119814_p1.read().is_01() || !zext_ln1118_526_fu_119803_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_527_fu_119814_p1.read()) + sc_biguint<14>(zext_ln1118_526_fu_119803_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_13_fu_125951_p2() {
    add_ln1118_13_fu_125951_p2 = (!zext_ln1118_147_fu_125937_p1.read().is_01() || !zext_ln1118_551_fu_125947_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_147_fu_125937_p1.read()) + sc_biguint<12>(zext_ln1118_551_fu_125947_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_14_fu_119951_p2() {
    add_ln1118_14_fu_119951_p2 = (!zext_ln1118_577_fu_119947_p1.read().is_01() || !zext_ln1118_526_fu_119803_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_577_fu_119947_p1.read()) + sc_biguint<14>(zext_ln1118_526_fu_119803_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_15_fu_126251_p2() {
    add_ln1118_15_fu_126251_p2 = (!zext_ln1118_585_fu_126247_p1.read().is_01() || !zext_ln1118_323_reg_141194.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_585_fu_126247_p1.read()) + sc_biguint<14>(zext_ln1118_323_reg_141194.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_16_fu_126310_p2() {
    add_ln1118_16_fu_126310_p2 = (!zext_ln1118_588_fu_126306_p1.read().is_01() || !zext_ln1118_587_fu_126302_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_588_fu_126306_p1.read()) + sc_biguint<14>(zext_ln1118_587_fu_126302_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_17_fu_134742_p2() {
    add_ln1118_17_fu_134742_p2 = (!zext_ln1118_173_fu_134663_p1.read().is_01() || !zext_ln1118_590_fu_134738_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_173_fu_134663_p1.read()) + sc_biguint<13>(zext_ln1118_590_fu_134738_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_18_fu_134832_p2() {
    add_ln1118_18_fu_134832_p2 = (!zext_ln1118_50_fu_133865_p1.read().is_01() || !zext_ln1118_448_fu_134199_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_50_fu_133865_p1.read()) + sc_biguint<12>(zext_ln1118_448_fu_134199_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_19_fu_120137_p2() {
    add_ln1118_19_fu_120137_p2 = (!zext_ln1118_224_fu_118721_p1.read().is_01() || !zext_ln1118_361_fu_119296_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_224_fu_118721_p1.read()) + sc_biguint<14>(zext_ln1118_361_fu_119296_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_1_fu_118756_p2() {
    add_ln1118_1_fu_118756_p2 = (!zext_ln1118_230_fu_118752_p1.read().is_01() || !zext_ln1118_76_fu_118499_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_230_fu_118752_p1.read()) + sc_biguint<13>(zext_ln1118_76_fu_118499_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_20_fu_126366_p2() {
    add_ln1118_20_fu_126366_p2 = (!zext_ln1118_18_reg_140805.read().is_01() || !zext_ln1118_594_fu_126362_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_18_reg_140805.read()) + sc_biguint<13>(zext_ln1118_594_fu_126362_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_21_fu_126513_p2() {
    add_ln1118_21_fu_126513_p2 = (!zext_ln1118_601_fu_126509_p1.read().is_01() || !zext_ln1118_119_fu_124395_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_601_fu_126509_p1.read()) + sc_biguint<14>(zext_ln1118_119_fu_124395_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_22_fu_126571_p2() {
    add_ln1118_22_fu_126571_p2 = (!zext_ln1118_92_fu_125347_p1.read().is_01() || !zext_ln1118_603_fu_126567_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_92_fu_125347_p1.read()) + sc_biguint<12>(zext_ln1118_603_fu_126567_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_23_fu_120190_p2() {
    add_ln1118_23_fu_120190_p2 = (!zext_ln1118_97_reg_141336.read().is_01() || !zext_ln1118_606_fu_120186_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_97_reg_141336.read()) + sc_biguint<12>(zext_ln1118_606_fu_120186_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_24_fu_134869_p2() {
    add_ln1118_24_fu_134869_p2 = (!zext_ln1118_609_fu_134866_p1.read().is_01() || !zext_ln1118_608_fu_134862_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_609_fu_134866_p1.read()) + sc_biguint<14>(zext_ln1118_608_fu_134862_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_25_fu_120305_p2() {
    add_ln1118_25_fu_120305_p2 = (!zext_ln1118_618_fu_120301_p1.read().is_01() || !zext_ln1118_280_fu_118957_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_618_fu_120301_p1.read()) + sc_biguint<14>(zext_ln1118_280_fu_118957_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_26_fu_126768_p2() {
    add_ln1118_26_fu_126768_p2 = (!zext_ln1118_157_reg_141988.read().is_01() || !zext_ln1118_623_fu_126764_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_157_reg_141988.read()) + sc_biguint<12>(zext_ln1118_623_fu_126764_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_27_fu_120382_p2() {
    add_ln1118_27_fu_120382_p2 = (!zext_ln1118_166_fu_119898_p1.read().is_01() || !zext_ln1118_628_fu_120378_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_166_fu_119898_p1.read()) + sc_biguint<13>(zext_ln1118_628_fu_120378_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_28_fu_126939_p2() {
    add_ln1118_28_fu_126939_p2 = (!zext_ln1118_648_fu_126935_p1.read().is_01() || !zext_ln1118_454_fu_125426_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_648_fu_126935_p1.read()) + sc_biguint<14>(zext_ln1118_454_fu_125426_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_29_fu_135212_p2() {
    add_ln1118_29_fu_135212_p2 = (!zext_ln1118_655_fu_135208_p1.read().is_01() || !zext_ln1118_590_fu_134738_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_655_fu_135208_p1.read()) + sc_biguint<13>(zext_ln1118_590_fu_134738_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_2_fu_118893_p2() {
    add_ln1118_2_fu_118893_p2 = (!zext_ln1118_54_reg_141124.read().is_01() || !zext_ln1118_94_fu_118593_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_54_reg_141124.read()) + sc_biguint<13>(zext_ln1118_94_fu_118593_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_30_fu_135309_p2() {
    add_ln1118_30_fu_135309_p2 = (!zext_ln1118_668_fu_135305_p1.read().is_01() || !zext_ln1118_667_fu_135301_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_668_fu_135305_p1.read()) + sc_biguint<14>(zext_ln1118_667_fu_135301_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_31_fu_120962_p2() {
    add_ln1118_31_fu_120962_p2 = (!zext_ln1118_673_fu_120958_p1.read().is_01() || !zext_ln1118_672_fu_120954_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_673_fu_120958_p1.read()) + sc_biguint<13>(zext_ln1118_672_fu_120954_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_32_fu_127212_p2() {
    add_ln1118_32_fu_127212_p2 = (!zext_ln1118_101_reg_141824.read().is_01() || !zext_ln1118_376_fu_125276_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_101_reg_141824.read()) + sc_biguint<14>(zext_ln1118_376_fu_125276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_33_fu_127336_p2() {
    add_ln1118_33_fu_127336_p2 = (!zext_ln1118_459_fu_125545_p1.read().is_01() || !zext_ln1118_603_fu_126567_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_459_fu_125545_p1.read()) + sc_biguint<12>(zext_ln1118_603_fu_126567_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_34_fu_135424_p2() {
    add_ln1118_34_fu_135424_p2 = (!zext_ln1118_200_reg_142608.read().is_01() || !zext_ln1118_206_reg_142620.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_200_reg_142608.read()) + sc_biguint<14>(zext_ln1118_206_reg_142620.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_36_fu_121112_p2() {
    add_ln1118_36_fu_121112_p2 = (!zext_ln1118_93_reg_140816.read().is_01() || !zext_ln1118_298_fu_118995_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_93_reg_140816.read()) + sc_biguint<12>(zext_ln1118_298_fu_118995_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_37_fu_121357_p2() {
    add_ln1118_37_fu_121357_p2 = (!zext_ln1118_714_fu_121353_p1.read().is_01() || !zext_ln1118_713_fu_121342_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_714_fu_121353_p1.read()) + sc_biguint<14>(zext_ln1118_713_fu_121342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_38_fu_121385_p2() {
    add_ln1118_38_fu_121385_p2 = (!zext_ln1118_717_fu_121381_p1.read().is_01() || !zext_ln1118_369_fu_119339_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_717_fu_121381_p1.read()) + sc_biguint<14>(zext_ln1118_369_fu_119339_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_39_fu_127698_p2() {
    add_ln1118_39_fu_127698_p2 = (!zext_ln1118_720_fu_127694_p1.read().is_01() || !zext_ln1118_497_fu_125796_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_720_fu_127694_p1.read()) + sc_biguint<12>(zext_ln1118_497_fu_125796_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_3_fu_124726_p2() {
    add_ln1118_3_fu_124726_p2 = (!zext_ln1118_264_fu_124722_p1.read().is_01() || !zext_ln1118_206_fu_124497_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_264_fu_124722_p1.read()) + sc_biguint<14>(zext_ln1118_206_fu_124497_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_40_fu_121474_p2() {
    add_ln1118_40_fu_121474_p2 = (!zext_ln1118_576_fu_119916_p1.read().is_01() || !zext_ln1118_47_fu_118446_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_576_fu_119916_p1.read()) + sc_biguint<14>(zext_ln1118_47_fu_118446_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_41_fu_121542_p2() {
    add_ln1118_41_fu_121542_p2 = (!zext_ln1118_78_reg_140752.read().is_01() || !zext_ln1118_713_fu_121342_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_78_reg_140752.read()) + sc_biguint<14>(zext_ln1118_713_fu_121342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_42_fu_121719_p2() {
    add_ln1118_42_fu_121719_p2 = (!zext_ln1118_737_fu_121715_p1.read().is_01() || !zext_ln1118_713_fu_121342_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_737_fu_121715_p1.read()) + sc_biguint<14>(zext_ln1118_713_fu_121342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_43_fu_135923_p2() {
    add_ln1118_43_fu_135923_p2 = (!zext_ln1118_728_fu_135665_p1.read().is_01() || !zext_ln1118_750_fu_135919_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_728_fu_135665_p1.read()) + sc_biguint<14>(zext_ln1118_750_fu_135919_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_44_fu_121793_p2() {
    add_ln1118_44_fu_121793_p2 = (!zext_ln1118_760_fu_121789_p1.read().is_01() || !zext_ln1118_759_fu_121778_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_760_fu_121789_p1.read()) + sc_biguint<13>(zext_ln1118_759_fu_121778_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_45_fu_128295_p2() {
    add_ln1118_45_fu_128295_p2 = (!zext_ln1118_765_fu_128291_p1.read().is_01() || !zext_ln1118_376_fu_125276_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_765_fu_128291_p1.read()) + sc_biguint<14>(zext_ln1118_376_fu_125276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_46_fu_136105_p2() {
    add_ln1118_46_fu_136105_p2 = (!zext_ln1118_770_fu_136101_p1.read().is_01() || !zext_ln1118_705_fu_135527_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_770_fu_136101_p1.read()) + sc_biguint<14>(zext_ln1118_705_fu_135527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_47_fu_121994_p2() {
    add_ln1118_47_fu_121994_p2 = (!zext_ln1118_771_fu_121990_p1.read().is_01() || !zext_ln1118_232_fu_118783_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_771_fu_121990_p1.read()) + sc_biguint<13>(zext_ln1118_232_fu_118783_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_48_fu_128721_p2() {
    add_ln1118_48_fu_128721_p2 = (!zext_ln1118_79_reg_141273.read().is_01() || !zext_ln1118_490_fu_125708_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_79_reg_141273.read()) + sc_biguint<14>(zext_ln1118_490_fu_125708_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_49_fu_136293_p2() {
    add_ln1118_49_fu_136293_p2 = (!zext_ln1118_442_fu_134137_p1.read().is_01() || !zext_ln1118_750_fu_135919_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_442_fu_134137_p1.read()) + sc_biguint<14>(zext_ln1118_750_fu_135919_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_4_fu_124894_p2() {
    add_ln1118_4_fu_124894_p2 = (!zext_ln1118_325_fu_124890_p1.read().is_01() || !zext_ln1118_323_reg_141194.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_325_fu_124890_p1.read()) + sc_biguint<14>(zext_ln1118_323_reg_141194.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_50_fu_122157_p2() {
    add_ln1118_50_fu_122157_p2 = (!zext_ln1118_790_fu_122153_p1.read().is_01() || !zext_ln1118_361_fu_119296_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_790_fu_122153_p1.read()) + sc_biguint<14>(zext_ln1118_361_fu_119296_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_51_fu_128954_p2() {
    add_ln1118_51_fu_128954_p2 = (!zext_ln1118_694_fu_127533_p1.read().is_01() || !zext_ln1118_119_fu_124395_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_694_fu_127533_p1.read()) + sc_biguint<14>(zext_ln1118_119_fu_124395_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_52_fu_128989_p2() {
    add_ln1118_52_fu_128989_p2 = (!zext_ln1118_794_fu_128985_p1.read().is_01() || !zext_ln1118_793_fu_128981_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_794_fu_128985_p1.read()) + sc_biguint<14>(zext_ln1118_793_fu_128981_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_53_fu_129165_p2() {
    add_ln1118_53_fu_129165_p2 = (!zext_ln1118_803_fu_129161_p1.read().is_01() || !zext_ln1118_587_fu_126302_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_803_fu_129161_p1.read()) + sc_biguint<14>(zext_ln1118_587_fu_126302_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_54_fu_129326_p2() {
    add_ln1118_54_fu_129326_p2 = (!zext_ln1118_813_fu_129323_p1.read().is_01() || !zext_ln1118_690_fu_127451_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_813_fu_129323_p1.read()) + sc_biguint<14>(zext_ln1118_690_fu_127451_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_55_fu_122255_p2() {
    add_ln1118_55_fu_122255_p2 = (!zext_ln1118_823_fu_122251_p1.read().is_01() || !zext_ln1118_713_fu_121342_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_823_fu_122251_p1.read()) + sc_biguint<14>(zext_ln1118_713_fu_121342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_56_fu_129599_p2() {
    add_ln1118_56_fu_129599_p2 = (!zext_ln1118_105_fu_124309_p1.read().is_01() || !zext_ln1118_827_fu_129595_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_105_fu_124309_p1.read()) + sc_biguint<12>(zext_ln1118_827_fu_129595_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_57_fu_129623_p2() {
    add_ln1118_57_fu_129623_p2 = (!zext_ln1118_829_fu_129619_p1.read().is_01() || !zext_ln1118_690_fu_127451_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_829_fu_129619_p1.read()) + sc_biguint<14>(zext_ln1118_690_fu_127451_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_58_fu_129771_p2() {
    add_ln1118_58_fu_129771_p2 = (!zext_ln1118_835_fu_129767_p1.read().is_01() || !zext_ln1118_834_fu_129763_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_835_fu_129767_p1.read()) + sc_biguint<12>(zext_ln1118_834_fu_129763_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_59_fu_122311_p2() {
    add_ln1118_59_fu_122311_p2 = (!zext_ln1118_11_reg_140729.read().is_01() || !zext_ln1118_76_fu_118499_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_11_reg_140729.read()) + sc_biguint<13>(zext_ln1118_76_fu_118499_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_5_fu_124941_p2() {
    add_ln1118_5_fu_124941_p2 = (!zext_ln1118_329_fu_124937_p1.read().is_01() || !zext_ln1118_328_fu_124926_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_329_fu_124937_p1.read()) + sc_biguint<13>(zext_ln1118_328_fu_124926_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_60_fu_129836_p2() {
    add_ln1118_60_fu_129836_p2 = (!zext_ln1118_145_reg_141448.read().is_01() || !zext_ln1118_661_fu_127080_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_145_reg_141448.read()) + sc_biguint<12>(zext_ln1118_661_fu_127080_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_61_fu_136801_p2() {
    add_ln1118_61_fu_136801_p2 = (!zext_ln1118_656_fu_135262_p1.read().is_01() || !zext_ln1118_463_fu_134306_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_656_fu_135262_p1.read()) + sc_biguint<14>(zext_ln1118_463_fu_134306_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_62_fu_122460_p2() {
    add_ln1118_62_fu_122460_p2 = (!zext_ln1118_861_fu_122456_p1.read().is_01() || !zext_ln1118_860_fu_122445_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_861_fu_122456_p1.read()) + sc_biguint<14>(zext_ln1118_860_fu_122445_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_6_fu_125021_p2() {
    add_ln1118_6_fu_125021_p2 = (!zext_ln1118_335_fu_125017_p1.read().is_01() || !zext_ln1118_334_fu_125006_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_335_fu_125017_p1.read()) + sc_biguint<14>(zext_ln1118_334_fu_125006_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_7_fu_134203_p2() {
    add_ln1118_7_fu_134203_p2 = (!zext_ln1118_265_reg_142669.read().is_01() || !zext_ln1118_448_fu_134199_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_265_reg_142669.read()) + sc_biguint<12>(zext_ln1118_448_fu_134199_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_8_fu_125434_p2() {
    add_ln1118_8_fu_125434_p2 = (!zext_ln1118_455_fu_125430_p1.read().is_01() || !zext_ln1118_454_fu_125426_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_455_fu_125430_p1.read()) + sc_biguint<14>(zext_ln1118_454_fu_125426_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_9_fu_134226_p2() {
    add_ln1118_9_fu_134226_p2 = (!zext_ln1118_41_fu_133671_p1.read().is_01() || !zext_ln1118_197_fu_133684_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_41_fu_133671_p1.read()) + sc_biguint<12>(zext_ln1118_197_fu_133684_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln1118_fu_133699_p2() {
    add_ln1118_fu_133699_p2 = (!zext_ln1118_199_fu_133695_p1.read().is_01() || !zext_ln1118_197_fu_133684_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_199_fu_133695_p1.read()) + sc_biguint<12>(zext_ln1118_197_fu_133684_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1000_fu_139977_p2() {
    add_ln703_1000_fu_139977_p2 = (!zext_ln708_381_fu_136832_p1.read().is_01() || !zext_ln708_380_fu_136829_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_381_fu_136832_p1.read()) + sc_biguint<11>(zext_ln708_380_fu_136829_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1001_fu_139983_p2() {
    add_ln703_1001_fu_139983_p2 = (!zext_ln708_379_fu_136825_p1.read().is_01() || !add_ln703_1000_fu_139977_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_379_fu_136825_p1.read()) + sc_biguint<11>(add_ln703_1000_fu_139977_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1002_fu_139993_p2() {
    add_ln703_1002_fu_139993_p2 = (!sext_ln703_563_fu_139973_p1.read().is_01() || !zext_ln703_159_fu_139989_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_563_fu_139973_p1.read()) + sc_biguint<15>(zext_ln703_159_fu_139989_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1003_fu_139999_p2() {
    add_ln703_1003_fu_139999_p2 = (!zext_ln1118_866_fu_136855_p1.read().is_01() || !reg_116695.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_866_fu_136855_p1.read()) + sc_biguint<10>(reg_116695.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1004_fu_140009_p2() {
    add_ln703_1004_fu_140009_p2 = (!zext_ln708_382_fu_136836_p1.read().is_01() || !zext_ln703_160_fu_140005_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_382_fu_136836_p1.read()) + sc_biguint<11>(zext_ln703_160_fu_140005_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1005_fu_133617_p2() {
    add_ln703_1005_fu_133617_p2 = (!sext_ln708_49_fu_130192_p1.read().is_01() || !sext_ln708_50_fu_130227_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_49_fu_130192_p1.read()) + sc_bigint<11>(sext_ln708_50_fu_130227_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1006_fu_124293_p2() {
    add_ln703_1006_fu_124293_p2 = (!sext_ln1118_307_fu_122495_p1.read().is_01() || !zext_ln708_378_fu_122476_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_307_fu_122495_p1.read()) + sc_biguint<8>(zext_ln708_378_fu_122476_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1007_fu_133626_p2() {
    add_ln703_1007_fu_133626_p2 = (!add_ln703_1005_fu_133617_p2.read().is_01() || !sext_ln703_564_fu_133623_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_1005_fu_133617_p2.read()) + sc_bigint<11>(sext_ln703_564_fu_133623_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1008_fu_140022_p2() {
    add_ln703_1008_fu_140022_p2 = (!zext_ln703_161_fu_140015_p1.read().is_01() || !sext_ln703_565_fu_140019_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_161_fu_140015_p1.read()) + sc_bigint<12>(sext_ln703_565_fu_140019_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1009_fu_140032_p2() {
    add_ln703_1009_fu_140032_p2 = (!add_ln703_1002_fu_139993_p2.read().is_01() || !sext_ln703_566_fu_140028_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1002_fu_139993_p2.read()) + sc_bigint<15>(sext_ln703_566_fu_140028_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_100_fu_122742_p2() {
    add_ln703_100_fu_122742_p2 = (!sext_ln708_6_fu_119179_p1.read().is_01() || !sext_ln703_77_fu_122738_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_6_fu_119179_p1.read()) + sc_bigint<12>(sext_ln703_77_fu_122738_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1010_fu_140038_p2() {
    add_ln703_1010_fu_140038_p2 = (!grp_fu_115597_p4.read().is_01() || !zext_ln203_117_fu_136879_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115597_p4.read()) + sc_biguint<10>(zext_ln203_117_fu_136879_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1011_fu_140048_p2() {
    add_ln703_1011_fu_140048_p2 = (!add_ln703_1009_fu_140032_p2.read().is_01() || !zext_ln703_162_fu_140044_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_1009_fu_140032_p2.read()) + sc_biguint<15>(zext_ln703_162_fu_140044_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1012_fu_133632_p2() {
    add_ln703_1012_fu_133632_p2 = (!sext_ln203_150_fu_130251_p1.read().is_01() || !sext_ln1118_90_fu_126178_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_150_fu_130251_p1.read()) + sc_bigint<9>(sext_ln1118_90_fu_126178_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1013_fu_140057_p2() {
    add_ln703_1013_fu_140057_p2 = (!sext_ln203_149_fu_136883_p1.read().is_01() || !sext_ln703_567_fu_140054_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_149_fu_136883_p1.read()) + sc_bigint<10>(sext_ln703_567_fu_140054_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_101_fu_122752_p2() {
    add_ln703_101_fu_122752_p2 = (!add_ln703_98_fu_122726_p2.read().is_01() || !sext_ln703_78_fu_122748_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_98_fu_122726_p2.read()) + sc_bigint<13>(sext_ln703_78_fu_122748_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_102_fu_122762_p2() {
    add_ln703_102_fu_122762_p2 = (!zext_ln1118_354_fu_119204_p1.read().is_01() || !sext_ln703_79_fu_122758_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_354_fu_119204_p1.read()) + sc_bigint<14>(sext_ln703_79_fu_122758_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_103_fu_118143_p2() {
    add_ln703_103_fu_118143_p2 = (!grp_fu_115487_p4.read().is_01() || !zext_ln1118_542_fu_117228_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_115487_p4.read()) + sc_biguint<9>(zext_ln1118_542_fu_117228_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_104_fu_130644_p2() {
    add_ln703_104_fu_130644_p2 = (!sext_ln1118_30_fu_125113_p1.read().is_01() || !zext_ln703_17_fu_130641_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_30_fu_125113_p1.read()) + sc_biguint<12>(zext_ln703_17_fu_130641_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_105_fu_130654_p2() {
    add_ln703_105_fu_130654_p2 = (!add_ln703_102_reg_142298.read().is_01() || !sext_ln703_80_fu_130650_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_102_reg_142298.read()) + sc_bigint<14>(sext_ln703_80_fu_130650_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_106_fu_118149_p2() {
    add_ln703_106_fu_118149_p2 = (!sext_ln1118_34_fu_117250_p1.read().is_01() || !sext_ln1118_33_fu_117236_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_34_fu_117250_p1.read()) + sc_bigint<10>(sext_ln1118_33_fu_117236_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_107_fu_118159_p2() {
    add_ln703_107_fu_118159_p2 = (!sext_ln1118_32_fu_117232_p1.read().is_01() || !sext_ln703_81_fu_118155_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_32_fu_117232_p1.read()) + sc_bigint<11>(sext_ln703_81_fu_118155_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_108_fu_122771_p2() {
    add_ln703_108_fu_122771_p2 = (!zext_ln708_30_fu_119019_p1.read().is_01() || !sext_ln1118_31_fu_119246_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_30_fu_119019_p1.read()) + sc_bigint<10>(sext_ln1118_31_fu_119246_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_109_fu_122781_p2() {
    add_ln703_109_fu_122781_p2 = (!sext_ln1118_35_fu_119250_p1.read().is_01() || !sext_ln703_85_fu_122777_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_35_fu_119250_p1.read()) + sc_bigint<11>(sext_ln703_85_fu_122777_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_10_fu_122583_p2() {
    add_ln703_10_fu_122583_p2 = (!add_ln703_6_fu_122547_p2.read().is_01() || !sext_ln703_15_fu_122579_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_6_fu_122547_p2.read()) + sc_bigint<13>(sext_ln703_15_fu_122579_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_110_fu_122791_p2() {
    add_ln703_110_fu_122791_p2 = (!sext_ln703_84_fu_122768_p1.read().is_01() || !sext_ln703_88_fu_122787_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_84_fu_122768_p1.read()) + sc_bigint<12>(sext_ln703_88_fu_122787_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_111_fu_130662_p2() {
    add_ln703_111_fu_130662_p2 = (!add_ln703_105_fu_130654_p2.read().is_01() || !sext_ln703_89_fu_130659_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_105_fu_130654_p2.read()) + sc_bigint<14>(sext_ln703_89_fu_130659_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_112_fu_130672_p2() {
    add_ln703_112_fu_130672_p2 = (!sext_ln203_12_fu_125143_p1.read().is_01() || !sext_ln703_90_fu_130668_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_12_fu_125143_p1.read()) + sc_bigint<15>(sext_ln703_90_fu_130668_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_113_fu_130678_p2() {
    add_ln703_113_fu_130678_p2 = (!sext_ln203_14_fu_125227_p1.read().is_01() || !sext_ln203_13_fu_125175_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_14_fu_125227_p1.read()) + sc_bigint<12>(sext_ln203_13_fu_125175_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_114_fu_130688_p2() {
    add_ln703_114_fu_130688_p2 = (!add_ln703_112_fu_130672_p2.read().is_01() || !sext_ln703_91_fu_130684_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_112_fu_130672_p2.read()) + sc_bigint<15>(sext_ln703_91_fu_130684_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_115_fu_118165_p2() {
    add_ln703_115_fu_118165_p2 = (!zext_ln203_6_fu_117254_p1.read().is_01() || !sext_ln203_18_fu_117258_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_6_fu_117254_p1.read()) + sc_bigint<12>(sext_ln203_18_fu_117258_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_116_fu_130697_p2() {
    add_ln703_116_fu_130697_p2 = (!zext_ln708_235_fu_125265_p1.read().is_01() || !zext_ln708_234_fu_125146_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_235_fu_125265_p1.read()) + sc_biguint<11>(zext_ln708_234_fu_125146_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_117_fu_130707_p2() {
    add_ln703_117_fu_130707_p2 = (!sext_ln703_93_fu_130694_p1.read().is_01() || !zext_ln703_18_fu_130703_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_93_fu_130694_p1.read()) + sc_biguint<13>(zext_ln703_18_fu_130703_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_118_fu_130717_p2() {
    add_ln703_118_fu_130717_p2 = (!add_ln703_114_fu_130688_p2.read().is_01() || !sext_ln703_94_fu_130713_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_114_fu_130688_p2.read()) + sc_bigint<15>(sext_ln703_94_fu_130713_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_119_fu_137014_p2() {
    add_ln703_119_fu_137014_p2 = (!zext_ln708_237_fu_134032_p1.read().is_01() || !zext_ln708_236_fu_134005_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_237_fu_134032_p1.read()) + sc_biguint<11>(zext_ln708_236_fu_134005_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_11_fu_130258_p2() {
    add_ln703_11_fu_130258_p2 = (!sext_ln1116_6_reg_141850.read().is_01() || !sext_ln1116_2_fu_124339_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_6_reg_141850.read()) + sc_bigint<12>(sext_ln1116_2_fu_124339_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_120_fu_137024_p2() {
    add_ln703_120_fu_137024_p2 = (!sext_ln203_16_fu_133979_p1.read().is_01() || !zext_ln203_7_fu_134067_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_16_fu_133979_p1.read()) + sc_biguint<12>(zext_ln203_7_fu_134067_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_121_fu_137034_p2() {
    add_ln703_121_fu_137034_p2 = (!zext_ln703_19_fu_137020_p1.read().is_01() || !sext_ln703_96_fu_137030_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_19_fu_137020_p1.read()) + sc_bigint<13>(sext_ln703_96_fu_137030_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_122_fu_137040_p2() {
    add_ln703_122_fu_137040_p2 = (!sext_ln203_15_fu_133975_p1.read().is_01() || !sext_ln203_19_fu_134071_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_15_fu_133975_p1.read()) + sc_bigint<11>(sext_ln203_19_fu_134071_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_123_fu_137046_p2() {
    add_ln703_123_fu_137046_p2 = (!sext_ln203_11_fu_133962_p1.read().is_01() || !sext_ln203_17_fu_134063_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_11_fu_133962_p1.read()) + sc_bigint<9>(sext_ln203_17_fu_134063_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_124_fu_137056_p2() {
    add_ln703_124_fu_137056_p2 = (!add_ln703_122_fu_137040_p2.read().is_01() || !sext_ln703_101_fu_137052_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_122_fu_137040_p2.read()) + sc_bigint<11>(sext_ln703_101_fu_137052_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_125_fu_137066_p2() {
    add_ln703_125_fu_137066_p2 = (!add_ln703_121_fu_137034_p2.read().is_01() || !sext_ln703_102_fu_137062_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_121_fu_137034_p2.read()) + sc_bigint<13>(sext_ln703_102_fu_137062_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_127_fu_122797_p2() {
    add_ln703_127_fu_122797_p2 = (!trunc_ln1118_12_reg_141236.read().is_01() || !ap_const_lv8_B0.is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln1118_12_reg_141236.read()) + sc_bigint<8>(ap_const_lv8_B0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_128_fu_122806_p2() {
    add_ln703_128_fu_122806_p2 = (!sext_ln203_20_fu_119281_p1.read().is_01() || !sext_ln703_105_fu_122802_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_20_fu_119281_p1.read()) + sc_bigint<12>(sext_ln703_105_fu_122802_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_129_fu_122816_p2() {
    add_ln703_129_fu_122816_p2 = (!sext_ln203_21_fu_119285_p1.read().is_01() || !sext_ln703_22_fu_122812_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_21_fu_119285_p1.read()) + sc_bigint<13>(sext_ln703_22_fu_122812_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_12_fu_130267_p2() {
    add_ln703_12_fu_130267_p2 = (!sext_ln703_16_fu_130255_p1.read().is_01() || !sext_ln703_17_fu_130263_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_16_fu_130255_p1.read()) + sc_bigint<14>(sext_ln703_17_fu_130263_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_130_fu_122822_p2() {
    add_ln703_130_fu_122822_p2 = (!zext_ln1118_362_fu_119320_p1.read().is_01() || !sext_ln708_7_fu_119316_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_362_fu_119320_p1.read()) + sc_bigint<10>(sext_ln708_7_fu_119316_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_131_fu_122832_p2() {
    add_ln703_131_fu_122832_p2 = (!add_ln703_129_fu_122816_p2.read().is_01() || !sext_ln703_106_fu_122828_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_129_fu_122816_p2.read()) + sc_bigint<13>(sext_ln703_106_fu_122828_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_132_fu_122838_p2() {
    add_ln703_132_fu_122838_p2 = (!sext_ln1118_37_fu_119323_p1.read().is_01() || !add_ln703_131_fu_122832_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_37_fu_119323_p1.read()) + sc_biguint<13>(add_ln703_131_fu_122832_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_133_fu_122844_p2() {
    add_ln703_133_fu_122844_p2 = (!sext_ln1118_41_fu_119384_p1.read().is_01() || !sext_ln1118_38_fu_119329_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_41_fu_119384_p1.read()) + sc_bigint<10>(sext_ln1118_38_fu_119329_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_134_fu_122854_p2() {
    add_ln703_134_fu_122854_p2 = (!sext_ln1118_40_fu_119380_p1.read().is_01() || !sext_ln703_107_fu_122850_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_40_fu_119380_p1.read()) + sc_bigint<11>(sext_ln703_107_fu_122850_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_135_fu_122864_p2() {
    add_ln703_135_fu_122864_p2 = (!add_ln703_132_fu_122838_p2.read().is_01() || !sext_ln703_109_fu_122860_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_132_fu_122838_p2.read()) + sc_bigint<13>(sext_ln703_109_fu_122860_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_136_fu_122874_p2() {
    add_ln703_136_fu_122874_p2 = (!sext_ln1116_6_fu_118683_p1.read().is_01() || !sext_ln1118_44_fu_119421_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_6_fu_118683_p1.read()) + sc_bigint<12>(sext_ln1118_44_fu_119421_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_137_fu_122884_p2() {
    add_ln703_137_fu_122884_p2 = (!sext_ln703_110_fu_122870_p1.read().is_01() || !sext_ln703_111_fu_122880_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_110_fu_122870_p1.read()) + sc_bigint<14>(sext_ln703_111_fu_122880_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_138_fu_122890_p2() {
    add_ln703_138_fu_122890_p2 = (!zext_ln708_239_fu_119418_p1.read().is_01() || !zext_ln708_238_fu_119414_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_239_fu_119418_p1.read()) + sc_biguint<11>(zext_ln708_238_fu_119414_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_139_fu_118171_p2() {
    add_ln703_139_fu_118171_p2 = (!zext_ln1116_53_fu_117309_p1.read().is_01() || !zext_ln1118_547_fu_117305_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_53_fu_117309_p1.read()) + sc_biguint<10>(zext_ln1118_547_fu_117305_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_13_fu_118031_p2() {
    add_ln703_13_fu_118031_p2 = (!zext_ln708_222_fu_116921_p1.read().is_01() || !zext_ln708_221_fu_116877_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_222_fu_116921_p1.read()) + sc_biguint<11>(zext_ln708_221_fu_116877_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_140_fu_122899_p2() {
    add_ln703_140_fu_122899_p2 = (!add_ln703_138_fu_122890_p2.read().is_01() || !zext_ln703_20_fu_122896_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_138_fu_122890_p2.read()) + sc_biguint<11>(zext_ln703_20_fu_122896_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_141_fu_122909_p2() {
    add_ln703_141_fu_122909_p2 = (!add_ln703_137_fu_122884_p2.read().is_01() || !zext_ln703_21_fu_122905_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_137_fu_122884_p2.read()) + sc_biguint<14>(zext_ln703_21_fu_122905_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_142_fu_118177_p2() {
    add_ln703_142_fu_118177_p2 = (!zext_ln1118_550_fu_117352_p1.read().is_01() || !zext_ln1118_548_fu_117343_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_550_fu_117352_p1.read()) + sc_biguint<10>(zext_ln1118_548_fu_117343_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_143_fu_118183_p2() {
    add_ln703_143_fu_118183_p2 = (!zext_ln1116_54_fu_117328_p1.read().is_01() || !add_ln703_142_fu_118177_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_54_fu_117328_p1.read()) + sc_biguint<10>(add_ln703_142_fu_118177_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_144_fu_130726_p2() {
    add_ln703_144_fu_130726_p2 = (!sext_ln1118_45_fu_125343_p1.read().is_01() || !sext_ln1118_43_fu_125309_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_45_fu_125343_p1.read()) + sc_bigint<11>(sext_ln1118_43_fu_125309_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_145_fu_130736_p2() {
    add_ln703_145_fu_130736_p2 = (!sext_ln1118_46_fu_125351_p1.read().is_01() || !sext_ln1118_47_fu_125385_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_46_fu_125351_p1.read()) + sc_bigint<11>(sext_ln1118_47_fu_125385_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_146_fu_130746_p2() {
    add_ln703_146_fu_130746_p2 = (!sext_ln703_113_fu_130732_p1.read().is_01() || !sext_ln703_114_fu_130742_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_113_fu_130732_p1.read()) + sc_bigint<12>(sext_ln703_114_fu_130742_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_147_fu_130756_p2() {
    add_ln703_147_fu_130756_p2 = (!zext_ln703_22_fu_130723_p1.read().is_01() || !sext_ln703_115_fu_130752_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_22_fu_130723_p1.read()) + sc_bigint<13>(sext_ln703_115_fu_130752_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_148_fu_137088_p2() {
    add_ln703_148_fu_137088_p2 = (!sext_ln703_112_fu_137082_p1.read().is_01() || !sext_ln703_119_fu_137085_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_112_fu_137082_p1.read()) + sc_bigint<15>(sext_ln703_119_fu_137085_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_149_fu_137094_p2() {
    add_ln703_149_fu_137094_p2 = (!zext_ln203_8_fu_134075_p1.read().is_01() || !add_ln703_148_fu_137088_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_8_fu_134075_p1.read()) + sc_biguint<15>(add_ln703_148_fu_137088_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_14_fu_118041_p2() {
    add_ln703_14_fu_118041_p2 = (!sext_ln1116_7_fu_117015_p1.read().is_01() || !zext_ln703_5_fu_118037_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_7_fu_117015_p1.read()) + sc_biguint<13>(zext_ln703_5_fu_118037_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_150_fu_137100_p2() {
    add_ln703_150_fu_137100_p2 = (!zext_ln203_10_fu_134090_p1.read().is_01() || !sext_ln203_24_fu_134188_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_10_fu_134090_p1.read()) + sc_bigint<12>(sext_ln203_24_fu_134188_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_151_fu_137110_p2() {
    add_ln703_151_fu_137110_p2 = (!sext_ln203_23_fu_134086_p1.read().is_01() || !sext_ln703_123_fu_137106_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_23_fu_134086_p1.read()) + sc_bigint<13>(sext_ln703_123_fu_137106_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_152_fu_137120_p2() {
    add_ln703_152_fu_137120_p2 = (!add_ln703_149_fu_137094_p2.read().is_01() || !sext_ln703_126_fu_137116_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_149_fu_137094_p2.read()) + sc_bigint<15>(sext_ln703_126_fu_137116_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_153_fu_137126_p2() {
    add_ln703_153_fu_137126_p2 = (!zext_ln708_242_fu_134174_p1.read().is_01() || !zext_ln708_241_fu_134157_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_242_fu_134174_p1.read()) + sc_biguint<11>(zext_ln708_241_fu_134157_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_154_fu_137132_p2() {
    add_ln703_154_fu_137132_p2 = (!zext_ln708_240_fu_134119_p1.read().is_01() || !add_ln703_153_fu_137126_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_240_fu_134119_p1.read()) + sc_biguint<11>(add_ln703_153_fu_137126_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_155_fu_137142_p2() {
    add_ln703_155_fu_137142_p2 = (!zext_ln203_9_fu_134079_p1.read().is_01() || !sext_ln203_22_fu_134082_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln203_9_fu_134079_p1.read()) + sc_bigint<11>(sext_ln203_22_fu_134082_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_156_fu_137148_p2() {
    add_ln703_156_fu_137148_p2 = (!zext_ln708_243_fu_134218_p1.read().is_01() || !add_ln703_155_fu_137142_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_243_fu_134218_p1.read()) + sc_biguint<11>(add_ln703_155_fu_137142_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_157_fu_137158_p2() {
    add_ln703_157_fu_137158_p2 = (!zext_ln703_23_fu_137138_p1.read().is_01() || !sext_ln703_127_fu_137154_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_23_fu_137138_p1.read()) + sc_bigint<13>(sext_ln703_127_fu_137154_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_159_fu_118189_p2() {
    add_ln703_159_fu_118189_p2 = (!zext_ln203_11_fu_117397_p1.read().is_01() || !ap_const_lv9_E8.is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_11_fu_117397_p1.read()) + sc_biguint<9>(ap_const_lv9_E8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_15_fu_130280_p2() {
    add_ln703_15_fu_130280_p2 = (!sext_ln703_18_fu_130273_p1.read().is_01() || !sext_ln703_19_fu_130277_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_18_fu_130273_p1.read()) + sc_bigint<15>(sext_ln703_19_fu_130277_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_160_fu_118199_p2() {
    add_ln703_160_fu_118199_p2 = (!zext_ln703_fu_118195_p1.read().is_01() || !sext_ln203_25_fu_117401_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_fu_118195_p1.read()) + sc_bigint<12>(sext_ln203_25_fu_117401_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_161_fu_118205_p2() {
    add_ln703_161_fu_118205_p2 = (!zext_ln1118_449_fu_117409_p1.read().is_01() || !add_ln703_160_fu_118199_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_449_fu_117409_p1.read()) + sc_biguint<12>(add_ln703_160_fu_118199_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_162_fu_118215_p2() {
    add_ln703_162_fu_118215_p2 = (!sext_ln708_8_fu_117413_p1.read().is_01() || !sext_ln1118_48_fu_117405_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_8_fu_117413_p1.read()) + sc_bigint<11>(sext_ln1118_48_fu_117405_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_163_fu_118225_p2() {
    add_ln703_163_fu_118225_p2 = (!sext_ln703_130_fu_118211_p1.read().is_01() || !sext_ln703_131_fu_118221_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_130_fu_118211_p1.read()) + sc_bigint<13>(sext_ln703_131_fu_118221_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_164_fu_118231_p2() {
    add_ln703_164_fu_118231_p2 = (!zext_ln1118_450_fu_117417_p1.read().is_01() || !add_ln703_163_fu_118225_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_450_fu_117417_p1.read()) + sc_biguint<13>(add_ln703_163_fu_118225_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_165_fu_118237_p2() {
    add_ln703_165_fu_118237_p2 = (!zext_ln708_245_fu_117429_p1.read().is_01() || !zext_ln1118_553_fu_117425_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln708_245_fu_117429_p1.read()) + sc_biguint<9>(zext_ln1118_553_fu_117425_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_166_fu_118247_p2() {
    add_ln703_166_fu_118247_p2 = (!zext_ln708_244_fu_117421_p1.read().is_01() || !zext_ln703_24_fu_118243_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_244_fu_117421_p1.read()) + sc_biguint<11>(zext_ln703_24_fu_118243_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_167_fu_118257_p2() {
    add_ln703_167_fu_118257_p2 = (!add_ln703_164_fu_118231_p2.read().is_01() || !zext_ln703_25_fu_118253_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_164_fu_118231_p2.read()) + sc_biguint<13>(zext_ln703_25_fu_118253_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_168_fu_130765_p2() {
    add_ln703_168_fu_130765_p2 = (!trunc_ln1118_17_fu_125470_p4.read().is_01() || !zext_ln708_247_fu_125450_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_17_fu_125470_p4.read()) + sc_biguint<10>(zext_ln708_247_fu_125450_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_169_fu_130775_p2() {
    add_ln703_169_fu_130775_p2 = (!sext_ln1118_50_fu_125396_p1.read().is_01() || !sext_ln708_9_fu_125393_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_50_fu_125396_p1.read()) + sc_bigint<10>(sext_ln708_9_fu_125393_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_16_fu_130286_p2() {
    add_ln703_16_fu_130286_p2 = (!sext_ln1116_3_fu_124343_p1.read().is_01() || !zext_ln708_224_fu_124466_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_3_fu_124343_p1.read()) + sc_biguint<11>(zext_ln708_224_fu_124466_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_170_fu_130781_p2() {
    add_ln703_170_fu_130781_p2 = (!zext_ln708_246_fu_125415_p1.read().is_01() || !add_ln703_169_fu_130775_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_246_fu_125415_p1.read()) + sc_biguint<10>(add_ln703_169_fu_130775_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_171_fu_130791_p2() {
    add_ln703_171_fu_130791_p2 = (!zext_ln703_26_fu_130771_p1.read().is_01() || !sext_ln703_135_fu_130787_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_26_fu_130771_p1.read()) + sc_bigint<12>(sext_ln703_135_fu_130787_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_172_fu_130801_p2() {
    add_ln703_172_fu_130801_p2 = (!sext_ln703_134_fu_130762_p1.read().is_01() || !sext_ln703_136_fu_130797_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_134_fu_130762_p1.read()) + sc_bigint<14>(sext_ln703_136_fu_130797_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_173_fu_130807_p2() {
    add_ln703_173_fu_130807_p2 = (!sext_ln1118_54_fu_125527_p1.read().is_01() || !add_ln703_172_fu_130801_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_54_fu_125527_p1.read()) + sc_biguint<14>(add_ln703_172_fu_130801_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_174_fu_130813_p2() {
    add_ln703_174_fu_130813_p2 = (!zext_ln1118_557_fu_125569_p1.read().is_01() || !zext_ln1118_555_fu_125565_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln1118_557_fu_125569_p1.read()) + sc_biguint<8>(zext_ln1118_555_fu_125565_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_175_fu_130823_p2() {
    add_ln703_175_fu_130823_p2 = (!zext_ln1118_554_fu_125507_p1.read().is_01() || !zext_ln703_27_fu_130819_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_554_fu_125507_p1.read()) + sc_biguint<10>(zext_ln703_27_fu_130819_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_176_fu_130833_p2() {
    add_ln703_176_fu_130833_p2 = (!add_ln703_173_fu_130807_p2.read().is_01() || !zext_ln703_28_fu_130829_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_173_fu_130807_p2.read()) + sc_biguint<14>(zext_ln703_28_fu_130829_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_177_fu_118263_p2() {
    add_ln703_177_fu_118263_p2 = (!sext_ln1118_53_fu_117457_p1.read().is_01() || !sext_ln1118_52_fu_117453_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_53_fu_117457_p1.read()) + sc_bigint<11>(sext_ln1118_52_fu_117453_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_178_fu_118273_p2() {
    add_ln703_178_fu_118273_p2 = (!zext_ln1118_460_fu_117479_p1.read().is_01() || !sext_ln703_138_fu_118269_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_460_fu_117479_p1.read()) + sc_bigint<12>(sext_ln703_138_fu_118269_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_179_fu_118283_p2() {
    add_ln703_179_fu_118283_p2 = (!sext_ln1118_51_fu_117449_p1.read().is_01() || !sext_ln708_10_fu_117465_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_51_fu_117449_p1.read()) + sc_bigint<11>(sext_ln708_10_fu_117465_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_17_fu_130296_p2() {
    add_ln703_17_fu_130296_p2 = (!zext_ln1116_20_fu_124425_p1.read().is_01() || !sext_ln703_20_fu_130292_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_20_fu_124425_p1.read()) + sc_bigint<12>(sext_ln703_20_fu_130292_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_180_fu_118293_p2() {
    add_ln703_180_fu_118293_p2 = (!sext_ln1118_55_fu_117461_p1.read().is_01() || !sext_ln703_142_fu_118289_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_55_fu_117461_p1.read()) + sc_bigint<12>(sext_ln703_142_fu_118289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_181_fu_118303_p2() {
    add_ln703_181_fu_118303_p2 = (!sext_ln703_139_fu_118279_p1.read().is_01() || !sext_ln703_143_fu_118299_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_139_fu_118279_p1.read()) + sc_bigint<13>(sext_ln703_143_fu_118299_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_182_fu_137184_p2() {
    add_ln703_182_fu_137184_p2 = (!sext_ln703_137_fu_137178_p1.read().is_01() || !sext_ln703_144_fu_137181_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_137_fu_137178_p1.read()) + sc_bigint<15>(sext_ln703_144_fu_137181_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_183_fu_137190_p2() {
    add_ln703_183_fu_137190_p2 = (!sext_ln203_26_fu_134222_p1.read().is_01() || !add_ln703_182_fu_137184_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_26_fu_134222_p1.read()) + sc_biguint<15>(add_ln703_182_fu_137184_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_184_fu_137196_p2() {
    add_ln703_184_fu_137196_p2 = (!sext_ln203_28_fu_134295_p1.read().is_01() || !sext_ln203_27_fu_134246_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_28_fu_134295_p1.read()) + sc_bigint<12>(sext_ln203_27_fu_134246_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_185_fu_137206_p2() {
    add_ln703_185_fu_137206_p2 = (!add_ln703_183_fu_137190_p2.read().is_01() || !sext_ln703_145_fu_137202_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_183_fu_137190_p2.read()) + sc_bigint<15>(sext_ln703_145_fu_137202_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_186_fu_137212_p2() {
    add_ln703_186_fu_137212_p2 = (!zext_ln203_90_fu_134250_p1.read().is_01() || !zext_ln203_89_fu_134242_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_90_fu_134250_p1.read()) + sc_biguint<10>(zext_ln203_89_fu_134242_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_187_fu_137222_p2() {
    add_ln703_187_fu_137222_p2 = (!zext_ln708_249_fu_134329_p1.read().is_01() || !zext_ln708_248_fu_134264_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_249_fu_134329_p1.read()) + sc_biguint<11>(zext_ln708_248_fu_134264_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_188_fu_137228_p2() {
    add_ln703_188_fu_137228_p2 = (!zext_ln703_29_fu_137218_p1.read().is_01() || !add_ln703_187_fu_137222_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_29_fu_137218_p1.read()) + sc_biguint<11>(add_ln703_187_fu_137222_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_18_fu_130302_p2() {
    add_ln703_18_fu_130302_p2 = (!sext_ln1116_5_fu_124422_p1.read().is_01() || !sext_ln1116_4_fu_124415_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_5_fu_124422_p1.read()) + sc_bigint<10>(sext_ln1116_4_fu_124415_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_190_fu_130839_p2() {
    add_ln703_190_fu_130839_p2 = (!sext_ln203_29_fu_125572_p1.read().is_01() || !ap_const_lv12_C00.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_29_fu_125572_p1.read()) + sc_bigint<12>(ap_const_lv12_C00));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_191_fu_130849_p2() {
    add_ln703_191_fu_130849_p2 = (!sext_ln203_30_fu_125575_p1.read().is_01() || !sext_ln703_30_fu_130845_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_30_fu_125575_p1.read()) + sc_bigint<13>(sext_ln703_30_fu_130845_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_192_fu_118309_p2() {
    add_ln703_192_fu_118309_p2 = (!zext_ln1118_560_fu_117491_p1.read().is_01() || !zext_ln1118_559_fu_117487_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_560_fu_117491_p1.read()) + sc_biguint<10>(zext_ln1118_559_fu_117487_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_193_fu_118319_p2() {
    add_ln703_193_fu_118319_p2 = (!sext_ln1118_56_fu_117483_p1.read().is_01() || !zext_ln703_31_fu_118315_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_56_fu_117483_p1.read()) + sc_biguint<12>(zext_ln703_31_fu_118315_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_194_fu_130858_p2() {
    add_ln703_194_fu_130858_p2 = (!add_ln703_191_fu_130849_p2.read().is_01() || !sext_ln703_147_fu_130855_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_191_fu_130849_p2.read()) + sc_bigint<13>(sext_ln703_147_fu_130855_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_195_fu_137251_p2() {
    add_ln703_195_fu_137251_p2 = (!sext_ln203_31_fu_134333_p1.read().is_01() || !sext_ln703_31_fu_137248_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_31_fu_134333_p1.read()) + sc_bigint<14>(sext_ln703_31_fu_137248_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_196_fu_118325_p2() {
    add_ln703_196_fu_118325_p2 = (!zext_ln1118_562_fu_117503_p1.read().is_01() || !zext_ln1118_561_fu_117499_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_562_fu_117503_p1.read()) + sc_biguint<10>(zext_ln1118_561_fu_117499_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_197_fu_130867_p2() {
    add_ln703_197_fu_130867_p2 = (!sext_ln1116_2_fu_124339_p1.read().is_01() || !zext_ln703_32_fu_130864_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_2_fu_124339_p1.read()) + sc_biguint<12>(zext_ln703_32_fu_130864_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_198_fu_137260_p2() {
    add_ln703_198_fu_137260_p2 = (!add_ln703_195_fu_137251_p2.read().is_01() || !sext_ln703_148_fu_137257_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_195_fu_137251_p2.read()) + sc_bigint<14>(sext_ln703_148_fu_137257_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_199_fu_122915_p2() {
    add_ln703_199_fu_122915_p2 = (!zext_ln708_251_fu_119580_p1.read().is_01() || !trunc_ln1118_s_reg_141368.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln708_251_fu_119580_p1.read()) + sc_biguint<9>(trunc_ln1118_s_reg_141368.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_19_fu_130312_p2() {
    add_ln703_19_fu_130312_p2 = (!zext_ln1118_116_fu_124380_p1.read().is_01() || !sext_ln703_21_fu_130308_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_116_fu_124380_p1.read()) + sc_bigint<11>(sext_ln703_21_fu_130308_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_1_fu_122505_p2() {
    add_ln703_1_fu_122505_p2 = (!zext_ln1116_3_fu_118481_p1.read().is_01() || !add_ln703_fu_122499_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_3_fu_118481_p1.read()) + sc_biguint<12>(add_ln703_fu_122499_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_200_fu_122924_p2() {
    add_ln703_200_fu_122924_p2 = (!zext_ln708_250_fu_119550_p1.read().is_01() || !zext_ln703_33_fu_122920_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_250_fu_119550_p1.read()) + sc_biguint<10>(zext_ln703_33_fu_122920_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_201_fu_118331_p2() {
    add_ln703_201_fu_118331_p2 = (!zext_ln1118_469_fu_117517_p1.read().is_01() || !sext_ln1118_57_fu_117495_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_469_fu_117517_p1.read()) + sc_bigint<11>(sext_ln1118_57_fu_117495_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_202_fu_118341_p2() {
    add_ln703_202_fu_118341_p2 = (!zext_ln708_40_fu_117531_p1.read().is_01() || !sext_ln703_149_fu_118337_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_40_fu_117531_p1.read()) + sc_bigint<12>(sext_ln703_149_fu_118337_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_203_fu_122937_p2() {
    add_ln703_203_fu_122937_p2 = (!zext_ln703_34_fu_122930_p1.read().is_01() || !sext_ln703_150_fu_122934_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_34_fu_122930_p1.read()) + sc_bigint<13>(sext_ln703_150_fu_122934_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_204_fu_137269_p2() {
    add_ln703_204_fu_137269_p2 = (!add_ln703_198_fu_137260_p2.read().is_01() || !sext_ln703_151_fu_137266_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_198_fu_137260_p2.read()) + sc_bigint<14>(sext_ln703_151_fu_137266_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_205_fu_130873_p2() {
    add_ln703_205_fu_130873_p2 = (!sext_ln1118_59_fu_125607_p1.read().is_01() || !zext_ln1118_471_fu_125578_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_59_fu_125607_p1.read()) + sc_biguint<12>(zext_ln1118_471_fu_125578_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_206_fu_137278_p2() {
    add_ln703_206_fu_137278_p2 = (!add_ln703_204_fu_137269_p2.read().is_01() || !sext_ln703_152_fu_137275_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_204_fu_137269_p2.read()) + sc_bigint<14>(sext_ln703_152_fu_137275_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_207_fu_130879_p2() {
    add_ln703_207_fu_130879_p2 = (!sext_ln1118_20_fu_125068_p1.read().is_01() || !sext_ln1118_60_fu_125611_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_20_fu_125068_p1.read()) + sc_bigint<12>(sext_ln1118_60_fu_125611_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_208_fu_137291_p2() {
    add_ln703_208_fu_137291_p2 = (!zext_ln1118_472_fu_134337_p1.read().is_01() || !sext_ln708_11_fu_134359_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_472_fu_134337_p1.read()) + sc_bigint<12>(sext_ln708_11_fu_134359_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_209_fu_137301_p2() {
    add_ln703_209_fu_137301_p2 = (!sext_ln703_154_fu_137288_p1.read().is_01() || !sext_ln703_155_fu_137297_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_154_fu_137288_p1.read()) + sc_bigint<13>(sext_ln703_155_fu_137297_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_20_fu_130322_p2() {
    add_ln703_20_fu_130322_p2 = (!add_ln703_17_fu_130296_p2.read().is_01() || !sext_ln703_23_fu_130318_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_17_fu_130296_p2.read()) + sc_bigint<12>(sext_ln703_23_fu_130318_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_210_fu_137311_p2() {
    add_ln703_210_fu_137311_p2 = (!sext_ln703_153_fu_137284_p1.read().is_01() || !sext_ln703_156_fu_137307_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_153_fu_137284_p1.read()) + sc_bigint<15>(sext_ln703_156_fu_137307_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_211_fu_118347_p2() {
    add_ln703_211_fu_118347_p2 = (!zext_ln1118_565_fu_117545_p1.read().is_01() || !grp_fu_115887_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_565_fu_117545_p1.read()) + sc_biguint<9>(grp_fu_115887_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_212_fu_130888_p2() {
    add_ln703_212_fu_130888_p2 = (!trunc_ln1118_22_reg_141383.read().is_01() || !zext_ln1118_566_fu_125694_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_22_reg_141383.read()) + sc_biguint<10>(zext_ln1118_566_fu_125694_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_213_fu_130897_p2() {
    add_ln703_213_fu_130897_p2 = (!zext_ln703_35_fu_130885_p1.read().is_01() || !zext_ln703_36_fu_130893_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_35_fu_130885_p1.read()) + sc_biguint<11>(zext_ln703_36_fu_130893_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_214_fu_137320_p2() {
    add_ln703_214_fu_137320_p2 = (!trunc_ln708_958_fu_134417_p4.read().is_01() || !zext_ln708_252_fu_134397_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln708_958_fu_134417_p4.read()) + sc_biguint<10>(zext_ln708_252_fu_134397_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_215_fu_137330_p2() {
    add_ln703_215_fu_137330_p2 = (!sext_ln1118_62_fu_134340_p1.read().is_01() || !zext_ln708_253_fu_134451_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_62_fu_134340_p1.read()) + sc_biguint<11>(zext_ln708_253_fu_134451_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_216_fu_137340_p2() {
    add_ln703_216_fu_137340_p2 = (!zext_ln703_38_fu_137326_p1.read().is_01() || !sext_ln703_157_fu_137336_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_38_fu_137326_p1.read()) + sc_bigint<12>(sext_ln703_157_fu_137336_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_217_fu_137350_p2() {
    add_ln703_217_fu_137350_p2 = (!zext_ln703_37_fu_137317_p1.read().is_01() || !sext_ln703_158_fu_137346_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_37_fu_137317_p1.read()) + sc_bigint<13>(sext_ln703_158_fu_137346_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_218_fu_137360_p2() {
    add_ln703_218_fu_137360_p2 = (!add_ln703_210_fu_137311_p2.read().is_01() || !sext_ln703_159_fu_137356_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_210_fu_137311_p2.read()) + sc_bigint<15>(sext_ln703_159_fu_137356_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_219_fu_137366_p2() {
    add_ln703_219_fu_137366_p2 = (!zext_ln203_12_fu_134465_p1.read().is_01() || !add_ln703_218_fu_137360_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_12_fu_134465_p1.read()) + sc_biguint<15>(add_ln703_218_fu_137360_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_21_fu_130332_p2() {
    add_ln703_21_fu_130332_p2 = (!add_ln703_15_fu_130280_p2.read().is_01() || !sext_ln703_24_fu_130328_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_15_fu_130280_p2.read()) + sc_bigint<15>(sext_ln703_24_fu_130328_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_220_fu_137372_p2() {
    add_ln703_220_fu_137372_p2 = (!zext_ln708_255_fu_134493_p1.read().is_01() || !zext_ln708_254_fu_134489_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_255_fu_134493_p1.read()) + sc_biguint<11>(zext_ln708_254_fu_134489_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_222_fu_122943_p2() {
    add_ln703_222_fu_122943_p2 = (!zext_ln203_91_fu_119615_p1.read().is_01() || !ap_const_lv10_2F0.is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_91_fu_119615_p1.read()) + sc_bigint<10>(ap_const_lv10_2F0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_223_fu_122949_p2() {
    add_ln703_223_fu_122949_p2 = (!sext_ln1118_64_fu_119638_p1.read().is_01() || !add_ln703_222_fu_122943_p2.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_64_fu_119638_p1.read()) + sc_biguint<10>(add_ln703_222_fu_122943_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_224_fu_122959_p2() {
    add_ln703_224_fu_122959_p2 = (!sext_ln1118_66_fu_119661_p1.read().is_01() || !sext_ln1118_65_fu_119642_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_66_fu_119661_p1.read()) + sc_bigint<11>(sext_ln1118_65_fu_119642_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_225_fu_122969_p2() {
    add_ln703_225_fu_122969_p2 = (!sext_ln703_161_fu_122955_p1.read().is_01() || !sext_ln703_162_fu_122965_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_161_fu_122955_p1.read()) + sc_bigint<12>(sext_ln703_162_fu_122965_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_226_fu_122975_p2() {
    add_ln703_226_fu_122975_p2 = (!sext_ln1118_69_fu_119709_p1.read().is_01() || !zext_ln708_256_fu_119705_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_69_fu_119709_p1.read()) + sc_biguint<11>(zext_ln708_256_fu_119705_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_227_fu_122985_p2() {
    add_ln703_227_fu_122985_p2 = (!add_ln703_225_fu_122969_p2.read().is_01() || !sext_ln703_163_fu_122981_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_225_fu_122969_p2.read()) + sc_bigint<12>(sext_ln703_163_fu_122981_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_228_fu_118353_p2() {
    add_ln703_228_fu_118353_p2 = (!sext_ln1118_70_fu_117563_p1.read().is_01() || !sext_ln1118_68_fu_117559_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_70_fu_117563_p1.read()) + sc_bigint<10>(sext_ln1118_68_fu_117559_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_229_fu_122998_p2() {
    add_ln703_229_fu_122998_p2 = (!sext_ln1118_67_fu_119681_p1.read().is_01() || !sext_ln703_165_fu_122995_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_67_fu_119681_p1.read()) + sc_bigint<11>(sext_ln703_165_fu_122995_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_22_fu_130338_p2() {
    add_ln703_22_fu_130338_p2 = (!zext_ln203_fu_124473_p1.read().is_01() || !add_ln703_21_fu_130332_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_fu_124473_p1.read()) + sc_biguint<15>(add_ln703_21_fu_130332_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_230_fu_123008_p2() {
    add_ln703_230_fu_123008_p2 = (!sext_ln703_164_fu_122991_p1.read().is_01() || !sext_ln703_166_fu_123004_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_164_fu_122991_p1.read()) + sc_bigint<13>(sext_ln703_166_fu_123004_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_231_fu_123014_p2() {
    add_ln703_231_fu_123014_p2 = (!sext_ln1118_82_fu_119737_p1.read().is_01() || !add_ln703_230_fu_123008_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_82_fu_119737_p1.read()) + sc_biguint<13>(add_ln703_230_fu_123008_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_232_fu_130906_p2() {
    add_ln703_232_fu_130906_p2 = (!sext_ln1118_74_fu_125737_p1.read().is_01() || !zext_ln708_257_fu_125869_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_74_fu_125737_p1.read()) + sc_biguint<11>(zext_ln708_257_fu_125869_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_233_fu_130916_p2() {
    add_ln703_233_fu_130916_p2 = (!zext_ln1118_491_fu_125741_p1.read().is_01() || !sext_ln703_168_fu_130912_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_491_fu_125741_p1.read()) + sc_bigint<12>(sext_ln703_168_fu_130912_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_234_fu_130926_p2() {
    add_ln703_234_fu_130926_p2 = (!sext_ln703_167_fu_130903_p1.read().is_01() || !sext_ln703_169_fu_130922_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_167_fu_130903_p1.read()) + sc_bigint<14>(sext_ln703_169_fu_130922_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_235_fu_130932_p2() {
    add_ln703_235_fu_130932_p2 = (!sext_ln1118_81_fu_125865_p1.read().is_01() || !sext_ln1118_77_fu_125792_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_81_fu_125865_p1.read()) + sc_bigint<11>(sext_ln1118_77_fu_125792_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_236_fu_137395_p2() {
    add_ln703_236_fu_137395_p2 = (!sext_ln1118_75_fu_134497_p1.read().is_01() || !sext_ln703_170_fu_137392_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_75_fu_134497_p1.read()) + sc_bigint<12>(sext_ln703_170_fu_137392_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_237_fu_130938_p2() {
    add_ln703_237_fu_130938_p2 = (!sext_ln1118_83_fu_125872_p1.read().is_01() || !sext_ln1118_79_fu_125825_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_83_fu_125872_p1.read()) + sc_bigint<9>(sext_ln1118_79_fu_125825_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_238_fu_130948_p2() {
    add_ln703_238_fu_130948_p2 = (!sext_ln1118_72_fu_125698_p1.read().is_01() || !sext_ln703_171_fu_130944_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_72_fu_125698_p1.read()) + sc_bigint<10>(sext_ln703_171_fu_130944_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_239_fu_137404_p2() {
    add_ln703_239_fu_137404_p2 = (!add_ln703_236_fu_137395_p2.read().is_01() || !sext_ln703_172_fu_137401_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_236_fu_137395_p2.read()) + sc_bigint<12>(sext_ln703_172_fu_137401_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_23_fu_136887_p2() {
    add_ln703_23_fu_136887_p2 = (!zext_ln203_85_fu_133773_p1.read().is_01() || !zext_ln203_84_fu_133715_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_85_fu_133773_p1.read()) + sc_biguint<10>(zext_ln203_84_fu_133715_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_240_fu_137414_p2() {
    add_ln703_240_fu_137414_p2 = (!add_ln703_234_reg_142893.read().is_01() || !sext_ln703_173_fu_137410_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_234_reg_142893.read()) + sc_bigint<14>(sext_ln703_173_fu_137410_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_241_fu_137419_p2() {
    add_ln703_241_fu_137419_p2 = (!sext_ln203_36_fu_134542_p1.read().is_01() || !zext_ln203_13_fu_134501_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_36_fu_134542_p1.read()) + sc_biguint<12>(zext_ln203_13_fu_134501_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_242_fu_137429_p2() {
    add_ln703_242_fu_137429_p2 = (!add_ln703_240_fu_137414_p2.read().is_01() || !sext_ln703_174_fu_137425_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_240_fu_137414_p2.read()) + sc_bigint<14>(sext_ln703_174_fu_137425_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_243_fu_137439_p2() {
    add_ln703_243_fu_137439_p2 = (!zext_ln203_93_fu_134562_p1.read().is_01() || !zext_ln203_92_fu_134515_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_93_fu_134562_p1.read()) + sc_biguint<9>(zext_ln203_92_fu_134515_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_244_fu_137449_p2() {
    add_ln703_244_fu_137449_p2 = (!zext_ln203_88_fu_133902_p1.read().is_01() || !zext_ln203_94_fu_134570_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_88_fu_133902_p1.read()) + sc_biguint<9>(zext_ln203_94_fu_134570_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_245_fu_137459_p2() {
    add_ln703_245_fu_137459_p2 = (!zext_ln703_40_fu_137445_p1.read().is_01() || !zext_ln703_41_fu_137455_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln703_40_fu_137445_p1.read()) + sc_biguint<10>(zext_ln703_41_fu_137455_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_246_fu_137469_p2() {
    add_ln703_246_fu_137469_p2 = (!sext_ln703_175_fu_137435_p1.read().is_01() || !zext_ln703_42_fu_137465_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_175_fu_137435_p1.read()) + sc_biguint<15>(zext_ln703_42_fu_137465_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_247_fu_130954_p2() {
    add_ln703_247_fu_130954_p2 = (!sext_ln203_34_fu_125894_p1.read().is_01() || !sext_ln203_33_fu_125875_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_34_fu_125894_p1.read()) + sc_bigint<11>(sext_ln203_33_fu_125875_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_248_fu_137478_p2() {
    add_ln703_248_fu_137478_p2 = (!sext_ln203_32_fu_134519_p1.read().is_01() || !sext_ln703_176_fu_137475_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_32_fu_134519_p1.read()) + sc_bigint<12>(sext_ln703_176_fu_137475_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_249_fu_137488_p2() {
    add_ln703_249_fu_137488_p2 = (!sext_ln203_37_fu_134566_p1.read().is_01() || !sext_ln203_39_fu_134640_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_37_fu_134566_p1.read()) + sc_bigint<11>(sext_ln203_39_fu_134640_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_24_fu_136897_p2() {
    add_ln703_24_fu_136897_p2 = (!sext_ln203_1_fu_133664_p1.read().is_01() || !zext_ln703_6_fu_136893_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_1_fu_133664_p1.read()) + sc_biguint<12>(zext_ln703_6_fu_136893_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_250_fu_137494_p2() {
    add_ln703_250_fu_137494_p2 = (!sext_ln203_38_fu_134605_p1.read().is_01() || !sext_ln203_35_fu_134538_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_38_fu_134605_p1.read()) + sc_bigint<9>(sext_ln203_35_fu_134538_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_251_fu_137504_p2() {
    add_ln703_251_fu_137504_p2 = (!add_ln703_249_fu_137488_p2.read().is_01() || !sext_ln703_178_fu_137500_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_249_fu_137488_p2.read()) + sc_bigint<11>(sext_ln703_178_fu_137500_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_252_fu_137514_p2() {
    add_ln703_252_fu_137514_p2 = (!sext_ln703_177_fu_137484_p1.read().is_01() || !sext_ln703_179_fu_137510_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_177_fu_137484_p1.read()) + sc_bigint<13>(sext_ln703_179_fu_137510_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_254_fu_123020_p2() {
    add_ln703_254_fu_123020_p2 = (!trunc_ln1118_23_fu_119824_p4.read().is_01() || !zext_ln1116_55_fu_119787_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln1118_23_fu_119824_p4.read()) + sc_biguint<9>(zext_ln1116_55_fu_119787_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_255_fu_123030_p2() {
    add_ln703_255_fu_123030_p2 = (!zext_ln703_43_fu_123026_p1.read().is_01() || !ap_const_lv11_418.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_43_fu_123026_p1.read()) + sc_bigint<11>(ap_const_lv11_418));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_256_fu_118359_p2() {
    add_ln703_256_fu_118359_p2 = (!trunc_ln1116_5_fu_117576_p4.read().is_01() || !zext_ln1118_567_fu_117572_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1116_5_fu_117576_p4.read()) + sc_biguint<10>(zext_ln1118_567_fu_117572_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_257_fu_123043_p2() {
    add_ln703_257_fu_123043_p2 = (!sext_ln1118_84_fu_119756_p1.read().is_01() || !zext_ln708_258_fu_119837_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_84_fu_119756_p1.read()) + sc_biguint<11>(zext_ln708_258_fu_119837_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_258_fu_123053_p2() {
    add_ln703_258_fu_123053_p2 = (!zext_ln703_44_fu_123040_p1.read().is_01() || !sext_ln703_183_fu_123049_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_44_fu_123040_p1.read()) + sc_bigint<12>(sext_ln703_183_fu_123049_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_259_fu_123059_p2() {
    add_ln703_259_fu_123059_p2 = (!sext_ln703_182_fu_123036_p1.read().is_01() || !add_ln703_258_fu_123053_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_182_fu_123036_p1.read()) + sc_biguint<12>(add_ln703_258_fu_123053_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_25_fu_136907_p2() {
    add_ln703_25_fu_136907_p2 = (!add_ln703_22_reg_142833.read().is_01() || !sext_ln703_25_fu_136903_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_22_reg_142833.read()) + sc_bigint<15>(sext_ln703_25_fu_136903_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_260_fu_123065_p2() {
    add_ln703_260_fu_123065_p2 = (!sext_ln1116_8_fu_119883_p1.read().is_01() || !sext_ln1118_41_fu_119384_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_8_fu_119883_p1.read()) + sc_bigint<10>(sext_ln1118_41_fu_119384_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_261_fu_123075_p2() {
    add_ln703_261_fu_123075_p2 = (!add_ln703_259_fu_123059_p2.read().is_01() || !sext_ln703_184_fu_123071_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_259_fu_123059_p2.read()) + sc_bigint<12>(sext_ln703_184_fu_123071_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_262_fu_123081_p2() {
    add_ln703_262_fu_123081_p2 = (!zext_ln708_45_fu_119887_p1.read().is_01() || !add_ln703_261_fu_123075_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_45_fu_119887_p1.read()) + sc_biguint<12>(add_ln703_261_fu_123075_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_263_fu_130963_p2() {
    add_ln703_263_fu_130963_p2 = (!zext_ln708_259_fu_125931_p1.read().is_01() || !trunc_ln1116_6_fu_125921_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_259_fu_125931_p1.read()) + sc_biguint<10>(trunc_ln1116_6_fu_125921_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_264_fu_130973_p2() {
    add_ln703_264_fu_130973_p2 = (!sext_ln1118_87_fu_126023_p1.read().is_01() || !zext_ln703_45_fu_130969_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_87_fu_126023_p1.read()) + sc_biguint<12>(zext_ln703_45_fu_130969_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_265_fu_130983_p2() {
    add_ln703_265_fu_130983_p2 = (!sext_ln703_185_fu_130960_p1.read().is_01() || !sext_ln703_186_fu_130979_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_185_fu_130960_p1.read()) + sc_bigint<13>(sext_ln703_186_fu_130979_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_266_fu_130989_p2() {
    add_ln703_266_fu_130989_p2 = (!zext_ln1118_568_fu_125990_p1.read().is_01() || !trunc_ln1118_24_fu_125957_p4.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1118_568_fu_125990_p1.read()) + sc_biguint<7>(trunc_ln1118_24_fu_125957_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_267_fu_130999_p2() {
    add_ln703_267_fu_130999_p2 = (!sext_ln1118_88_fu_126054_p1.read().is_01() || !zext_ln1116_56_reg_141983.read().is_01())? sc_lv<6>(): (sc_bigint<6>(sext_ln1118_88_fu_126054_p1.read()) + sc_biguint<6>(zext_ln1116_56_reg_141983.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_268_fu_131008_p2() {
    add_ln703_268_fu_131008_p2 = (!sext_ln1116_9_fu_126058_p1.read().is_01() || !sext_ln703_187_fu_131004_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_9_fu_126058_p1.read()) + sc_bigint<11>(sext_ln703_187_fu_131004_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_269_fu_131014_p2() {
    add_ln703_269_fu_131014_p2 = (!zext_ln703_46_fu_130995_p1.read().is_01() || !add_ln703_268_fu_131008_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_46_fu_130995_p1.read()) + sc_biguint<11>(add_ln703_268_fu_131008_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_26_fu_136912_p2() {
    add_ln703_26_fu_136912_p2 = (!zext_ln203_86_fu_133856_p1.read().is_01() || !trunc_ln203_13_fu_133805_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_86_fu_133856_p1.read()) + sc_biguint<10>(trunc_ln203_13_fu_133805_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_270_fu_131024_p2() {
    add_ln703_270_fu_131024_p2 = (!add_ln703_265_fu_130983_p2.read().is_01() || !sext_ln703_188_fu_131020_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_265_fu_130983_p2.read()) + sc_bigint<13>(sext_ln703_188_fu_131020_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_271_fu_137537_p2() {
    add_ln703_271_fu_137537_p2 = (!zext_ln1116_36_fu_134654_p1.read().is_01() || !sext_ln703_189_fu_137534_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1116_36_fu_134654_p1.read()) + sc_bigint<14>(sext_ln703_189_fu_137534_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_272_fu_118365_p2() {
    add_ln703_272_fu_118365_p2 = (!grp_fu_116047_p4.read().is_01() || !zext_ln708_260_fu_117621_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_116047_p4.read()) + sc_biguint<9>(zext_ln708_260_fu_117621_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_273_fu_118375_p2() {
    add_ln703_273_fu_118375_p2 = (!sext_ln708_12_fu_117639_p1.read().is_01() || !zext_ln703_47_fu_118371_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_12_fu_117639_p1.read()) + sc_biguint<12>(zext_ln703_47_fu_118371_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_274_fu_137546_p2() {
    add_ln703_274_fu_137546_p2 = (!add_ln703_271_fu_137537_p2.read().is_01() || !sext_ln703_190_fu_137543_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_271_fu_137537_p2.read()) + sc_bigint<14>(sext_ln703_190_fu_137543_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_275_fu_131030_p2() {
    add_ln703_275_fu_131030_p2 = (!sext_ln708_13_fu_126134_p1.read().is_01() || !zext_ln708_261_fu_126138_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_13_fu_126134_p1.read()) + sc_biguint<11>(zext_ln708_261_fu_126138_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_276_fu_131040_p2() {
    add_ln703_276_fu_131040_p2 = (!zext_ln1116_38_fu_126067_p1.read().is_01() || !sext_ln703_192_fu_131036_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_38_fu_126067_p1.read()) + sc_bigint<12>(sext_ln703_192_fu_131036_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_277_fu_131050_p2() {
    add_ln703_277_fu_131050_p2 = (!sext_ln1118_90_fu_126178_p1.read().is_01() || !sext_ln1116_11_fu_126092_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_90_fu_126178_p1.read()) + sc_bigint<9>(sext_ln1116_11_fu_126092_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_278_fu_131060_p2() {
    add_ln703_278_fu_131060_p2 = (!sext_ln1116_10_fu_126070_p1.read().is_01() || !sext_ln703_194_fu_131056_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_10_fu_126070_p1.read()) + sc_bigint<10>(sext_ln703_194_fu_131056_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_279_fu_131070_p2() {
    add_ln703_279_fu_131070_p2 = (!sext_ln703_193_fu_131046_p1.read().is_01() || !sext_ln703_195_fu_131066_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_193_fu_131046_p1.read()) + sc_bigint<13>(sext_ln703_195_fu_131066_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_27_fu_136922_p2() {
    add_ln703_27_fu_136922_p2 = (!sext_ln203_3_fu_133761_p1.read().is_01() || !sext_ln203_2_fu_133668_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_3_fu_133761_p1.read()) + sc_bigint<11>(sext_ln203_2_fu_133668_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_280_fu_137559_p2() {
    add_ln703_280_fu_137559_p2 = (!sext_ln703_191_fu_137552_p1.read().is_01() || !sext_ln703_196_fu_137556_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_191_fu_137552_p1.read()) + sc_bigint<15>(sext_ln703_196_fu_137556_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_281_fu_137565_p2() {
    add_ln703_281_fu_137565_p2 = (!zext_ln203_14_fu_134672_p1.read().is_01() || !add_ln703_280_fu_137559_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_14_fu_134672_p1.read()) + sc_biguint<15>(add_ln703_280_fu_137559_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_282_fu_137571_p2() {
    add_ln703_282_fu_137571_p2 = (!sext_ln203_40_fu_134730_p1.read().is_01() || !zext_ln203_16_fu_134726_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_40_fu_134730_p1.read()) + sc_biguint<12>(zext_ln203_16_fu_134726_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_283_fu_137577_p2() {
    add_ln703_283_fu_137577_p2 = (!zext_ln203_15_fu_134707_p1.read().is_01() || !add_ln703_282_fu_137571_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_15_fu_134707_p1.read()) + sc_biguint<12>(add_ln703_282_fu_137571_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_285_fu_123087_p2() {
    add_ln703_285_fu_123087_p2 = (!zext_ln203_95_fu_119906_p1.read().is_01() || !ap_const_lv10_378.is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_95_fu_119906_p1.read()) + sc_bigint<10>(ap_const_lv10_378));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_286_fu_123097_p2() {
    add_ln703_286_fu_123097_p2 = (!sext_ln703_43_fu_123093_p1.read().is_01() || !zext_ln708_264_fu_119936_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_43_fu_123093_p1.read()) + sc_biguint<11>(zext_ln708_264_fu_119936_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_287_fu_123107_p2() {
    add_ln703_287_fu_123107_p2 = (!zext_ln203_17_fu_119967_p1.read().is_01() || !sext_ln703_44_fu_123103_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_17_fu_119967_p1.read()) + sc_bigint<12>(sext_ln703_44_fu_123103_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_288_fu_123113_p2() {
    add_ln703_288_fu_123113_p2 = (!zext_ln1118_580_fu_120023_p1.read().is_01() || !add_ln703_287_fu_123107_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_580_fu_120023_p1.read()) + sc_biguint<12>(add_ln703_287_fu_123107_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_289_fu_123119_p2() {
    add_ln703_289_fu_123119_p2 = (!sext_ln1118_93_fu_120019_p1.read().is_01() || !sext_ln1118_92_fu_119995_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_93_fu_120019_p1.read()) + sc_bigint<11>(sext_ln1118_92_fu_119995_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_28_fu_136932_p2() {
    add_ln703_28_fu_136932_p2 = (!zext_ln203_1_fu_133898_p1.read().is_01() || !sext_ln703_26_fu_136928_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_1_fu_133898_p1.read()) + sc_bigint<12>(sext_ln703_26_fu_136928_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_290_fu_123129_p2() {
    add_ln703_290_fu_123129_p2 = (!add_ln703_288_fu_123113_p2.read().is_01() || !sext_ln703_199_fu_123125_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_288_fu_123113_p2.read()) + sc_bigint<12>(sext_ln703_199_fu_123125_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_291_fu_123139_p2() {
    add_ln703_291_fu_123139_p2 = (!sext_ln1118_94_fu_120054_p1.read().is_01() || !sext_ln703_200_fu_123135_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_94_fu_120054_p1.read()) + sc_bigint<13>(sext_ln703_200_fu_123135_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_292_fu_123145_p2() {
    add_ln703_292_fu_123145_p2 = (!zext_ln1118_582_fu_120085_p1.read().is_01() || !sext_ln1118_96_fu_120092_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_582_fu_120085_p1.read()) + sc_bigint<12>(sext_ln1118_96_fu_120092_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_293_fu_123155_p2() {
    add_ln703_293_fu_123155_p2 = (!add_ln703_291_fu_123139_p2.read().is_01() || !sext_ln703_201_fu_123151_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_291_fu_123139_p2.read()) + sc_bigint<13>(sext_ln703_201_fu_123151_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_294_fu_131079_p2() {
    add_ln703_294_fu_131079_p2 = (!zext_ln1118_583_fu_126213_p1.read().is_01() || !trunc_ln1118_25_fu_126203_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_583_fu_126213_p1.read()) + sc_biguint<10>(trunc_ln1118_25_fu_126203_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_295_fu_118381_p2() {
    add_ln703_295_fu_118381_p2 = (!sext_ln1118_95_fu_117653_p1.read().is_01() || !zext_ln708_265_fu_117657_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_95_fu_117653_p1.read()) + sc_biguint<11>(zext_ln708_265_fu_117657_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_296_fu_131092_p2() {
    add_ln703_296_fu_131092_p2 = (!zext_ln703_48_fu_131085_p1.read().is_01() || !sext_ln703_203_fu_131089_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_48_fu_131085_p1.read()) + sc_bigint<12>(sext_ln703_203_fu_131089_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_297_fu_131102_p2() {
    add_ln703_297_fu_131102_p2 = (!sext_ln703_202_fu_131076_p1.read().is_01() || !sext_ln703_204_fu_131098_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_202_fu_131076_p1.read()) + sc_bigint<14>(sext_ln703_204_fu_131098_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_298_fu_118387_p2() {
    add_ln703_298_fu_118387_p2 = (!sext_ln1118_100_fu_117689_p1.read().is_01() || !sext_ln708_15_fu_117671_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_100_fu_117689_p1.read()) + sc_bigint<12>(sext_ln708_15_fu_117671_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_299_fu_131111_p2() {
    add_ln703_299_fu_131111_p2 = (!add_ln703_297_fu_131102_p2.read().is_01() || !sext_ln703_205_fu_131108_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_297_fu_131102_p2.read()) + sc_bigint<14>(sext_ln703_205_fu_131108_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_29_fu_136938_p2() {
    add_ln703_29_fu_136938_p2 = (!zext_ln703_7_fu_136918_p1.read().is_01() || !add_ln703_28_fu_136932_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_7_fu_136918_p1.read()) + sc_biguint<12>(add_ln703_28_fu_136932_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_2_fu_122511_p2() {
    add_ln703_2_fu_122511_p2 = (!sext_ln1118_fu_118489_p1.read().is_01() || !sext_ln1116_fu_118477_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_fu_118489_p1.read()) + sc_bigint<10>(sext_ln1116_fu_118477_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_300_fu_131121_p2() {
    add_ln703_300_fu_131121_p2 = (!zext_ln708_269_fu_126326_p1.read().is_01() || !zext_ln708_267_fu_126285_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_269_fu_126326_p1.read()) + sc_biguint<11>(zext_ln708_267_fu_126285_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_301_fu_131127_p2() {
    add_ln703_301_fu_131127_p2 = (!zext_ln708_266_fu_126266_p1.read().is_01() || !add_ln703_300_fu_131121_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_266_fu_126266_p1.read()) + sc_biguint<11>(add_ln703_300_fu_131121_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_302_fu_131137_p2() {
    add_ln703_302_fu_131137_p2 = (!sext_ln703_206_fu_131117_p1.read().is_01() || !zext_ln703_49_fu_131133_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_206_fu_131117_p1.read()) + sc_biguint<15>(zext_ln703_49_fu_131133_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_303_fu_118393_p2() {
    add_ln703_303_fu_118393_p2 = (!grp_fu_116147_p4.read().is_01() || !zext_ln1118_589_fu_117685_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_116147_p4.read()) + sc_biguint<10>(zext_ln1118_589_fu_117685_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_304_fu_131146_p2() {
    add_ln703_304_fu_131146_p2 = (!zext_ln708_270_fu_126345_p1.read().is_01() || !zext_ln703_50_fu_131143_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_270_fu_126345_p1.read()) + sc_biguint<11>(zext_ln703_50_fu_131143_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_305_fu_131156_p2() {
    add_ln703_305_fu_131156_p2 = (!sext_ln1118_35_reg_141911.read().is_01() || !sext_ln1118_98_fu_126243_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_35_reg_141911.read()) + sc_bigint<11>(sext_ln1118_98_fu_126243_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_306_fu_131165_p2() {
    add_ln703_306_fu_131165_p2 = (!zext_ln1118_586_fu_126292_p1.read().is_01() || !sext_ln1118_99_fu_126349_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_586_fu_126292_p1.read()) + sc_bigint<10>(sext_ln1118_99_fu_126349_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_307_fu_131175_p2() {
    add_ln703_307_fu_131175_p2 = (!sext_ln703_207_fu_131161_p1.read().is_01() || !sext_ln703_208_fu_131171_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_207_fu_131161_p1.read()) + sc_bigint<12>(sext_ln703_208_fu_131171_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_308_fu_131185_p2() {
    add_ln703_308_fu_131185_p2 = (!zext_ln703_51_fu_131152_p1.read().is_01() || !sext_ln703_209_fu_131181_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_51_fu_131152_p1.read()) + sc_bigint<13>(sext_ln703_209_fu_131181_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_309_fu_137600_p2() {
    add_ln703_309_fu_137600_p2 = (!add_ln703_302_reg_142923.read().is_01() || !sext_ln703_210_fu_137597_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_302_reg_142923.read()) + sc_bigint<15>(sext_ln703_210_fu_137597_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_310_fu_137605_p2() {
    add_ln703_310_fu_137605_p2 = (!sext_ln203_41_fu_134734_p1.read().is_01() || !add_ln703_309_fu_137600_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_41_fu_134734_p1.read()) + sc_biguint<15>(add_ln703_309_fu_137600_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_311_fu_137611_p2() {
    add_ln703_311_fu_137611_p2 = (!zext_ln203_18_fu_134758_p1.read().is_01() || !sext_ln203_42_fu_134789_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_18_fu_134758_p1.read()) + sc_bigint<12>(sext_ln203_42_fu_134789_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_312_fu_137621_p2() {
    add_ln703_312_fu_137621_p2 = (!add_ln703_310_fu_137605_p2.read().is_01() || !sext_ln703_211_fu_137617_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_310_fu_137605_p2.read()) + sc_bigint<15>(sext_ln703_211_fu_137617_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_313_fu_137627_p2() {
    add_ln703_313_fu_137627_p2 = (!zext_ln203_96_fu_134828_p1.read().is_01() || !trunc_ln203_14_fu_134798_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_96_fu_134828_p1.read()) + sc_biguint<10>(trunc_ln203_14_fu_134798_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_314_fu_137637_p2() {
    add_ln703_314_fu_137637_p2 = (!sext_ln203_43_fu_134824_p1.read().is_01() || !zext_ln708_271_fu_134848_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_43_fu_134824_p1.read()) + sc_biguint<11>(zext_ln708_271_fu_134848_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_315_fu_137647_p2() {
    add_ln703_315_fu_137647_p2 = (!zext_ln703_52_fu_137633_p1.read().is_01() || !sext_ln703_212_fu_137643_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_52_fu_137633_p1.read()) + sc_bigint<12>(sext_ln703_212_fu_137643_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_317_fu_123161_p2() {
    add_ln703_317_fu_123161_p2 = (!sext_ln203_44_fu_120110_p1.read().is_01() || !ap_const_lv12_E80.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_44_fu_120110_p1.read()) + sc_bigint<12>(ap_const_lv12_E80));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_318_fu_123171_p2() {
    add_ln703_318_fu_123171_p2 = (!zext_ln708_79_fu_120157_p1.read().is_01() || !sext_ln1118_102_fu_120133_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_79_fu_120157_p1.read()) + sc_bigint<12>(sext_ln1118_102_fu_120133_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_319_fu_123181_p2() {
    add_ln703_319_fu_123181_p2 = (!sext_ln703_49_fu_123167_p1.read().is_01() || !sext_ln703_215_fu_123177_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_49_fu_123167_p1.read()) + sc_bigint<13>(sext_ln703_215_fu_123177_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_31_fu_118047_p2() {
    add_ln703_31_fu_118047_p2 = (!trunc_ln7_fu_117068_p4.read().is_01() || !ap_const_lv9_110.is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln7_fu_117068_p4.read()) + sc_bigint<9>(ap_const_lv9_110));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_320_fu_123187_p2() {
    add_ln703_320_fu_123187_p2 = (!zext_ln1118_362_fu_119320_p1.read().is_01() || !sext_ln1118_101_fu_120129_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_362_fu_119320_p1.read()) + sc_bigint<10>(sext_ln1118_101_fu_120129_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_321_fu_123197_p2() {
    add_ln703_321_fu_123197_p2 = (!zext_ln1118_592_fu_120161_p1.read().is_01() || !sext_ln703_216_fu_123193_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_592_fu_120161_p1.read()) + sc_bigint<12>(sext_ln703_216_fu_123193_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_322_fu_123207_p2() {
    add_ln703_322_fu_123207_p2 = (!add_ln703_319_fu_123181_p2.read().is_01() || !sext_ln703_217_fu_123203_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_319_fu_123181_p2.read()) + sc_bigint<13>(sext_ln703_217_fu_123203_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_323_fu_123213_p2() {
    add_ln703_323_fu_123213_p2 = (!zext_ln708_81_fu_120165_p1.read().is_01() || !add_ln703_322_fu_123207_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln708_81_fu_120165_p1.read()) + sc_biguint<13>(add_ln703_322_fu_123207_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_324_fu_131194_p2() {
    add_ln703_324_fu_131194_p2 = (!zext_ln708_273_fu_126420_p1.read().is_01() || !zext_ln1118_596_fu_126385_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_273_fu_126420_p1.read()) + sc_biguint<10>(zext_ln1118_596_fu_126385_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_325_fu_131200_p2() {
    add_ln703_325_fu_131200_p2 = (!zext_ln1118_595_fu_126381_p1.read().is_01() || !add_ln703_324_fu_131194_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_595_fu_126381_p1.read()) + sc_biguint<10>(add_ln703_324_fu_131194_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_326_fu_131210_p2() {
    add_ln703_326_fu_131210_p2 = (!sext_ln703_218_fu_131191_p1.read().is_01() || !zext_ln703_53_fu_131206_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_218_fu_131191_p1.read()) + sc_biguint<14>(zext_ln703_53_fu_131206_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_327_fu_131216_p2() {
    add_ln703_327_fu_131216_p2 = (!zext_ln1118_599_fu_126443_p1.read().is_01() || !trunc_ln1118_27_reg_142014.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_599_fu_126443_p1.read()) + sc_biguint<10>(trunc_ln1118_27_reg_142014.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_328_fu_131225_p2() {
    add_ln703_328_fu_131225_p2 = (!zext_ln1118_593_fu_126352_p1.read().is_01() || !sext_ln1118_103_fu_126416_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_593_fu_126352_p1.read()) + sc_bigint<10>(sext_ln1118_103_fu_126416_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_329_fu_131231_p2() {
    add_ln703_329_fu_131231_p2 = (!zext_ln203_97_fu_126470_p1.read().is_01() || !add_ln703_328_fu_131225_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_97_fu_126470_p1.read()) + sc_biguint<10>(add_ln703_328_fu_131225_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_32_fu_118057_p2() {
    add_ln703_32_fu_118057_p2 = (!sext_ln703_9_fu_118053_p1.read().is_01() || !sext_ln203_4_fu_117078_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_9_fu_118053_p1.read()) + sc_bigint<12>(sext_ln203_4_fu_117078_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_330_fu_131241_p2() {
    add_ln703_330_fu_131241_p2 = (!zext_ln703_54_fu_131221_p1.read().is_01() || !sext_ln703_219_fu_131237_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_54_fu_131221_p1.read()) + sc_bigint<12>(sext_ln703_219_fu_131237_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_331_fu_131251_p2() {
    add_ln703_331_fu_131251_p2 = (!add_ln703_326_fu_131210_p2.read().is_01() || !sext_ln703_220_fu_131247_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_326_fu_131210_p2.read()) + sc_bigint<14>(sext_ln703_220_fu_131247_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_332_fu_131257_p2() {
    add_ln703_332_fu_131257_p2 = (!sext_ln1118_104_fu_126474_p1.read().is_01() || !add_ln703_331_fu_131251_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_104_fu_126474_p1.read()) + sc_biguint<14>(add_ln703_331_fu_131251_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_333_fu_131263_p2() {
    add_ln703_333_fu_131263_p2 = (!zext_ln1118_600_fu_126505_p1.read().is_01() || !sext_ln1118_105_fu_126556_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_600_fu_126505_p1.read()) + sc_bigint<12>(sext_ln1118_105_fu_126556_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_334_fu_131273_p2() {
    add_ln703_334_fu_131273_p2 = (!add_ln703_332_fu_131257_p2.read().is_01() || !sext_ln703_221_fu_131269_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_332_fu_131257_p2.read()) + sc_bigint<14>(sext_ln703_221_fu_131269_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_335_fu_131279_p2() {
    add_ln703_335_fu_131279_p2 = (!zext_ln1118_604_fu_126587_p1.read().is_01() || !trunc_ln1118_28_fu_126519_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_604_fu_126587_p1.read()) + sc_biguint<9>(trunc_ln1118_28_fu_126519_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_336_fu_123219_p2() {
    add_ln703_336_fu_123219_p2 = (!grp_fu_116207_p4.read().is_01() || !zext_ln1118_607_fu_120205_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_116207_p4.read()) + sc_biguint<9>(zext_ln1118_607_fu_120205_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_337_fu_131292_p2() {
    add_ln703_337_fu_131292_p2 = (!zext_ln703_55_fu_131285_p1.read().is_01() || !zext_ln703_56_fu_131289_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln703_55_fu_131285_p1.read()) + sc_biguint<10>(zext_ln703_56_fu_131289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_338_fu_137673_p2() {
    add_ln703_338_fu_137673_p2 = (!sext_ln703_222_fu_137667_p1.read().is_01() || !zext_ln703_57_fu_137670_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_222_fu_137667_p1.read()) + sc_biguint<15>(zext_ln703_57_fu_137670_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_339_fu_137679_p2() {
    add_ln703_339_fu_137679_p2 = (!zext_ln708_276_fu_134885_p1.read().is_01() || !zext_ln708_275_fu_134852_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_276_fu_134885_p1.read()) + sc_biguint<11>(zext_ln708_275_fu_134852_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_33_fu_122592_p2() {
    add_ln703_33_fu_122592_p2 = (!zext_ln1118_225_fu_118741_p1.read().is_01() || !sext_ln1118_4_fu_118704_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_225_fu_118741_p1.read()) + sc_bigint<12>(sext_ln1118_4_fu_118704_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_340_fu_137685_p2() {
    add_ln703_340_fu_137685_p2 = (!zext_ln1118_613_fu_134919_p1.read().is_01() || !zext_ln1118_611_fu_134889_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_613_fu_134919_p1.read()) + sc_biguint<10>(zext_ln1118_611_fu_134889_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_341_fu_137695_p2() {
    add_ln703_341_fu_137695_p2 = (!add_ln703_339_fu_137679_p2.read().is_01() || !zext_ln703_58_fu_137691_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_339_fu_137679_p2.read()) + sc_biguint<11>(zext_ln703_58_fu_137691_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_342_fu_123225_p2() {
    add_ln703_342_fu_123225_p2 = (!sext_ln1118_111_fu_120223_p1.read().is_01() || !sext_ln1118_110_fu_120219_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_111_fu_120223_p1.read()) + sc_bigint<11>(sext_ln1118_110_fu_120219_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_343_fu_131301_p2() {
    add_ln703_343_fu_131301_p2 = (!sext_ln1118_107_fu_126628_p1.read().is_01() || !sext_ln1118_109_fu_126675_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_107_fu_126628_p1.read()) + sc_bigint<10>(sext_ln1118_109_fu_126675_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_344_fu_131311_p2() {
    add_ln703_344_fu_131311_p2 = (!sext_ln703_223_fu_131298_p1.read().is_01() || !sext_ln703_224_fu_131307_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_223_fu_131298_p1.read()) + sc_bigint<12>(sext_ln703_224_fu_131307_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_345_fu_137708_p2() {
    add_ln703_345_fu_137708_p2 = (!zext_ln703_59_fu_137701_p1.read().is_01() || !sext_ln703_225_fu_137705_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_59_fu_137701_p1.read()) + sc_bigint<13>(sext_ln703_225_fu_137705_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_346_fu_137718_p2() {
    add_ln703_346_fu_137718_p2 = (!add_ln703_338_fu_137673_p2.read().is_01() || !sext_ln703_226_fu_137714_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_338_fu_137673_p2.read()) + sc_bigint<15>(sext_ln703_226_fu_137714_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_347_fu_137724_p2() {
    add_ln703_347_fu_137724_p2 = (!sext_ln203_46_fu_134958_p1.read().is_01() || !sext_ln203_45_fu_134938_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_46_fu_134958_p1.read()) + sc_bigint<12>(sext_ln203_45_fu_134938_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_349_fu_123231_p2() {
    add_ln703_349_fu_123231_p2 = (!sext_ln203_47_fu_120227_p1.read().is_01() || !ap_const_lv12_F40.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_47_fu_120227_p1.read()) + sc_bigint<12>(ap_const_lv12_F40));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_34_fu_122602_p2() {
    add_ln703_34_fu_122602_p2 = (!sext_ln703_10_fu_122589_p1.read().is_01() || !sext_ln703_29_fu_122598_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_10_fu_122589_p1.read()) + sc_bigint<13>(sext_ln703_29_fu_122598_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_350_fu_123237_p2() {
    add_ln703_350_fu_123237_p2 = (!zext_ln1118_616_fu_120266_p1.read().is_01() || !add_ln703_349_fu_123231_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_616_fu_120266_p1.read()) + sc_biguint<12>(add_ln703_349_fu_123231_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_351_fu_123243_p2() {
    add_ln703_351_fu_123243_p2 = (!sext_ln1118_113_fu_120290_p1.read().is_01() || !sext_ln1118_112_fu_120262_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_113_fu_120290_p1.read()) + sc_bigint<11>(sext_ln1118_112_fu_120262_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_352_fu_123249_p2() {
    add_ln703_352_fu_123249_p2 = (!zext_ln708_277_fu_120321_p1.read().is_01() || !add_ln703_351_fu_123243_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_277_fu_120321_p1.read()) + sc_biguint<11>(add_ln703_351_fu_123243_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_353_fu_123259_p2() {
    add_ln703_353_fu_123259_p2 = (!add_ln703_350_fu_123237_p2.read().is_01() || !sext_ln703_229_fu_123255_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_350_fu_123237_p2.read()) + sc_bigint<12>(sext_ln703_229_fu_123255_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_354_fu_123269_p2() {
    add_ln703_354_fu_123269_p2 = (!sext_ln708_16_fu_120349_p1.read().is_01() || !sext_ln1118_115_fu_120345_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_16_fu_120349_p1.read()) + sc_bigint<12>(sext_ln1118_115_fu_120345_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_355_fu_123279_p2() {
    add_ln703_355_fu_123279_p2 = (!sext_ln703_230_fu_123265_p1.read().is_01() || !sext_ln703_231_fu_123275_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_230_fu_123265_p1.read()) + sc_bigint<13>(sext_ln703_231_fu_123275_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_356_fu_131320_p2() {
    add_ln703_356_fu_131320_p2 = (!zext_ln1118_620_fu_126708_p1.read().is_01() || !zext_ln1118_619_fu_126679_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln1118_620_fu_126708_p1.read()) + sc_biguint<8>(zext_ln1118_619_fu_126679_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_357_fu_123285_p2() {
    add_ln703_357_fu_123285_p2 = (!sext_ln1118_116_fu_120353_p1.read().is_01() || !sext_ln1118_114_fu_120325_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_116_fu_120353_p1.read()) + sc_bigint<10>(sext_ln1118_114_fu_120325_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_358_fu_131333_p2() {
    add_ln703_358_fu_131333_p2 = (!zext_ln703_60_fu_131326_p1.read().is_01() || !sext_ln703_233_fu_131330_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_60_fu_131326_p1.read()) + sc_bigint<11>(sext_ln703_233_fu_131330_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_359_fu_131343_p2() {
    add_ln703_359_fu_131343_p2 = (!sext_ln703_232_fu_131317_p1.read().is_01() || !sext_ln703_234_fu_131339_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_232_fu_131317_p1.read()) + sc_bigint<14>(sext_ln703_234_fu_131339_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_35_fu_122608_p2() {
    add_ln703_35_fu_122608_p2 = (!sext_ln1118_5_fu_118803_p1.read().is_01() || !zext_ln1118_533_fu_118841_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_5_fu_118803_p1.read()) + sc_biguint<10>(zext_ln1118_533_fu_118841_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_360_fu_123291_p2() {
    add_ln703_360_fu_123291_p2 = (!zext_ln708_84_fu_120367_p1.read().is_01() || !sext_ln1118_122_fu_120398_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_84_fu_120367_p1.read()) + sc_bigint<12>(sext_ln1118_122_fu_120398_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_361_fu_131352_p2() {
    add_ln703_361_fu_131352_p2 = (!add_ln703_359_fu_131343_p2.read().is_01() || !sext_ln703_235_fu_131349_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_359_fu_131343_p2.read()) + sc_bigint<14>(sext_ln703_235_fu_131349_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_362_fu_131358_p2() {
    add_ln703_362_fu_131358_p2 = (!trunc_ln708_1069_reg_142040.read().is_01() || !zext_ln1118_624_fu_126783_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln708_1069_reg_142040.read()) + sc_biguint<8>(zext_ln1118_624_fu_126783_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_363_fu_131367_p2() {
    add_ln703_363_fu_131367_p2 = (!sext_ln1118_98_fu_126243_p1.read().is_01() || !sext_ln1118_117_fu_126712_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_98_fu_126243_p1.read()) + sc_bigint<11>(sext_ln1118_117_fu_126712_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_364_fu_131377_p2() {
    add_ln703_364_fu_131377_p2 = (!zext_ln703_61_fu_131363_p1.read().is_01() || !sext_ln703_236_fu_131373_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_61_fu_131363_p1.read()) + sc_bigint<12>(sext_ln703_236_fu_131373_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_365_fu_131387_p2() {
    add_ln703_365_fu_131387_p2 = (!add_ln703_361_fu_131352_p2.read().is_01() || !sext_ln703_237_fu_131383_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_361_fu_131352_p2.read()) + sc_bigint<14>(sext_ln703_237_fu_131383_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_366_fu_131393_p2() {
    add_ln703_366_fu_131393_p2 = (!zext_ln1118_629_fu_126841_p1.read().is_01() || !sext_ln1118_119_fu_126760_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_629_fu_126841_p1.read()) + sc_bigint<11>(sext_ln1118_119_fu_126760_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_367_fu_131403_p2() {
    add_ln703_367_fu_131403_p2 = (!sext_ln708_17_fu_126821_p1.read().is_01() || !sext_ln1118_118_fu_126730_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_17_fu_126821_p1.read()) + sc_bigint<10>(sext_ln1118_118_fu_126730_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_368_fu_131413_p2() {
    add_ln703_368_fu_131413_p2 = (!sext_ln703_238_fu_131399_p1.read().is_01() || !sext_ln703_239_fu_131409_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_238_fu_131399_p1.read()) + sc_bigint<12>(sext_ln703_239_fu_131409_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_369_fu_118399_p2() {
    add_ln703_369_fu_118399_p2 = (!zext_ln1118_627_fu_117727_p1.read().is_01() || !zext_ln1118_621_fu_117713_p1.read().is_01())? sc_lv<5>(): (sc_biguint<5>(zext_ln1118_627_fu_117727_p1.read()) + sc_biguint<5>(zext_ln1118_621_fu_117713_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_36_fu_122618_p2() {
    add_ln703_36_fu_122618_p2 = (!zext_ln708_225_fu_118772_p1.read().is_01() || !sext_ln703_32_fu_122614_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_225_fu_118772_p1.read()) + sc_bigint<11>(sext_ln703_32_fu_122614_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_370_fu_118409_p2() {
    add_ln703_370_fu_118409_p2 = (!sext_ln1118_121_fu_117747_p1.read().is_01() || !zext_ln708_278_fu_117761_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_121_fu_117747_p1.read()) + sc_biguint<7>(zext_ln708_278_fu_117761_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_371_fu_118415_p2() {
    add_ln703_371_fu_118415_p2 = (!zext_ln703_62_fu_118405_p1.read().is_01() || !add_ln703_370_fu_118409_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln703_62_fu_118405_p1.read()) + sc_biguint<7>(add_ln703_370_fu_118409_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_372_fu_131422_p2() {
    add_ln703_372_fu_131422_p2 = (!add_ln703_368_fu_131413_p2.read().is_01() || !sext_ln703_240_fu_131419_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_368_fu_131413_p2.read()) + sc_bigint<12>(sext_ln703_240_fu_131419_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_373_fu_131432_p2() {
    add_ln703_373_fu_131432_p2 = (!add_ln703_365_fu_131387_p2.read().is_01() || !sext_ln703_241_fu_131428_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_365_fu_131387_p2.read()) + sc_bigint<14>(sext_ln703_241_fu_131428_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_374_fu_137747_p2() {
    add_ln703_374_fu_137747_p2 = (!zext_ln203_19_fu_135032_p1.read().is_01() || !sext_ln203_50_fu_135039_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln203_19_fu_135032_p1.read()) + sc_bigint<11>(sext_ln203_50_fu_135039_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_375_fu_137757_p2() {
    add_ln703_375_fu_137757_p2 = (!sext_ln703_242_fu_137744_p1.read().is_01() || !sext_ln703_243_fu_137753_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_242_fu_137744_p1.read()) + sc_bigint<15>(sext_ln703_243_fu_137753_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_376_fu_137763_p2() {
    add_ln703_376_fu_137763_p2 = (!sext_ln203_48_fu_134988_p1.read().is_01() || !sext_ln203_51_fu_135061_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_48_fu_134988_p1.read()) + sc_bigint<10>(sext_ln203_51_fu_135061_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_377_fu_137773_p2() {
    add_ln703_377_fu_137773_p2 = (!zext_ln203_20_fu_135036_p1.read().is_01() || !sext_ln203_49_fu_135012_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_20_fu_135036_p1.read()) + sc_bigint<9>(sext_ln203_49_fu_135012_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_378_fu_137783_p2() {
    add_ln703_378_fu_137783_p2 = (!sext_ln703_244_fu_137769_p1.read().is_01() || !sext_ln703_245_fu_137779_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_244_fu_137769_p1.read()) + sc_bigint<11>(sext_ln703_245_fu_137779_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_37_fu_122628_p2() {
    add_ln703_37_fu_122628_p2 = (!add_ln703_34_fu_122602_p2.read().is_01() || !sext_ln703_33_fu_122624_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_34_fu_122602_p2.read()) + sc_bigint<13>(sext_ln703_33_fu_122624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_380_fu_123297_p2() {
    add_ln703_380_fu_123297_p2 = (!zext_ln203_98_fu_120402_p1.read().is_01() || !ap_const_lv9_148.is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_98_fu_120402_p1.read()) + sc_bigint<9>(ap_const_lv9_148));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_381_fu_123307_p2() {
    add_ln703_381_fu_123307_p2 = (!zext_ln703_1_fu_123303_p1.read().is_01() || !sext_ln203_52_fu_120406_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_1_fu_123303_p1.read()) + sc_bigint<12>(sext_ln203_52_fu_120406_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_382_fu_123317_p2() {
    add_ln703_382_fu_123317_p2 = (!sext_ln1116_12_fu_120430_p1.read().is_01() || !sext_ln1118_125_fu_120410_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_12_fu_120430_p1.read()) + sc_bigint<12>(sext_ln1118_125_fu_120410_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_383_fu_123327_p2() {
    add_ln703_383_fu_123327_p2 = (!sext_ln703_57_fu_123313_p1.read().is_01() || !sext_ln703_248_fu_123323_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_57_fu_123313_p1.read()) + sc_bigint<13>(sext_ln703_248_fu_123323_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_384_fu_123333_p2() {
    add_ln703_384_fu_123333_p2 = (!sext_ln1118_126_fu_120447_p1.read().is_01() || !sext_ln1116_13_fu_120438_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_126_fu_120447_p1.read()) + sc_bigint<12>(sext_ln1116_13_fu_120438_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_385_fu_131444_p2() {
    add_ln703_385_fu_131444_p2 = (!sext_ln703_58_fu_131438_p1.read().is_01() || !sext_ln703_249_fu_131441_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_58_fu_131438_p1.read()) + sc_bigint<14>(sext_ln703_249_fu_131441_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_386_fu_123339_p2() {
    add_ln703_386_fu_123339_p2 = (!zext_ln1118_632_fu_120451_p1.read().is_01() || !sext_ln1118_127_fu_120479_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_632_fu_120451_p1.read()) + sc_bigint<12>(sext_ln1118_127_fu_120479_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_387_fu_123349_p2() {
    add_ln703_387_fu_123349_p2 = (!zext_ln1116_57_fu_120492_p1.read().is_01() || !zext_ln1118_635_fu_120483_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_57_fu_120492_p1.read()) + sc_biguint<10>(zext_ln1118_635_fu_120483_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_388_fu_123359_p2() {
    add_ln703_388_fu_123359_p2 = (!sext_ln703_250_fu_123345_p1.read().is_01() || !zext_ln703_63_fu_123355_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_250_fu_123345_p1.read()) + sc_biguint<13>(zext_ln703_63_fu_123355_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_389_fu_131453_p2() {
    add_ln703_389_fu_131453_p2 = (!add_ln703_385_fu_131444_p2.read().is_01() || !sext_ln703_251_fu_131450_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_385_fu_131444_p2.read()) + sc_bigint<14>(sext_ln703_251_fu_131450_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_38_fu_130347_p2() {
    add_ln703_38_fu_130347_p2 = (!zext_ln1118_236_fu_124554_p1.read().is_01() || !sext_ln1118_8_fu_124585_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_236_fu_124554_p1.read()) + sc_bigint<12>(sext_ln1118_8_fu_124585_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_390_fu_137806_p2() {
    add_ln703_390_fu_137806_p2 = (!sext_ln1116_14_fu_135078_p1.read().is_01() || !zext_ln1118_636_fu_135065_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_14_fu_135078_p1.read()) + sc_biguint<12>(zext_ln1118_636_fu_135065_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_391_fu_137816_p2() {
    add_ln703_391_fu_137816_p2 = (!sext_ln703_59_fu_137803_p1.read().is_01() || !sext_ln703_252_fu_137812_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_59_fu_137803_p1.read()) + sc_bigint<15>(sext_ln703_252_fu_137812_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_392_fu_123365_p2() {
    add_ln703_392_fu_123365_p2 = (!sext_ln1118_130_fu_120554_p1.read().is_01() || !sext_ln708_18_fu_120533_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_130_fu_120554_p1.read()) + sc_bigint<12>(sext_ln708_18_fu_120533_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_393_fu_123375_p2() {
    add_ln703_393_fu_123375_p2 = (!zext_ln1116_58_fu_120524_p1.read().is_01() || !grp_fu_115627_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1116_58_fu_120524_p1.read()) + sc_biguint<9>(grp_fu_115627_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_394_fu_123385_p2() {
    add_ln703_394_fu_123385_p2 = (!sext_ln703_253_fu_123371_p1.read().is_01() || !zext_ln703_64_fu_123381_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_253_fu_123371_p1.read()) + sc_biguint<13>(zext_ln703_64_fu_123381_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_395_fu_137825_p2() {
    add_ln703_395_fu_137825_p2 = (!add_ln703_391_fu_137816_p2.read().is_01() || !sext_ln703_254_fu_137822_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_391_fu_137816_p2.read()) + sc_bigint<15>(sext_ln703_254_fu_137822_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_396_fu_123391_p2() {
    add_ln703_396_fu_123391_p2 = (!zext_ln708_280_fu_120546_p1.read().is_01() || !zext_ln708_279_fu_120537_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_280_fu_120546_p1.read()) + sc_biguint<11>(zext_ln708_279_fu_120537_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_397_fu_123397_p2() {
    add_ln703_397_fu_123397_p2 = (!zext_ln1118_638_fu_120567_p1.read().is_01() || !zext_ln1116_59_fu_120558_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_638_fu_120567_p1.read()) + sc_biguint<10>(zext_ln1116_59_fu_120558_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_398_fu_123407_p2() {
    add_ln703_398_fu_123407_p2 = (!add_ln703_396_fu_123391_p2.read().is_01() || !zext_ln703_65_fu_123403_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_396_fu_123391_p2.read()) + sc_biguint<11>(zext_ln703_65_fu_123403_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_399_fu_123417_p2() {
    add_ln703_399_fu_123417_p2 = (!sext_ln1118_18_reg_141205.read().is_01() || !zext_ln708_281_fu_120570_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_18_reg_141205.read()) + sc_biguint<11>(zext_ln708_281_fu_120570_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_39_fu_130357_p2() {
    add_ln703_39_fu_130357_p2 = (!sext_ln703_11_fu_130344_p1.read().is_01() || !sext_ln703_34_fu_130353_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_11_fu_130344_p1.read()) + sc_bigint<14>(sext_ln703_34_fu_130353_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_3_fu_122521_p2() {
    add_ln703_3_fu_122521_p2 = (!add_ln703_1_fu_122505_p2.read().is_01() || !sext_ln703_fu_122517_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_1_fu_122505_p2.read()) + sc_bigint<12>(sext_ln703_fu_122517_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_400_fu_123426_p2() {
    add_ln703_400_fu_123426_p2 = (!zext_ln1118_639_fu_120574_p1.read().is_01() || !sext_ln1118_129_fu_120550_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_639_fu_120574_p1.read()) + sc_bigint<11>(sext_ln1118_129_fu_120550_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_401_fu_123436_p2() {
    add_ln703_401_fu_123436_p2 = (!sext_ln703_255_fu_123422_p1.read().is_01() || !sext_ln703_256_fu_123432_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_255_fu_123422_p1.read()) + sc_bigint<12>(sext_ln703_256_fu_123432_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_402_fu_123446_p2() {
    add_ln703_402_fu_123446_p2 = (!zext_ln703_66_fu_123413_p1.read().is_01() || !sext_ln703_257_fu_123442_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_66_fu_123413_p1.read()) + sc_bigint<13>(sext_ln703_257_fu_123442_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_403_fu_137834_p2() {
    add_ln703_403_fu_137834_p2 = (!add_ln703_395_fu_137825_p2.read().is_01() || !sext_ln703_258_fu_137831_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_395_fu_137825_p2.read()) + sc_bigint<15>(sext_ln703_258_fu_137831_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_404_fu_137840_p2() {
    add_ln703_404_fu_137840_p2 = (!sext_ln203_53_fu_135092_p1.read().is_01() || !add_ln703_403_fu_137834_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_53_fu_135092_p1.read()) + sc_biguint<15>(add_ln703_403_fu_137834_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_405_fu_137850_p2() {
    add_ln703_405_fu_137850_p2 = (!zext_ln203_21_fu_135122_p1.read().is_01() || !sext_ln203_54_fu_135149_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_21_fu_135122_p1.read()) + sc_bigint<12>(sext_ln203_54_fu_135149_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_406_fu_137860_p2() {
    add_ln703_406_fu_137860_p2 = (!sext_ln703_259_fu_137846_p1.read().is_01() || !sext_ln703_260_fu_137856_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_259_fu_137846_p1.read()) + sc_bigint<16>(sext_ln703_260_fu_137856_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_407_fu_137866_p2() {
    add_ln703_407_fu_137866_p2 = (!zext_ln708_283_fu_135140_p1.read().is_01() || !zext_ln708_282_fu_135126_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_283_fu_135140_p1.read()) + sc_biguint<11>(zext_ln708_282_fu_135126_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_408_fu_137876_p2() {
    add_ln703_408_fu_137876_p2 = (!sext_ln203_55_fu_135176_p1.read().is_01() || !zext_ln708_284_fu_135157_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_55_fu_135176_p1.read()) + sc_biguint<11>(zext_ln708_284_fu_135157_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_409_fu_137886_p2() {
    add_ln703_409_fu_137886_p2 = (!zext_ln203_22_fu_135153_p1.read().is_01() || !sext_ln703_261_fu_137882_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_22_fu_135153_p1.read()) + sc_bigint<12>(sext_ln703_261_fu_137882_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_40_fu_122634_p2() {
    add_ln703_40_fu_122634_p2 = (!trunc_ln1118_1_reg_141130.read().is_01() || !zext_ln708_226_fu_118908_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_1_reg_141130.read()) + sc_biguint<10>(zext_ln708_226_fu_118908_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_410_fu_137896_p2() {
    add_ln703_410_fu_137896_p2 = (!zext_ln703_67_fu_137872_p1.read().is_01() || !sext_ln703_262_fu_137892_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_67_fu_137872_p1.read()) + sc_bigint<13>(sext_ln703_262_fu_137892_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_412_fu_123452_p2() {
    add_ln703_412_fu_123452_p2 = (!zext_ln708_286_fu_120601_p1.read().is_01() || !ap_const_lv11_5D0.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_286_fu_120601_p1.read()) + sc_bigint<11>(ap_const_lv11_5D0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_413_fu_123458_p2() {
    add_ln703_413_fu_123458_p2 = (!zext_ln708_285_fu_120581_p1.read().is_01() || !add_ln703_412_fu_123452_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_285_fu_120581_p1.read()) + sc_biguint<11>(add_ln703_412_fu_123452_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_414_fu_123468_p2() {
    add_ln703_414_fu_123468_p2 = (!sext_ln203_56_fu_120639_p1.read().is_01() || !sext_ln703_61_fu_123464_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_56_fu_120639_p1.read()) + sc_bigint<12>(sext_ln703_61_fu_123464_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_415_fu_123474_p2() {
    add_ln703_415_fu_123474_p2 = (!zext_ln1118_642_fu_120658_p1.read().is_01() || !add_ln703_414_fu_123468_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_642_fu_120658_p1.read()) + sc_biguint<12>(add_ln703_414_fu_123468_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_416_fu_123484_p2() {
    add_ln703_416_fu_123484_p2 = (!sext_ln708_19_fu_120672_p1.read().is_01() || !zext_ln708_287_fu_120676_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_19_fu_120672_p1.read()) + sc_biguint<11>(zext_ln708_287_fu_120676_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_417_fu_123494_p2() {
    add_ln703_417_fu_123494_p2 = (!sext_ln703_264_fu_123480_p1.read().is_01() || !sext_ln703_265_fu_123490_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_264_fu_123480_p1.read()) + sc_bigint<13>(sext_ln703_265_fu_123490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_418_fu_123500_p2() {
    add_ln703_418_fu_123500_p2 = (!zext_ln708_91_fu_120714_p1.read().is_01() || !add_ln703_417_fu_123494_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln708_91_fu_120714_p1.read()) + sc_biguint<13>(add_ln703_417_fu_123494_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_419_fu_131462_p2() {
    add_ln703_419_fu_131462_p2 = (!sext_ln1118_133_fu_126931_p1.read().is_01() || !sext_ln1118_132_fu_126901_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_133_fu_126931_p1.read()) + sc_bigint<12>(sext_ln1118_132_fu_126901_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_41_fu_122643_p2() {
    add_ln703_41_fu_122643_p2 = (!sext_ln1118_7_fu_118882_p1.read().is_01() || !zext_ln708_227_fu_118912_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_7_fu_118882_p1.read()) + sc_biguint<11>(zext_ln708_227_fu_118912_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_420_fu_131472_p2() {
    add_ln703_420_fu_131472_p2 = (!sext_ln703_266_fu_131459_p1.read().is_01() || !sext_ln703_267_fu_131468_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_266_fu_131459_p1.read()) + sc_bigint<14>(sext_ln703_267_fu_131468_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_421_fu_131478_p2() {
    add_ln703_421_fu_131478_p2 = (!zext_ln1118_583_fu_126213_p1.read().is_01() || !zext_ln1118_646_fu_126897_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_583_fu_126213_p1.read()) + sc_biguint<10>(zext_ln1118_646_fu_126897_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_422_fu_131484_p2() {
    add_ln703_422_fu_131484_p2 = (!zext_ln1118_644_fu_126875_p1.read().is_01() || !trunc_ln1118_29_fu_126945_p4.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_644_fu_126875_p1.read()) + sc_biguint<9>(trunc_ln1118_29_fu_126945_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_423_fu_131494_p2() {
    add_ln703_423_fu_131494_p2 = (!add_ln703_421_fu_131478_p2.read().is_01() || !zext_ln703_68_fu_131490_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(add_ln703_421_fu_131478_p2.read()) + sc_biguint<10>(zext_ln703_68_fu_131490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_424_fu_131504_p2() {
    add_ln703_424_fu_131504_p2 = (!add_ln703_420_fu_131472_p2.read().is_01() || !zext_ln703_69_fu_131500_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_420_fu_131472_p2.read()) + sc_biguint<14>(zext_ln703_69_fu_131500_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_425_fu_131510_p2() {
    add_ln703_425_fu_131510_p2 = (!sext_ln1118_135_fu_127055_p1.read().is_01() || !sext_ln1118_134_fu_126986_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_135_fu_127055_p1.read()) + sc_bigint<12>(sext_ln1118_134_fu_126986_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_426_fu_131520_p2() {
    add_ln703_426_fu_131520_p2 = (!add_ln703_424_fu_131504_p2.read().is_01() || !sext_ln703_268_fu_131516_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_424_fu_131504_p2.read()) + sc_bigint<14>(sext_ln703_268_fu_131516_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_427_fu_131530_p2() {
    add_ln703_427_fu_131530_p2 = (!zext_ln708_288_fu_127012_p1.read().is_01() || !zext_ln708_267_fu_126285_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_288_fu_127012_p1.read()) + sc_biguint<11>(zext_ln708_267_fu_126285_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_428_fu_131540_p2() {
    add_ln703_428_fu_131540_p2 = (!zext_ln708_92_fu_126990_p1.read().is_01() || !zext_ln703_70_fu_131536_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_92_fu_126990_p1.read()) + sc_biguint<12>(zext_ln703_70_fu_131536_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_429_fu_131550_p2() {
    add_ln703_429_fu_131550_p2 = (!sext_ln703_269_fu_131526_p1.read().is_01() || !zext_ln703_71_fu_131546_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_269_fu_131526_p1.read()) + sc_biguint<15>(zext_ln703_71_fu_131546_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_42_fu_122653_p2() {
    add_ln703_42_fu_122653_p2 = (!zext_ln703_8_fu_122639_p1.read().is_01() || !sext_ln703_35_fu_122649_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_8_fu_122639_p1.read()) + sc_bigint<12>(sext_ln703_35_fu_122649_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_430_fu_123506_p2() {
    add_ln703_430_fu_123506_p2 = (!zext_ln1118_652_fu_120722_p1.read().is_01() || !zext_ln1118_651_fu_120718_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_652_fu_120722_p1.read()) + sc_biguint<10>(zext_ln1118_651_fu_120718_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_431_fu_131559_p2() {
    add_ln703_431_fu_131559_p2 = (!zext_ln708_289_fu_127051_p1.read().is_01() || !zext_ln703_72_fu_131556_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_289_fu_127051_p1.read()) + sc_biguint<11>(zext_ln703_72_fu_131556_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_432_fu_131569_p2() {
    add_ln703_432_fu_131569_p2 = (!zext_ln708_94_fu_127032_p1.read().is_01() || !sext_ln708_20_fu_127058_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_94_fu_127032_p1.read()) + sc_bigint<11>(sext_ln708_20_fu_127058_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_433_fu_131579_p2() {
    add_ln703_433_fu_131579_p2 = (!zext_ln1118_653_fu_127076_p1.read().is_01() || !sext_ln703_270_fu_131575_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_653_fu_127076_p1.read()) + sc_bigint<12>(sext_ln703_270_fu_131575_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_434_fu_131589_p2() {
    add_ln703_434_fu_131589_p2 = (!zext_ln703_73_fu_131565_p1.read().is_01() || !sext_ln703_271_fu_131585_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_73_fu_131565_p1.read()) + sc_bigint<13>(sext_ln703_271_fu_131585_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_435_fu_131599_p2() {
    add_ln703_435_fu_131599_p2 = (!add_ln703_429_fu_131550_p2.read().is_01() || !sext_ln703_272_fu_131595_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_429_fu_131550_p2.read()) + sc_bigint<15>(sext_ln703_272_fu_131595_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_436_fu_137912_p2() {
    add_ln703_436_fu_137912_p2 = (!sext_ln203_57_fu_135180_p1.read().is_01() || !add_ln703_435_reg_142958.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_57_fu_135180_p1.read()) + sc_biguint<15>(add_ln703_435_reg_142958.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_437_fu_137917_p2() {
    add_ln703_437_fu_137917_p2 = (!sext_ln203_59_fu_135251_p1.read().is_01() || !sext_ln203_58_fu_135204_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_59_fu_135251_p1.read()) + sc_bigint<12>(sext_ln203_58_fu_135204_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_438_fu_137927_p2() {
    add_ln703_438_fu_137927_p2 = (!add_ln703_436_fu_137912_p2.read().is_01() || !sext_ln703_273_fu_137923_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_436_fu_137912_p2.read()) + sc_bigint<15>(sext_ln703_273_fu_137923_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_439_fu_137937_p2() {
    add_ln703_439_fu_137937_p2 = (!zext_ln708_291_fu_135247_p1.read().is_01() || !zext_ln708_290_fu_135228_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_291_fu_135247_p1.read()) + sc_biguint<11>(zext_ln708_290_fu_135228_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_43_fu_130366_p2() {
    add_ln703_43_fu_130366_p2 = (!add_ln703_39_fu_130357_p2.read().is_01() || !sext_ln703_36_fu_130363_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_39_fu_130357_p2.read()) + sc_bigint<14>(sext_ln703_36_fu_130363_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_440_fu_137947_p2() {
    add_ln703_440_fu_137947_p2 = (!sext_ln203_60_fu_135255_p1.read().is_01() || !sext_ln203_61_fu_135282_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_60_fu_135255_p1.read()) + sc_bigint<10>(sext_ln203_61_fu_135282_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_441_fu_137957_p2() {
    add_ln703_441_fu_137957_p2 = (!zext_ln708_292_fu_135258_p1.read().is_01() || !sext_ln703_275_fu_137953_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_292_fu_135258_p1.read()) + sc_bigint<11>(sext_ln703_275_fu_137953_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_442_fu_137967_p2() {
    add_ln703_442_fu_137967_p2 = (!zext_ln703_74_fu_137943_p1.read().is_01() || !sext_ln703_276_fu_137963_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_74_fu_137943_p1.read()) + sc_bigint<13>(sext_ln703_276_fu_137963_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_444_fu_123512_p2() {
    add_ln703_444_fu_123512_p2 = (!zext_ln203_23_fu_120742_p1.read().is_01() || !sext_ln203_44_fu_120110_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_23_fu_120742_p1.read()) + sc_bigint<12>(sext_ln203_44_fu_120110_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_445_fu_123518_p2() {
    add_ln703_445_fu_123518_p2 = (!zext_ln1118_658_fu_120780_p1.read().is_01() || !ap_const_lv10_3B8.is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_658_fu_120780_p1.read()) + sc_bigint<10>(ap_const_lv10_3B8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_446_fu_123528_p2() {
    add_ln703_446_fu_123528_p2 = (!add_ln703_444_fu_123512_p2.read().is_01() || !sext_ln703_278_fu_123524_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_444_fu_123512_p2.read()) + sc_bigint<12>(sext_ln703_278_fu_123524_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_447_fu_123538_p2() {
    add_ln703_447_fu_123538_p2 = (!sext_ln203_62_fu_120834_p1.read().is_01() || !sext_ln703_66_fu_123534_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_62_fu_120834_p1.read()) + sc_bigint<13>(sext_ln703_66_fu_123534_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_448_fu_123544_p2() {
    add_ln703_448_fu_123544_p2 = (!sext_ln708_21_fu_120800_p1.read().is_01() || !zext_ln708_293_fu_120820_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_21_fu_120800_p1.read()) + sc_biguint<11>(zext_ln708_293_fu_120820_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_449_fu_123554_p2() {
    add_ln703_449_fu_123554_p2 = (!add_ln703_447_fu_123538_p2.read().is_01() || !sext_ln703_279_fu_123550_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_447_fu_123538_p2.read()) + sc_bigint<13>(sext_ln703_279_fu_123550_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_44_fu_130372_p2() {
    add_ln703_44_fu_130372_p2 = (!sext_ln708_2_fu_124589_p1.read().is_01() || !add_ln703_43_fu_130366_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln708_2_fu_124589_p1.read()) + sc_biguint<14>(add_ln703_43_fu_130366_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_450_fu_123564_p2() {
    add_ln703_450_fu_123564_p2 = (!zext_ln1118_659_fu_120858_p1.read().is_01() || !grp_fu_116327_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_659_fu_120858_p1.read()) + sc_biguint<10>(grp_fu_116327_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_451_fu_123574_p2() {
    add_ln703_451_fu_123574_p2 = (!sext_ln703_67_fu_123560_p1.read().is_01() || !zext_ln703_75_fu_123570_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_67_fu_123560_p1.read()) + sc_biguint<14>(zext_ln703_75_fu_123570_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_452_fu_123580_p2() {
    add_ln703_452_fu_123580_p2 = (!sext_ln708_22_fu_120862_p1.read().is_01() || !sext_ln1118_136_fu_120838_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_22_fu_120862_p1.read()) + sc_bigint<11>(sext_ln1118_136_fu_120838_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_453_fu_123590_p2() {
    add_ln703_453_fu_123590_p2 = (!zext_ln1118_660_fu_120866_p1.read().is_01() || !sext_ln703_280_fu_123586_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_660_fu_120866_p1.read()) + sc_bigint<12>(sext_ln703_280_fu_123586_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_454_fu_123600_p2() {
    add_ln703_454_fu_123600_p2 = (!add_ln703_451_fu_123574_p2.read().is_01() || !sext_ln703_281_fu_123596_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_451_fu_123574_p2.read()) + sc_bigint<14>(sext_ln703_281_fu_123596_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_455_fu_131608_p2() {
    add_ln703_455_fu_131608_p2 = (!sext_ln708_25_fu_127205_p1.read().is_01() || !sext_ln1118_137_fu_127114_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_25_fu_127205_p1.read()) + sc_bigint<12>(sext_ln1118_137_fu_127114_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_456_fu_131618_p2() {
    add_ln703_456_fu_131618_p2 = (!sext_ln703_68_fu_131605_p1.read().is_01() || !sext_ln703_282_fu_131614_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_68_fu_131605_p1.read()) + sc_bigint<15>(sext_ln703_282_fu_131614_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_457_fu_123606_p2() {
    add_ln703_457_fu_123606_p2 = (!zext_ln708_295_fu_120874_p1.read().is_01() || !zext_ln708_294_fu_120870_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_295_fu_120874_p1.read()) + sc_biguint<11>(zext_ln708_294_fu_120870_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_458_fu_123616_p2() {
    add_ln703_458_fu_123616_p2 = (!zext_ln708_297_fu_120882_p1.read().is_01() || !zext_ln708_296_fu_120878_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_297_fu_120882_p1.read()) + sc_biguint<11>(zext_ln708_296_fu_120878_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_459_fu_123626_p2() {
    add_ln703_459_fu_123626_p2 = (!zext_ln703_76_fu_123612_p1.read().is_01() || !zext_ln703_77_fu_123622_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_76_fu_123612_p1.read()) + sc_biguint<12>(zext_ln703_77_fu_123622_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_45_fu_130382_p2() {
    add_ln703_45_fu_130382_p2 = (!sext_ln1118_13_fu_124657_p1.read().is_01() || !sext_ln1118_12_fu_124653_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_13_fu_124657_p1.read()) + sc_bigint<12>(sext_ln1118_12_fu_124653_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_460_fu_131627_p2() {
    add_ln703_460_fu_131627_p2 = (!add_ln703_456_fu_131618_p2.read().is_01() || !zext_ln703_78_fu_131624_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_456_fu_131618_p2.read()) + sc_biguint<15>(zext_ln703_78_fu_131624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_461_fu_123632_p2() {
    add_ln703_461_fu_123632_p2 = (!zext_ln1118_666_fu_120900_p1.read().is_01() || !trunc_ln1118_31_fu_120890_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_666_fu_120900_p1.read()) + sc_biguint<10>(trunc_ln1118_31_fu_120890_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_462_fu_123642_p2() {
    add_ln703_462_fu_123642_p2 = (!zext_ln708_299_fu_120886_p1.read().is_01() || !zext_ln703_79_fu_123638_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_299_fu_120886_p1.read()) + sc_biguint<11>(zext_ln703_79_fu_123638_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_463_fu_131636_p2() {
    add_ln703_463_fu_131636_p2 = (!sext_ln708_23_fu_127110_p1.read().is_01() || !zext_ln708_298_fu_127142_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln708_23_fu_127110_p1.read()) + sc_biguint<8>(zext_ln708_298_fu_127142_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_464_fu_131646_p2() {
    add_ln703_464_fu_131646_p2 = (!sext_ln1118_138_fu_127165_p1.read().is_01() || !sext_ln708_24_fu_127138_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_138_fu_127165_p1.read()) + sc_bigint<7>(sext_ln708_24_fu_127138_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_465_fu_131656_p2() {
    add_ln703_465_fu_131656_p2 = (!sext_ln703_283_fu_131642_p1.read().is_01() || !sext_ln703_284_fu_131652_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln703_283_fu_131642_p1.read()) + sc_bigint<9>(sext_ln703_284_fu_131652_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_466_fu_131666_p2() {
    add_ln703_466_fu_131666_p2 = (!zext_ln703_80_fu_131633_p1.read().is_01() || !sext_ln703_285_fu_131662_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_80_fu_131633_p1.read()) + sc_bigint<12>(sext_ln703_285_fu_131662_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_467_fu_131676_p2() {
    add_ln703_467_fu_131676_p2 = (!add_ln703_460_fu_131627_p2.read().is_01() || !sext_ln703_286_fu_131672_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_460_fu_131627_p2.read()) + sc_bigint<15>(sext_ln703_286_fu_131672_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_468_fu_137983_p2() {
    add_ln703_468_fu_137983_p2 = (!sext_ln203_63_fu_135286_p1.read().is_01() || !add_ln703_467_reg_142963.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_63_fu_135286_p1.read()) + sc_biguint<15>(add_ln703_467_reg_142963.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_469_fu_137988_p2() {
    add_ln703_469_fu_137988_p2 = (!sext_ln203_68_fu_135377_p1.read().is_01() || !sext_ln203_65_fu_135345_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_68_fu_135377_p1.read()) + sc_bigint<12>(sext_ln203_65_fu_135345_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_46_fu_130392_p2() {
    add_ln703_46_fu_130392_p2 = (!sext_ln1118_11_fu_124622_p1.read().is_01() || !sext_ln703_38_fu_130388_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_11_fu_124622_p1.read()) + sc_bigint<13>(sext_ln703_38_fu_130388_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_470_fu_137998_p2() {
    add_ln703_470_fu_137998_p2 = (!add_ln703_468_fu_137983_p2.read().is_01() || !sext_ln703_287_fu_137994_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_468_fu_137983_p2.read()) + sc_bigint<15>(sext_ln703_287_fu_137994_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_471_fu_138008_p2() {
    add_ln703_471_fu_138008_p2 = (!sext_ln203_64_fu_135290_p1.read().is_01() || !zext_ln708_300_fu_135325_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_64_fu_135290_p1.read()) + sc_biguint<11>(zext_ln708_300_fu_135325_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_472_fu_138018_p2() {
    add_ln703_472_fu_138018_p2 = (!sext_ln203_66_fu_135369_p1.read().is_01() || !sext_ln203_69_fu_135381_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_66_fu_135369_p1.read()) + sc_bigint<11>(sext_ln203_69_fu_135381_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_473_fu_138028_p2() {
    add_ln703_473_fu_138028_p2 = (!sext_ln203_67_fu_135373_p1.read().is_01() || !sext_ln703_290_fu_138024_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_67_fu_135373_p1.read()) + sc_bigint<12>(sext_ln703_290_fu_138024_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_474_fu_138034_p2() {
    add_ln703_474_fu_138034_p2 = (!sext_ln703_289_fu_138014_p1.read().is_01() || !add_ln703_473_fu_138028_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_289_fu_138014_p1.read()) + sc_biguint<12>(add_ln703_473_fu_138028_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_476_fu_123648_p2() {
    add_ln703_476_fu_123648_p2 = (!sext_ln1118_140_fu_120904_p1.read().is_01() || !zext_ln708_301_fu_120908_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_140_fu_120904_p1.read()) + sc_biguint<11>(zext_ln708_301_fu_120908_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_477_fu_123658_p2() {
    add_ln703_477_fu_123658_p2 = (!sext_ln703_292_fu_123654_p1.read().is_01() || !ap_const_lv12_C08.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_292_fu_123654_p1.read()) + sc_bigint<12>(ap_const_lv12_C08));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_478_fu_123664_p2() {
    add_ln703_478_fu_123664_p2 = (!trunc_ln1118_32_fu_121023_p4.read().is_01() || !zext_ln1118_674_fu_120978_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_32_fu_121023_p4.read()) + sc_biguint<10>(zext_ln1118_674_fu_120978_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_479_fu_123674_p2() {
    add_ln703_479_fu_123674_p2 = (!add_ln703_477_fu_123658_p2.read().is_01() || !zext_ln703_81_fu_123670_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_477_fu_123658_p2.read()) + sc_biguint<12>(zext_ln703_81_fu_123670_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_47_fu_130402_p2() {
    add_ln703_47_fu_130402_p2 = (!sext_ln703_37_fu_130378_p1.read().is_01() || !sext_ln703_39_fu_130398_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_37_fu_130378_p1.read()) + sc_bigint<15>(sext_ln703_39_fu_130398_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_480_fu_123680_p2() {
    add_ln703_480_fu_123680_p2 = (!sext_ln1118_141_fu_120943_p1.read().is_01() || !zext_ln708_302_fu_121043_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_141_fu_120943_p1.read()) + sc_biguint<11>(zext_ln708_302_fu_121043_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_481_fu_123686_p2() {
    add_ln703_481_fu_123686_p2 = (!sext_ln708_26_fu_121002_p1.read().is_01() || !zext_ln708_105_fu_121006_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln708_26_fu_121002_p1.read()) + sc_biguint<9>(zext_ln708_105_fu_121006_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_482_fu_123696_p2() {
    add_ln703_482_fu_123696_p2 = (!add_ln703_480_fu_123680_p2.read().is_01() || !sext_ln703_293_fu_123692_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_480_fu_123680_p2.read()) + sc_bigint<11>(sext_ln703_293_fu_123692_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_483_fu_123706_p2() {
    add_ln703_483_fu_123706_p2 = (!add_ln703_479_fu_123674_p2.read().is_01() || !sext_ln703_294_fu_123702_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_479_fu_123674_p2.read()) + sc_bigint<12>(sext_ln703_294_fu_123702_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_484_fu_131685_p2() {
    add_ln703_484_fu_131685_p2 = (!zext_ln1118_676_fu_127227_p1.read().is_01() || !sext_ln1118_142_fu_127209_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_676_fu_127227_p1.read()) + sc_bigint<12>(sext_ln1118_142_fu_127209_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_485_fu_131695_p2() {
    add_ln703_485_fu_131695_p2 = (!sext_ln703_295_fu_131682_p1.read().is_01() || !sext_ln703_296_fu_131691_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_295_fu_131682_p1.read()) + sc_bigint<13>(sext_ln703_296_fu_131691_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_486_fu_123712_p2() {
    add_ln703_486_fu_123712_p2 = (!sext_ln1118_144_fu_121051_p1.read().is_01() || !sext_ln1118_143_fu_121047_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_144_fu_121051_p1.read()) + sc_bigint<10>(sext_ln1118_143_fu_121047_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_487_fu_123722_p2() {
    add_ln703_487_fu_123722_p2 = (!sext_ln1118_145_fu_121055_p1.read().is_01() || !sext_ln703_297_fu_123718_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_145_fu_121055_p1.read()) + sc_bigint<11>(sext_ln703_297_fu_123718_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_488_fu_131704_p2() {
    add_ln703_488_fu_131704_p2 = (!add_ln703_485_fu_131695_p2.read().is_01() || !sext_ln703_298_fu_131701_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_485_fu_131695_p2.read()) + sc_bigint<13>(sext_ln703_298_fu_131701_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_489_fu_131714_p2() {
    add_ln703_489_fu_131714_p2 = (!sext_ln1118_152_fu_127383_p1.read().is_01() || !sext_ln1118_150_fu_127332_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_152_fu_127383_p1.read()) + sc_bigint<12>(sext_ln1118_150_fu_127332_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_48_fu_118063_p2() {
    add_ln703_48_fu_118063_p2 = (!grp_fu_115267_p4.read().is_01() || !zext_ln1118_534_fu_117122_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115267_p4.read()) + sc_biguint<10>(zext_ln1118_534_fu_117122_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_490_fu_131724_p2() {
    add_ln703_490_fu_131724_p2 = (!sext_ln703_299_fu_131710_p1.read().is_01() || !sext_ln703_300_fu_131720_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_299_fu_131710_p1.read()) + sc_bigint<14>(sext_ln703_300_fu_131720_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_491_fu_131730_p2() {
    add_ln703_491_fu_131730_p2 = (!zext_ln708_303_fu_127352_p1.read().is_01() || !zext_ln1118_679_fu_127258_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_303_fu_127352_p1.read()) + sc_biguint<10>(zext_ln1118_679_fu_127258_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_492_fu_131736_p2() {
    add_ln703_492_fu_131736_p2 = (!zext_ln1118_678_fu_127255_p1.read().is_01() || !add_ln703_491_fu_131730_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_678_fu_127255_p1.read()) + sc_biguint<10>(add_ln703_491_fu_131730_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_493_fu_131746_p2() {
    add_ln703_493_fu_131746_p2 = (!add_ln703_490_fu_131724_p2.read().is_01() || !zext_ln703_82_fu_131742_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_490_fu_131724_p2.read()) + sc_biguint<14>(zext_ln703_82_fu_131742_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_494_fu_123728_p2() {
    add_ln703_494_fu_123728_p2 = (!sext_ln1118_153_fu_121077_p1.read().is_01() || !zext_ln1118_682_fu_121073_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_153_fu_121077_p1.read()) + sc_biguint<12>(zext_ln1118_682_fu_121073_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_495_fu_123734_p2() {
    add_ln703_495_fu_123734_p2 = (!zext_ln708_108_fu_121069_p1.read().is_01() || !add_ln703_494_fu_123728_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_108_fu_121069_p1.read()) + sc_biguint<12>(add_ln703_494_fu_123728_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_496_fu_131755_p2() {
    add_ln703_496_fu_131755_p2 = (!sext_ln1118_149_fu_127328_p1.read().is_01() || !sext_ln1118_148_fu_127297_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_149_fu_127328_p1.read()) + sc_bigint<9>(sext_ln1118_148_fu_127297_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_497_fu_131765_p2() {
    add_ln703_497_fu_131765_p2 = (!sext_ln1118_146_fu_127251_p1.read().is_01() || !sext_ln703_303_fu_131761_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_146_fu_127251_p1.read()) + sc_bigint<10>(sext_ln703_303_fu_131761_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_498_fu_131775_p2() {
    add_ln703_498_fu_131775_p2 = (!sext_ln703_302_fu_131752_p1.read().is_01() || !sext_ln703_304_fu_131771_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_302_fu_131752_p1.read()) + sc_bigint<13>(sext_ln703_304_fu_131771_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_499_fu_138056_p2() {
    add_ln703_499_fu_138056_p2 = (!sext_ln703_301_fu_138050_p1.read().is_01() || !sext_ln703_305_fu_138053_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_301_fu_138050_p1.read()) + sc_bigint<15>(sext_ln703_305_fu_138053_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_49_fu_118073_p2() {
    add_ln703_49_fu_118073_p2 = (!sext_ln1118_14_fu_117126_p1.read().is_01() || !zext_ln703_9_fu_118069_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_14_fu_117126_p1.read()) + sc_biguint<12>(zext_ln703_9_fu_118069_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_4_fu_122531_p2() {
    add_ln703_4_fu_122531_p2 = (!sext_ln1116_1_fu_118580_p1.read().is_01() || !sext_ln703_12_fu_122527_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1116_1_fu_118580_p1.read()) + sc_bigint<13>(sext_ln703_12_fu_122527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_500_fu_138062_p2() {
    add_ln703_500_fu_138062_p2 = (!zext_ln203_24_fu_135385_p1.read().is_01() || !add_ln703_499_fu_138056_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_24_fu_135385_p1.read()) + sc_biguint<15>(add_ln703_499_fu_138056_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_501_fu_138068_p2() {
    add_ln703_501_fu_138068_p2 = (!zext_ln203_25_fu_135420_p1.read().is_01() || !sext_ln203_71_fu_135450_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_25_fu_135420_p1.read()) + sc_bigint<12>(sext_ln203_71_fu_135450_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_502_fu_138078_p2() {
    add_ln703_502_fu_138078_p2 = (!add_ln703_500_fu_138062_p2.read().is_01() || !sext_ln703_306_fu_138074_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_500_fu_138062_p2.read()) + sc_bigint<15>(sext_ln703_306_fu_138074_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_503_fu_138084_p2() {
    add_ln703_503_fu_138084_p2 = (!zext_ln708_305_fu_135442_p1.read().is_01() || !zext_ln708_304_fu_135438_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_305_fu_135442_p1.read()) + sc_biguint<11>(zext_ln708_304_fu_135438_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_504_fu_131781_p2() {
    add_ln703_504_fu_131781_p2 = (!sext_ln203_72_fu_127417_p1.read().is_01() || !sext_ln203_70_fu_127413_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_72_fu_127417_p1.read()) + sc_bigint<11>(sext_ln203_70_fu_127413_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_505_fu_138097_p2() {
    add_ln703_505_fu_138097_p2 = (!zext_ln203_26_fu_135446_p1.read().is_01() || !sext_ln703_307_fu_138094_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_26_fu_135446_p1.read()) + sc_bigint<12>(sext_ln703_307_fu_138094_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_506_fu_138107_p2() {
    add_ln703_506_fu_138107_p2 = (!zext_ln703_83_fu_138090_p1.read().is_01() || !sext_ln703_308_fu_138103_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_83_fu_138090_p1.read()) + sc_bigint<13>(sext_ln703_308_fu_138103_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_508_fu_123740_p2() {
    add_ln703_508_fu_123740_p2 = (!sext_ln1118_140_fu_120904_p1.read().is_01() || !ap_const_lv11_748.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_140_fu_120904_p1.read()) + sc_bigint<11>(ap_const_lv11_748));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_509_fu_123746_p2() {
    add_ln703_509_fu_123746_p2 = (!zext_ln708_272_fu_120153_p1.read().is_01() || !add_ln703_508_fu_123740_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_272_fu_120153_p1.read()) + sc_biguint<11>(add_ln703_508_fu_123740_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_50_fu_118079_p2() {
    add_ln703_50_fu_118079_p2 = (!sext_ln1118_10_fu_117108_p1.read().is_01() || !sext_ln1118_9_fu_117104_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_10_fu_117108_p1.read()) + sc_bigint<10>(sext_ln1118_9_fu_117104_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_510_fu_123756_p2() {
    add_ln703_510_fu_123756_p2 = (!sext_ln1118_64_fu_119638_p1.read().is_01() || !sext_ln1116_17_fu_121084_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_64_fu_119638_p1.read()) + sc_bigint<10>(sext_ln1116_17_fu_121084_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_511_fu_123766_p2() {
    add_ln703_511_fu_123766_p2 = (!sext_ln703_311_fu_123752_p1.read().is_01() || !sext_ln703_312_fu_123762_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_311_fu_123752_p1.read()) + sc_bigint<12>(sext_ln703_312_fu_123762_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_512_fu_123772_p2() {
    add_ln703_512_fu_123772_p2 = (!zext_ln1118_686_fu_121096_p1.read().is_01() || !add_ln703_511_fu_123766_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_686_fu_121096_p1.read()) + sc_biguint<12>(add_ln703_511_fu_123766_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_513_fu_123778_p2() {
    add_ln703_513_fu_123778_p2 = (!zext_ln1118_688_fu_121104_p1.read().is_01() || !zext_ln1118_687_fu_121100_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_688_fu_121104_p1.read()) + sc_biguint<10>(zext_ln1118_687_fu_121100_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_514_fu_123788_p2() {
    add_ln703_514_fu_123788_p2 = (!add_ln703_512_fu_123772_p2.read().is_01() || !zext_ln703_84_fu_123784_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_512_fu_123772_p2.read()) + sc_biguint<12>(zext_ln703_84_fu_123784_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_515_fu_123794_p2() {
    add_ln703_515_fu_123794_p2 = (!sext_ln1118_155_fu_121092_p1.read().is_01() || !zext_ln708_306_fu_121127_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_155_fu_121092_p1.read()) + sc_biguint<11>(zext_ln708_306_fu_121127_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_516_fu_131793_p2() {
    add_ln703_516_fu_131793_p2 = (!sext_ln1116_18_fu_127444_p1.read().is_01() || !sext_ln1118_156_fu_127448_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_18_fu_127444_p1.read()) + sc_bigint<11>(sext_ln1118_156_fu_127448_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_517_fu_131803_p2() {
    add_ln703_517_fu_131803_p2 = (!sext_ln703_314_fu_131790_p1.read().is_01() || !sext_ln703_315_fu_131799_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_314_fu_131790_p1.read()) + sc_bigint<12>(sext_ln703_315_fu_131799_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_518_fu_131813_p2() {
    add_ln703_518_fu_131813_p2 = (!sext_ln703_313_fu_131787_p1.read().is_01() || !sext_ln703_316_fu_131809_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_313_fu_131787_p1.read()) + sc_bigint<13>(sext_ln703_316_fu_131809_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_519_fu_123800_p2() {
    add_ln703_519_fu_123800_p2 = (!sext_ln1116_20_fu_121146_p1.read().is_01() || !sext_ln708_27_fu_121131_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1116_20_fu_121146_p1.read()) + sc_bigint<12>(sext_ln708_27_fu_121131_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_51_fu_130414_p2() {
    add_ln703_51_fu_130414_p2 = (!zext_ln1118_244_fu_124618_p1.read().is_01() || !sext_ln703_41_fu_130411_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_244_fu_124618_p1.read()) + sc_bigint<11>(sext_ln703_41_fu_130411_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_520_fu_131826_p2() {
    add_ln703_520_fu_131826_p2 = (!sext_ln703_317_fu_131819_p1.read().is_01() || !sext_ln703_318_fu_131823_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_317_fu_131819_p1.read()) + sc_bigint<14>(sext_ln703_318_fu_131823_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_521_fu_123806_p2() {
    add_ln703_521_fu_123806_p2 = (!zext_ln1118_693_fu_121138_p1.read().is_01() || !sext_ln1116_23_fu_121162_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_693_fu_121138_p1.read()) + sc_bigint<12>(sext_ln1116_23_fu_121162_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_522_fu_123812_p2() {
    add_ln703_522_fu_123812_p2 = (!zext_ln1116_62_fu_121158_p1.read().is_01() || !zext_ln1116_61_fu_121142_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1116_62_fu_121158_p1.read()) + sc_biguint<9>(zext_ln1116_61_fu_121142_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_523_fu_123822_p2() {
    add_ln703_523_fu_123822_p2 = (!add_ln703_521_fu_123806_p2.read().is_01() || !zext_ln703_85_fu_123818_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_521_fu_123806_p2.read()) + sc_biguint<12>(zext_ln703_85_fu_123818_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_524_fu_131835_p2() {
    add_ln703_524_fu_131835_p2 = (!add_ln703_520_fu_131826_p2.read().is_01() || !sext_ln703_319_fu_131832_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_520_fu_131826_p2.read()) + sc_bigint<14>(sext_ln703_319_fu_131832_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_525_fu_131841_p2() {
    add_ln703_525_fu_131841_p2 = (!sext_ln1118_159_fu_127553_p1.read().is_01() || !sext_ln708_28_fu_127519_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_159_fu_127553_p1.read()) + sc_bigint<10>(sext_ln708_28_fu_127519_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_526_fu_131851_p2() {
    add_ln703_526_fu_131851_p2 = (!sext_ln1116_19_fu_127485_p1.read().is_01() || !sext_ln703_321_fu_131847_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1116_19_fu_127485_p1.read()) + sc_bigint<11>(sext_ln703_321_fu_131847_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_527_fu_123828_p2() {
    add_ln703_527_fu_123828_p2 = (!sext_ln1116_22_fu_121154_p1.read().is_01() || !sext_ln1116_21_fu_121150_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_22_fu_121154_p1.read()) + sc_bigint<10>(sext_ln1116_21_fu_121150_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_528_fu_123838_p2() {
    add_ln703_528_fu_123838_p2 = (!zext_ln1116_56_fu_119891_p1.read().is_01() || !zext_ln1116_60_fu_121135_p1.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln1116_56_fu_119891_p1.read()) + sc_biguint<6>(zext_ln1116_60_fu_121135_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_529_fu_123848_p2() {
    add_ln703_529_fu_123848_p2 = (!sext_ln703_323_fu_123834_p1.read().is_01() || !zext_ln703_86_fu_123844_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_323_fu_123834_p1.read()) + sc_biguint<11>(zext_ln703_86_fu_123844_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_52_fu_130424_p2() {
    add_ln703_52_fu_130424_p2 = (!sext_ln703_40_fu_130408_p1.read().is_01() || !sext_ln703_42_fu_130420_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_40_fu_130408_p1.read()) + sc_bigint<13>(sext_ln703_42_fu_130420_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_530_fu_131864_p2() {
    add_ln703_530_fu_131864_p2 = (!sext_ln703_322_fu_131857_p1.read().is_01() || !sext_ln703_324_fu_131861_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_322_fu_131857_p1.read()) + sc_bigint<12>(sext_ln703_324_fu_131861_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_531_fu_138133_p2() {
    add_ln703_531_fu_138133_p2 = (!sext_ln703_320_fu_138127_p1.read().is_01() || !sext_ln703_325_fu_138130_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_320_fu_138127_p1.read()) + sc_bigint<15>(sext_ln703_325_fu_138130_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_532_fu_138139_p2() {
    add_ln703_532_fu_138139_p2 = (!sext_ln203_75_fu_135492_p1.read().is_01() || !add_ln703_531_fu_138133_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_75_fu_135492_p1.read()) + sc_biguint<15>(add_ln703_531_fu_138133_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_533_fu_138145_p2() {
    add_ln703_533_fu_138145_p2 = (!sext_ln203_73_fu_135485_p1.read().is_01() || !sext_ln203_76_fu_135496_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_73_fu_135485_p1.read()) + sc_bigint<11>(sext_ln203_76_fu_135496_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_534_fu_138155_p2() {
    add_ln703_534_fu_138155_p2 = (!add_ln703_532_fu_138139_p2.read().is_01() || !sext_ln703_326_fu_138151_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_532_fu_138139_p2.read()) + sc_bigint<15>(sext_ln703_326_fu_138151_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_535_fu_138161_p2() {
    add_ln703_535_fu_138161_p2 = (!sext_ln203_77_fu_135500_p1.read().is_01() || !sext_ln203_74_fu_135489_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_77_fu_135500_p1.read()) + sc_bigint<10>(sext_ln203_74_fu_135489_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_536_fu_123854_p2() {
    add_ln703_536_fu_123854_p2 = (!zext_ln708_308_fu_121179_p1.read().is_01() || !zext_ln708_307_fu_121166_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln708_308_fu_121179_p1.read()) + sc_biguint<8>(zext_ln708_307_fu_121166_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_537_fu_138174_p2() {
    add_ln703_537_fu_138174_p2 = (!sext_ln703_327_fu_138167_p1.read().is_01() || !zext_ln703_87_fu_138171_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_327_fu_138167_p1.read()) + sc_biguint<11>(zext_ln703_87_fu_138171_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_539_fu_123860_p2() {
    add_ln703_539_fu_123860_p2 = (!sext_ln1118_161_fu_121183_p1.read().is_01() || !ap_const_lv10_380.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_161_fu_121183_p1.read()) + sc_bigint<10>(ap_const_lv10_380));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_53_fu_130434_p2() {
    add_ln703_53_fu_130434_p2 = (!add_ln703_47_fu_130402_p2.read().is_01() || !sext_ln703_45_fu_130430_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_47_fu_130402_p2.read()) + sc_bigint<15>(sext_ln703_45_fu_130430_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_540_fu_123870_p2() {
    add_ln703_540_fu_123870_p2 = (!zext_ln203_27_fu_121191_p1.read().is_01() || !sext_ln1118_162_fu_121187_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_27_fu_121191_p1.read()) + sc_bigint<12>(sext_ln1118_162_fu_121187_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_541_fu_123876_p2() {
    add_ln703_541_fu_123876_p2 = (!sext_ln703_330_fu_123866_p1.read().is_01() || !add_ln703_540_fu_123870_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_330_fu_123866_p1.read()) + sc_biguint<12>(add_ln703_540_fu_123870_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_542_fu_123882_p2() {
    add_ln703_542_fu_123882_p2 = (!zext_ln1118_696_fu_121195_p1.read().is_01() || !zext_ln708_26_fu_118916_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_696_fu_121195_p1.read()) + sc_biguint<9>(zext_ln708_26_fu_118916_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_543_fu_131876_p2() {
    add_ln703_543_fu_131876_p2 = (!zext_ln708_309_fu_127572_p1.read().is_01() || !zext_ln703_88_fu_131873_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_309_fu_127572_p1.read()) + sc_biguint<11>(zext_ln703_88_fu_131873_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_544_fu_131886_p2() {
    add_ln703_544_fu_131886_p2 = (!sext_ln703_331_fu_131870_p1.read().is_01() || !zext_ln703_89_fu_131882_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_331_fu_131870_p1.read()) + sc_biguint<13>(zext_ln703_89_fu_131882_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_545_fu_131892_p2() {
    add_ln703_545_fu_131892_p2 = (!sext_ln1118_164_fu_127619_p1.read().is_01() || !add_ln703_544_fu_131886_p2.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_164_fu_127619_p1.read()) + sc_biguint<13>(add_ln703_544_fu_131886_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_546_fu_131902_p2() {
    add_ln703_546_fu_131902_p2 = (!zext_ln1118_699_fu_127579_p1.read().is_01() || !zext_ln1118_698_fu_127576_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_699_fu_127579_p1.read()) + sc_biguint<10>(zext_ln1118_698_fu_127576_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_547_fu_131912_p2() {
    add_ln703_547_fu_131912_p2 = (!sext_ln703_332_fu_131898_p1.read().is_01() || !zext_ln703_90_fu_131908_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_332_fu_131898_p1.read()) + sc_biguint<14>(zext_ln703_90_fu_131908_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_548_fu_131918_p2() {
    add_ln703_548_fu_131918_p2 = (!trunc_ln1118_33_reg_142132.read().is_01() || !zext_ln708_310_fu_127599_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_33_reg_142132.read()) + sc_biguint<10>(zext_ln708_310_fu_127599_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_549_fu_123888_p2() {
    add_ln703_549_fu_123888_p2 = (!zext_ln1118_697_fu_121206_p1.read().is_01() || !sext_ln1118_163_fu_121198_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_697_fu_121206_p1.read()) + sc_bigint<10>(sext_ln1118_163_fu_121198_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_54_fu_130440_p2() {
    add_ln703_54_fu_130440_p2 = (!zext_ln203_2_fu_124707_p1.read().is_01() || !add_ln703_53_fu_130434_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_2_fu_124707_p1.read()) + sc_biguint<15>(add_ln703_53_fu_130434_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_550_fu_123898_p2() {
    add_ln703_550_fu_123898_p2 = (!sext_ln708_29_fu_121202_p1.read().is_01() || !sext_ln703_333_fu_123894_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_29_fu_121202_p1.read()) + sc_bigint<11>(sext_ln703_333_fu_123894_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_551_fu_131930_p2() {
    add_ln703_551_fu_131930_p2 = (!zext_ln703_91_fu_131923_p1.read().is_01() || !sext_ln703_334_fu_131927_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_91_fu_131923_p1.read()) + sc_bigint<12>(sext_ln703_334_fu_131927_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_552_fu_131940_p2() {
    add_ln703_552_fu_131940_p2 = (!add_ln703_547_fu_131912_p2.read().is_01() || !sext_ln703_335_fu_131936_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_547_fu_131912_p2.read()) + sc_bigint<14>(sext_ln703_335_fu_131936_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_553_fu_131946_p2() {
    add_ln703_553_fu_131946_p2 = (!sext_ln1118_168_fu_127664_p1.read().is_01() || !sext_ln203_13_fu_125175_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_168_fu_127664_p1.read()) + sc_bigint<12>(sext_ln203_13_fu_125175_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_554_fu_131956_p2() {
    add_ln703_554_fu_131956_p2 = (!add_ln703_552_fu_131940_p2.read().is_01() || !sext_ln703_336_fu_131952_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_552_fu_131940_p2.read()) + sc_bigint<14>(sext_ln703_336_fu_131952_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_555_fu_123904_p2() {
    add_ln703_555_fu_123904_p2 = (!grp_fu_116487_p4.read().is_01() || !zext_ln1118_703_fu_121209_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_116487_p4.read()) + sc_biguint<9>(zext_ln1118_703_fu_121209_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_556_fu_138200_p2() {
    add_ln703_556_fu_138200_p2 = (!sext_ln708_31_fu_135504_p1.read().is_01() || !zext_ln703_92_fu_138197_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_31_fu_135504_p1.read()) + sc_biguint<12>(zext_ln703_92_fu_138197_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_557_fu_138210_p2() {
    add_ln703_557_fu_138210_p2 = (!sext_ln703_337_fu_138194_p1.read().is_01() || !sext_ln703_338_fu_138206_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_337_fu_138194_p1.read()) + sc_bigint<15>(sext_ln703_338_fu_138206_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_558_fu_123910_p2() {
    add_ln703_558_fu_123910_p2 = (!sext_ln1118_167_fu_121213_p1.read().is_01() || !zext_ln708_311_fu_121227_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_167_fu_121213_p1.read()) + sc_biguint<11>(zext_ln708_311_fu_121227_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_559_fu_138219_p2() {
    add_ln703_559_fu_138219_p2 = (!zext_ln1118_704_fu_135508_p1.read().is_01() || !sext_ln703_339_fu_138216_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_704_fu_135508_p1.read()) + sc_bigint<12>(sext_ln703_339_fu_138216_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_55_fu_130446_p2() {
    add_ln703_55_fu_130446_p2 = (!zext_ln203_87_fu_124742_p1.read().is_01() || !trunc_ln203_s_reg_141154.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_87_fu_124742_p1.read()) + sc_biguint<10>(trunc_ln203_s_reg_141154.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_560_fu_131962_p2() {
    add_ln703_560_fu_131962_p2 = (!zext_ln1118_702_fu_127661_p1.read().is_01() || !sext_ln1118_165_fu_127654_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_702_fu_127661_p1.read()) + sc_bigint<9>(sext_ln1118_165_fu_127654_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_561_fu_131972_p2() {
    add_ln703_561_fu_131972_p2 = (!sext_ln708_30_fu_127658_p1.read().is_01() || !sext_ln703_340_fu_131968_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_30_fu_127658_p1.read()) + sc_bigint<10>(sext_ln703_340_fu_131968_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_562_fu_138228_p2() {
    add_ln703_562_fu_138228_p2 = (!add_ln703_559_fu_138219_p2.read().is_01() || !sext_ln703_341_fu_138225_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_559_fu_138219_p2.read()) + sc_bigint<12>(sext_ln703_341_fu_138225_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_563_fu_138238_p2() {
    add_ln703_563_fu_138238_p2 = (!add_ln703_557_fu_138210_p2.read().is_01() || !sext_ln703_342_fu_138234_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_557_fu_138210_p2.read()) + sc_bigint<15>(sext_ln703_342_fu_138234_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_564_fu_138244_p2() {
    add_ln703_564_fu_138244_p2 = (!sext_ln203_80_fu_135575_p1.read().is_01() || !sext_ln203_78_fu_135512_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_80_fu_135575_p1.read()) + sc_bigint<12>(sext_ln203_78_fu_135512_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_565_fu_138254_p2() {
    add_ln703_565_fu_138254_p2 = (!add_ln703_563_fu_138238_p2.read().is_01() || !sext_ln703_343_fu_138250_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_563_fu_138238_p2.read()) + sc_bigint<15>(sext_ln703_343_fu_138250_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_566_fu_138260_p2() {
    add_ln703_566_fu_138260_p2 = (!sext_ln203_79_fu_135557_p1.read().is_01() || !zext_ln708_312_fu_135571_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_79_fu_135557_p1.read()) + sc_biguint<11>(zext_ln708_312_fu_135571_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_567_fu_138270_p2() {
    add_ln703_567_fu_138270_p2 = (!zext_ln203_28_fu_135516_p1.read().is_01() || !sext_ln703_344_fu_138266_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_28_fu_135516_p1.read()) + sc_bigint<12>(sext_ln703_344_fu_138266_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_569_fu_123916_p2() {
    add_ln703_569_fu_123916_p2 = (!sext_ln1118_170_fu_121251_p1.read().is_01() || !ap_const_lv10_340.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_170_fu_121251_p1.read()) + sc_bigint<10>(ap_const_lv10_340));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_56_fu_130455_p2() {
    add_ln703_56_fu_130455_p2 = (!zext_ln708_228_fu_124711_p1.read().is_01() || !zext_ln703_10_fu_130451_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_228_fu_124711_p1.read()) + sc_biguint<11>(zext_ln703_10_fu_130451_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_570_fu_123922_p2() {
    add_ln703_570_fu_123922_p2 = (!zext_ln1118_708_fu_121275_p1.read().is_01() || !add_ln703_569_fu_123916_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_708_fu_121275_p1.read()) + sc_biguint<10>(add_ln703_569_fu_123916_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_571_fu_123932_p2() {
    add_ln703_571_fu_123932_p2 = (!zext_ln1118_711_fu_121327_p1.read().is_01() || !sext_ln1118_172_fu_121313_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_711_fu_121327_p1.read()) + sc_bigint<12>(sext_ln1118_172_fu_121313_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_572_fu_123942_p2() {
    add_ln703_572_fu_123942_p2 = (!sext_ln703_82_fu_123928_p1.read().is_01() || !sext_ln703_347_fu_123938_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_82_fu_123928_p1.read()) + sc_bigint<13>(sext_ln703_347_fu_123938_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_573_fu_123948_p2() {
    add_ln703_573_fu_123948_p2 = (!zext_ln1118_716_fu_121377_p1.read().is_01() || !zext_ln1118_715_fu_121373_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_716_fu_121377_p1.read()) + sc_biguint<10>(zext_ln1118_715_fu_121373_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_574_fu_123954_p2() {
    add_ln703_574_fu_123954_p2 = (!zext_ln1118_712_fu_121331_p1.read().is_01() || !add_ln703_573_fu_123948_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_712_fu_121331_p1.read()) + sc_biguint<10>(add_ln703_573_fu_123948_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_575_fu_123964_p2() {
    add_ln703_575_fu_123964_p2 = (!add_ln703_572_fu_123942_p2.read().is_01() || !zext_ln703_93_fu_123960_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_572_fu_123942_p2.read()) + sc_biguint<13>(zext_ln703_93_fu_123960_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_576_fu_123974_p2() {
    add_ln703_576_fu_123974_p2 = (!sext_ln1118_174_fu_121413_p1.read().is_01() || !zext_ln1118_718_fu_121401_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_174_fu_121413_p1.read()) + sc_biguint<12>(zext_ln1118_718_fu_121401_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_577_fu_123984_p2() {
    add_ln703_577_fu_123984_p2 = (!sext_ln703_83_fu_123970_p1.read().is_01() || !sext_ln703_348_fu_123980_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_83_fu_123970_p1.read()) + sc_bigint<14>(sext_ln703_348_fu_123980_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_578_fu_123990_p2() {
    add_ln703_578_fu_123990_p2 = (!zext_ln708_314_fu_121417_p1.read().is_01() || !zext_ln708_313_fu_121409_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_314_fu_121417_p1.read()) + sc_biguint<11>(zext_ln708_313_fu_121409_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_579_fu_124000_p2() {
    add_ln703_579_fu_124000_p2 = (!sext_ln1118_173_fu_121405_p1.read().is_01() || !zext_ln1118_719_fu_121421_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_173_fu_121405_p1.read()) + sc_biguint<10>(zext_ln1118_719_fu_121421_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_57_fu_130465_p2() {
    add_ln703_57_fu_130465_p2 = (!add_ln703_54_fu_130440_p2.read().is_01() || !zext_ln703_11_fu_130461_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_54_fu_130440_p2.read()) + sc_biguint<15>(zext_ln703_11_fu_130461_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_580_fu_124010_p2() {
    add_ln703_580_fu_124010_p2 = (!zext_ln703_94_fu_123996_p1.read().is_01() || !sext_ln703_349_fu_124006_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_94_fu_123996_p1.read()) + sc_bigint<12>(sext_ln703_349_fu_124006_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_581_fu_131981_p2() {
    add_ln703_581_fu_131981_p2 = (!add_ln703_577_reg_142483.read().is_01() || !sext_ln703_350_fu_131978_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_577_reg_142483.read()) + sc_bigint<14>(sext_ln703_350_fu_131978_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_582_fu_131986_p2() {
    add_ln703_582_fu_131986_p2 = (!zext_ln1118_721_fu_127714_p1.read().is_01() || !add_ln703_581_fu_131981_p2.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln1118_721_fu_127714_p1.read()) + sc_biguint<14>(add_ln703_581_fu_131981_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_583_fu_124016_p2() {
    add_ln703_583_fu_124016_p2 = (!sext_ln1118_177_fu_121429_p1.read().is_01() || !zext_ln1118_722_fu_121425_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_177_fu_121429_p1.read()) + sc_biguint<12>(zext_ln1118_722_fu_121425_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_584_fu_131999_p2() {
    add_ln703_584_fu_131999_p2 = (!zext_ln708_124_fu_127718_p1.read().is_01() || !sext_ln703_352_fu_131996_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln708_124_fu_127718_p1.read()) + sc_bigint<13>(sext_ln703_352_fu_131996_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_585_fu_132009_p2() {
    add_ln703_585_fu_132009_p2 = (!sext_ln703_351_fu_131992_p1.read().is_01() || !sext_ln703_353_fu_132005_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_351_fu_131992_p1.read()) + sc_bigint<15>(sext_ln703_353_fu_132005_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_586_fu_138290_p2() {
    add_ln703_586_fu_138290_p2 = (!sext_ln1118_181_fu_135583_p1.read().is_01() || !sext_ln1118_179_fu_135579_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_181_fu_135583_p1.read()) + sc_bigint<10>(sext_ln1118_179_fu_135579_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_587_fu_132015_p2() {
    add_ln703_587_fu_132015_p2 = (!sext_ln1118_175_fu_127683_p1.read().is_01() || !sext_ln1118_178_fu_127762_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_175_fu_127683_p1.read()) + sc_bigint<7>(sext_ln1118_178_fu_127762_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_588_fu_132025_p2() {
    add_ln703_588_fu_132025_p2 = (!sext_ln1118_176_fu_127742_p1.read().is_01() || !sext_ln703_354_fu_132021_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_176_fu_127742_p1.read()) + sc_bigint<8>(sext_ln703_354_fu_132021_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_589_fu_138299_p2() {
    add_ln703_589_fu_138299_p2 = (!add_ln703_586_fu_138290_p2.read().is_01() || !sext_ln703_355_fu_138296_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(add_ln703_586_fu_138290_p2.read()) + sc_bigint<10>(sext_ln703_355_fu_138296_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_58_fu_130471_p2() {
    add_ln703_58_fu_130471_p2 = (!zext_ln708_230_fu_124750_p1.read().is_01() || !zext_ln708_229_fu_124746_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_230_fu_124750_p1.read()) + sc_biguint<11>(zext_ln708_229_fu_124746_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_590_fu_138309_p2() {
    add_ln703_590_fu_138309_p2 = (!add_ln703_585_reg_143003.read().is_01() || !sext_ln703_356_fu_138305_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_585_reg_143003.read()) + sc_bigint<15>(sext_ln703_356_fu_138305_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_591_fu_138314_p2() {
    add_ln703_591_fu_138314_p2 = (!sext_ln203_81_fu_135586_p1.read().is_01() || !add_ln703_590_fu_138309_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_81_fu_135586_p1.read()) + sc_biguint<15>(add_ln703_590_fu_138309_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_592_fu_138320_p2() {
    add_ln703_592_fu_138320_p2 = (!zext_ln203_100_fu_135623_p1.read().is_01() || !zext_ln203_99_fu_135619_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_100_fu_135623_p1.read()) + sc_biguint<9>(zext_ln203_99_fu_135619_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_593_fu_138330_p2() {
    add_ln703_593_fu_138330_p2 = (!sext_ln203_85_fu_135689_p1.read().is_01() || !zext_ln703_95_fu_138326_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_85_fu_135689_p1.read()) + sc_biguint<12>(zext_ln703_95_fu_138326_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_594_fu_138340_p2() {
    add_ln703_594_fu_138340_p2 = (!add_ln703_591_fu_138314_p2.read().is_01() || !sext_ln703_357_fu_138336_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_591_fu_138314_p2.read()) + sc_bigint<15>(sext_ln703_357_fu_138336_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_595_fu_138346_p2() {
    add_ln703_595_fu_138346_p2 = (!sext_ln203_84_fu_135685_p1.read().is_01() || !sext_ln203_82_fu_135589_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_84_fu_135685_p1.read()) + sc_bigint<11>(sext_ln203_82_fu_135589_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_596_fu_138356_p2() {
    add_ln703_596_fu_138356_p2 = (!zext_ln203_29_fu_135651_p1.read().is_01() || !sext_ln703_358_fu_138352_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_29_fu_135651_p1.read()) + sc_bigint<12>(sext_ln703_358_fu_138352_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_597_fu_138362_p2() {
    add_ln703_597_fu_138362_p2 = (!sext_ln203_87_fu_135727_p1.read().is_01() || !zext_ln708_315_fu_135731_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_87_fu_135727_p1.read()) + sc_biguint<8>(zext_ln708_315_fu_135731_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_598_fu_138372_p2() {
    add_ln703_598_fu_138372_p2 = (!sext_ln203_83_fu_135627_p1.read().is_01() || !sext_ln703_359_fu_138368_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_83_fu_135627_p1.read()) + sc_bigint<9>(sext_ln703_359_fu_138368_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_599_fu_138382_p2() {
    add_ln703_599_fu_138382_p2 = (!add_ln703_596_fu_138356_p2.read().is_01() || !sext_ln703_360_fu_138378_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_596_fu_138356_p2.read()) + sc_bigint<12>(sext_ln703_360_fu_138378_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_59_fu_130481_p2() {
    add_ln703_59_fu_130481_p2 = (!sext_ln203_6_fu_124754_p1.read().is_01() || !sext_ln203_5_fu_124698_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_6_fu_124754_p1.read()) + sc_bigint<11>(sext_ln203_5_fu_124698_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_5_fu_122537_p2() {
    add_ln703_5_fu_122537_p2 = (!zext_ln708_220_fu_118562_p1.read().is_01() || !zext_ln708_219_fu_118554_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_220_fu_118562_p1.read()) + sc_biguint<11>(zext_ln708_219_fu_118554_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_601_fu_124022_p2() {
    add_ln703_601_fu_124022_p2 = (!zext_ln203_101_fu_121470_p1.read().is_01() || !ap_const_lv9_158.is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_101_fu_121470_p1.read()) + sc_bigint<9>(ap_const_lv9_158));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_602_fu_124032_p2() {
    add_ln703_602_fu_124032_p2 = (!sext_ln703_86_fu_124028_p1.read().is_01() || !zext_ln203_102_fu_121490_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln703_86_fu_124028_p1.read()) + sc_biguint<10>(zext_ln203_102_fu_121490_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_603_fu_124038_p2() {
    add_ln703_603_fu_124038_p2 = (!zext_ln203_103_fu_121514_p1.read().is_01() || !add_ln703_602_fu_124032_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_103_fu_121514_p1.read()) + sc_biguint<10>(add_ln703_602_fu_124032_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_604_fu_124048_p2() {
    add_ln703_604_fu_124048_p2 = (!sext_ln703_87_fu_124044_p1.read().is_01() || !sext_ln203_88_fu_121518_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_87_fu_124044_p1.read()) + sc_bigint<12>(sext_ln203_88_fu_121518_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_605_fu_124054_p2() {
    add_ln703_605_fu_124054_p2 = (!zext_ln708_128_fu_121557_p1.read().is_01() || !add_ln703_604_fu_124048_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_128_fu_121557_p1.read()) + sc_biguint<12>(add_ln703_604_fu_124048_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_606_fu_124064_p2() {
    add_ln703_606_fu_124064_p2 = (!sext_ln1118_184_fu_121538_p1.read().is_01() || !zext_ln708_317_fu_121571_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_184_fu_121538_p1.read()) + sc_biguint<11>(zext_ln708_317_fu_121571_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_607_fu_124074_p2() {
    add_ln703_607_fu_124074_p2 = (!sext_ln703_363_fu_124060_p1.read().is_01() || !sext_ln703_364_fu_124070_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_363_fu_124060_p1.read()) + sc_bigint<13>(sext_ln703_364_fu_124070_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_608_fu_132031_p2() {
    add_ln703_608_fu_132031_p2 = (!sext_ln1118_186_fu_127870_p1.read().is_01() || !add_ln703_607_reg_142498.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_186_fu_127870_p1.read()) + sc_biguint<13>(add_ln703_607_reg_142498.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_609_fu_132036_p2() {
    add_ln703_609_fu_132036_p2 = (!zext_ln708_318_fu_127893_p1.read().is_01() || !trunc_ln1118_35_reg_142157.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln708_318_fu_127893_p1.read()) + sc_biguint<9>(trunc_ln1118_35_reg_142157.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_60_fu_130491_p2() {
    add_ln703_60_fu_130491_p2 = (!zext_ln203_3_fu_124791_p1.read().is_01() || !sext_ln703_47_fu_130487_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_3_fu_124791_p1.read()) + sc_bigint<12>(sext_ln703_47_fu_130487_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_610_fu_132045_p2() {
    add_ln703_610_fu_132045_p2 = (!add_ln703_608_fu_132031_p2.read().is_01() || !zext_ln703_96_fu_132041_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_608_fu_132031_p2.read()) + sc_biguint<13>(zext_ln703_96_fu_132041_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_611_fu_124080_p2() {
    add_ln703_611_fu_124080_p2 = (!sext_ln1118_188_fu_121606_p1.read().is_01() || !sext_ln1118_187_fu_121602_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_188_fu_121606_p1.read()) + sc_bigint<11>(sext_ln1118_187_fu_121602_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_612_fu_124090_p2() {
    add_ln703_612_fu_124090_p2 = (!sext_ln1118_185_fu_121595_p1.read().is_01() || !zext_ln708_319_fu_121599_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_185_fu_121595_p1.read()) + sc_biguint<8>(zext_ln708_319_fu_121599_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_613_fu_124100_p2() {
    add_ln703_613_fu_124100_p2 = (!sext_ln703_366_fu_124086_p1.read().is_01() || !sext_ln703_367_fu_124096_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_366_fu_124086_p1.read()) + sc_bigint<12>(sext_ln703_367_fu_124096_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_614_fu_132058_p2() {
    add_ln703_614_fu_132058_p2 = (!sext_ln703_365_fu_132051_p1.read().is_01() || !sext_ln703_368_fu_132055_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_365_fu_132051_p1.read()) + sc_bigint<14>(sext_ln703_368_fu_132055_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_615_fu_132064_p2() {
    add_ln703_615_fu_132064_p2 = (!sext_ln1118_189_fu_127897_p1.read().is_01() || !add_ln703_614_fu_132058_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_189_fu_127897_p1.read()) + sc_biguint<14>(add_ln703_614_fu_132058_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_616_fu_132074_p2() {
    add_ln703_616_fu_132074_p2 = (!sext_ln708_32_fu_127953_p1.read().is_01() || !sext_ln1118_12_fu_124653_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_32_fu_127953_p1.read()) + sc_bigint<12>(sext_ln1118_12_fu_124653_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_617_fu_132084_p2() {
    add_ln703_617_fu_132084_p2 = (!sext_ln1118_192_fu_127934_p1.read().is_01() || !sext_ln703_370_fu_132080_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_192_fu_127934_p1.read()) + sc_bigint<13>(sext_ln703_370_fu_132080_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_618_fu_132094_p2() {
    add_ln703_618_fu_132094_p2 = (!sext_ln703_369_fu_132070_p1.read().is_01() || !sext_ln703_371_fu_132090_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_369_fu_132070_p1.read()) + sc_bigint<15>(sext_ln703_371_fu_132090_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_619_fu_124106_p2() {
    add_ln703_619_fu_124106_p2 = (!zext_ln708_322_fu_121638_p1.read().is_01() || !zext_ln708_321_fu_121624_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_322_fu_121638_p1.read()) + sc_biguint<11>(zext_ln708_321_fu_121624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_61_fu_130501_p2() {
    add_ln703_61_fu_130501_p2 = (!zext_ln703_12_fu_130477_p1.read().is_01() || !sext_ln703_48_fu_130497_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_12_fu_130477_p1.read()) + sc_bigint<13>(sext_ln703_48_fu_130497_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_620_fu_124112_p2() {
    add_ln703_620_fu_124112_p2 = (!zext_ln708_320_fu_121620_p1.read().is_01() || !add_ln703_619_fu_124106_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_320_fu_121620_p1.read()) + sc_biguint<11>(add_ln703_619_fu_124106_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_621_fu_132103_p2() {
    add_ln703_621_fu_132103_p2 = (!sext_ln1118_190_fu_127927_p1.read().is_01() || !sext_ln1118_191_fu_127931_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_190_fu_127927_p1.read()) + sc_bigint<11>(sext_ln1118_191_fu_127931_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_622_fu_132113_p2() {
    add_ln703_622_fu_132113_p2 = (!zext_ln1118_733_fu_127957_p1.read().is_01() || !sext_ln703_372_fu_132109_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_733_fu_127957_p1.read()) + sc_bigint<12>(sext_ln703_372_fu_132109_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_623_fu_132123_p2() {
    add_ln703_623_fu_132123_p2 = (!zext_ln703_97_fu_132100_p1.read().is_01() || !sext_ln703_373_fu_132119_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_97_fu_132100_p1.read()) + sc_bigint<13>(sext_ln703_373_fu_132119_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_624_fu_138405_p2() {
    add_ln703_624_fu_138405_p2 = (!add_ln703_618_reg_143013.read().is_01() || !sext_ln703_374_fu_138402_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_618_reg_143013.read()) + sc_bigint<15>(sext_ln703_374_fu_138402_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_625_fu_138410_p2() {
    add_ln703_625_fu_138410_p2 = (!sext_ln203_91_fu_135780_p1.read().is_01() || !add_ln703_624_fu_138405_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_91_fu_135780_p1.read()) + sc_biguint<15>(add_ln703_624_fu_138405_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_626_fu_138416_p2() {
    add_ln703_626_fu_138416_p2 = (!zext_ln203_30_fu_135858_p1.read().is_01() || !sext_ln203_93_fu_135830_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_30_fu_135858_p1.read()) + sc_bigint<12>(sext_ln203_93_fu_135830_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_627_fu_138426_p2() {
    add_ln703_627_fu_138426_p2 = (!add_ln703_625_fu_138410_p2.read().is_01() || !sext_ln703_375_fu_138422_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_625_fu_138410_p2.read()) + sc_bigint<15>(sext_ln703_375_fu_138422_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_628_fu_138432_p2() {
    add_ln703_628_fu_138432_p2 = (!sext_ln203_89_fu_135752_p1.read().is_01() || !sext_ln203_94_fu_135834_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_89_fu_135752_p1.read()) + sc_bigint<10>(sext_ln203_94_fu_135834_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_629_fu_138442_p2() {
    add_ln703_629_fu_138442_p2 = (!sext_ln203_92_fu_135800_p1.read().is_01() || !sext_ln203_95_fu_135854_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_92_fu_135800_p1.read()) + sc_bigint<9>(sext_ln203_95_fu_135854_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_630_fu_138452_p2() {
    add_ln703_630_fu_138452_p2 = (!sext_ln203_90_fu_135756_p1.read().is_01() || !sext_ln703_377_fu_138448_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_90_fu_135756_p1.read()) + sc_bigint<10>(sext_ln703_377_fu_138448_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_631_fu_138462_p2() {
    add_ln703_631_fu_138462_p2 = (!sext_ln703_376_fu_138438_p1.read().is_01() || !sext_ln703_378_fu_138458_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_376_fu_138438_p1.read()) + sc_bigint<11>(sext_ln703_378_fu_138458_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_633_fu_124118_p2() {
    add_ln703_633_fu_124118_p2 = (!zext_ln708_323_fu_121642_p1.read().is_01() || !ap_const_lv11_450.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_323_fu_121642_p1.read()) + sc_bigint<11>(ap_const_lv11_450));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_634_fu_124128_p2() {
    add_ln703_634_fu_124128_p2 = (!sext_ln203_96_fu_121662_p1.read().is_01() || !zext_ln203_31_fu_121693_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_96_fu_121662_p1.read()) + sc_biguint<12>(zext_ln203_31_fu_121693_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_635_fu_124134_p2() {
    add_ln703_635_fu_124134_p2 = (!sext_ln703_92_fu_124124_p1.read().is_01() || !add_ln703_634_fu_124128_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_92_fu_124124_p1.read()) + sc_biguint<12>(add_ln703_634_fu_124128_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_636_fu_124140_p2() {
    add_ln703_636_fu_124140_p2 = (!zext_ln1118_736_fu_121697_p1.read().is_01() || !add_ln703_635_fu_124134_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_736_fu_121697_p1.read()) + sc_biguint<12>(add_ln703_635_fu_124134_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_637_fu_124146_p2() {
    add_ln703_637_fu_124146_p2 = (!sext_ln708_33_fu_121711_p1.read().is_01() || !zext_ln1118_738_fu_121735_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_33_fu_121711_p1.read()) + sc_biguint<10>(zext_ln1118_738_fu_121735_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_638_fu_124156_p2() {
    add_ln703_638_fu_124156_p2 = (!add_ln703_636_fu_124140_p2.read().is_01() || !sext_ln703_381_fu_124152_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_636_fu_124140_p2.read()) + sc_bigint<12>(sext_ln703_381_fu_124152_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_639_fu_132132_p2() {
    add_ln703_639_fu_132132_p2 = (!zext_ln1118_740_fu_127960_p1.read().is_01() || !sext_ln703_382_fu_132129_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_740_fu_127960_p1.read()) + sc_bigint<13>(sext_ln703_382_fu_132129_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_63_fu_118085_p2() {
    add_ln703_63_fu_118085_p2 = (!sext_ln203_7_fu_117155_p1.read().is_01() || !ap_const_lv12_C08.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_7_fu_117155_p1.read()) + sc_bigint<12>(ap_const_lv12_C08));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_640_fu_124162_p2() {
    add_ln703_640_fu_124162_p2 = (!zext_ln1118_742_fu_121771_p1.read().is_01() || !zext_ln1118_741_fu_121767_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_742_fu_121771_p1.read()) + sc_biguint<10>(zext_ln1118_741_fu_121767_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_641_fu_124172_p2() {
    add_ln703_641_fu_124172_p2 = (!zext_ln708_324_fu_121763_p1.read().is_01() || !zext_ln703_98_fu_124168_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_324_fu_121763_p1.read()) + sc_biguint<11>(zext_ln703_98_fu_124168_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_642_fu_132141_p2() {
    add_ln703_642_fu_132141_p2 = (!add_ln703_639_fu_132132_p2.read().is_01() || !zext_ln703_99_fu_132138_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_639_fu_132132_p2.read()) + sc_biguint<13>(zext_ln703_99_fu_132138_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_643_fu_132151_p2() {
    add_ln703_643_fu_132151_p2 = (!zext_ln1116_63_fu_128017_p1.read().is_01() || !zext_ln1118_746_fu_127998_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_63_fu_128017_p1.read()) + sc_biguint<10>(zext_ln1118_746_fu_127998_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_644_fu_124178_p2() {
    add_ln703_644_fu_124178_p2 = (!sext_ln708_34_fu_121759_p1.read().is_01() || !zext_ln1118_743_fu_121775_p1.read().is_01())? sc_lv<6>(): (sc_bigint<6>(sext_ln708_34_fu_121759_p1.read()) + sc_biguint<6>(zext_ln1118_743_fu_121775_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_645_fu_132164_p2() {
    add_ln703_645_fu_132164_p2 = (!sext_ln1118_195_fu_127994_p1.read().is_01() || !sext_ln703_384_fu_132161_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_195_fu_127994_p1.read()) + sc_bigint<9>(sext_ln703_384_fu_132161_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_646_fu_132174_p2() {
    add_ln703_646_fu_132174_p2 = (!zext_ln703_100_fu_132157_p1.read().is_01() || !sext_ln703_385_fu_132170_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_100_fu_132157_p1.read()) + sc_bigint<11>(sext_ln703_385_fu_132170_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_647_fu_132184_p2() {
    add_ln703_647_fu_132184_p2 = (!sext_ln703_383_fu_132147_p1.read().is_01() || !sext_ln703_386_fu_132180_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_383_fu_132147_p1.read()) + sc_bigint<14>(sext_ln703_386_fu_132180_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_648_fu_138482_p2() {
    add_ln703_648_fu_138482_p2 = (!sext_ln708_35_fu_135862_p1.read().is_01() || !add_ln703_647_reg_143023.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln708_35_fu_135862_p1.read()) + sc_biguint<14>(add_ln703_647_reg_143023.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_649_fu_132190_p2() {
    add_ln703_649_fu_132190_p2 = (!trunc_ln708_1286_fu_128124_p4.read().is_01() || !zext_ln708_326_fu_128081_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln708_1286_fu_128124_p4.read()) + sc_biguint<10>(zext_ln708_326_fu_128081_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_64_fu_118095_p2() {
    add_ln703_64_fu_118095_p2 = (!zext_ln1118_274_fu_117163_p1.read().is_01() || !sext_ln708_3_fu_117159_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_274_fu_117163_p1.read()) + sc_bigint<12>(sext_ln708_3_fu_117159_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_650_fu_132200_p2() {
    add_ln703_650_fu_132200_p2 = (!zext_ln708_325_fu_128040_p1.read().is_01() || !zext_ln703_101_fu_132196_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_325_fu_128040_p1.read()) + sc_biguint<11>(zext_ln703_101_fu_132196_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_651_fu_138490_p2() {
    add_ln703_651_fu_138490_p2 = (!add_ln703_648_fu_138482_p2.read().is_01() || !zext_ln703_102_fu_138487_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_648_fu_138482_p2.read()) + sc_biguint<14>(zext_ln703_102_fu_138487_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_652_fu_138500_p2() {
    add_ln703_652_fu_138500_p2 = (!sext_ln1118_202_fu_135896_p1.read().is_01() || !sext_ln1118_197_reg_142783.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_202_fu_135896_p1.read()) + sc_bigint<11>(sext_ln1118_197_reg_142783.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_653_fu_132206_p2() {
    add_ln703_653_fu_132206_p2 = (!sext_ln1118_198_fu_128077_p1.read().is_01() || !sext_ln1118_196_fu_128021_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_198_fu_128077_p1.read()) + sc_bigint<9>(sext_ln1118_196_fu_128021_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_654_fu_132216_p2() {
    add_ln703_654_fu_132216_p2 = (!sext_ln1118_200_fu_128114_p1.read().is_01() || !sext_ln703_389_fu_132212_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_200_fu_128114_p1.read()) + sc_bigint<10>(sext_ln703_389_fu_132212_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_655_fu_138512_p2() {
    add_ln703_655_fu_138512_p2 = (!sext_ln703_388_fu_138505_p1.read().is_01() || !sext_ln703_390_fu_138509_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_388_fu_138505_p1.read()) + sc_bigint<12>(sext_ln703_390_fu_138509_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_656_fu_138522_p2() {
    add_ln703_656_fu_138522_p2 = (!sext_ln703_387_fu_138496_p1.read().is_01() || !sext_ln703_391_fu_138518_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_387_fu_138496_p1.read()) + sc_bigint<15>(sext_ln703_391_fu_138518_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_657_fu_138528_p2() {
    add_ln703_657_fu_138528_p2 = (!zext_ln203_32_fu_135939_p1.read().is_01() || !add_ln703_656_fu_138522_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_32_fu_135939_p1.read()) + sc_biguint<15>(add_ln703_656_fu_138522_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_658_fu_138534_p2() {
    add_ln703_658_fu_138534_p2 = (!sext_ln203_100_fu_135943_p1.read().is_01() || !sext_ln203_79_fu_135557_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_100_fu_135943_p1.read()) + sc_bigint<11>(sext_ln203_79_fu_135557_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_659_fu_138544_p2() {
    add_ln703_659_fu_138544_p2 = (!add_ln703_657_fu_138528_p2.read().is_01() || !sext_ln703_392_fu_138540_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_657_fu_138528_p2.read()) + sc_bigint<15>(sext_ln703_392_fu_138540_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_65_fu_118105_p2() {
    add_ln703_65_fu_118105_p2 = (!sext_ln703_14_fu_118091_p1.read().is_01() || !sext_ln703_51_fu_118101_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_14_fu_118091_p1.read()) + sc_bigint<13>(sext_ln703_51_fu_118101_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_660_fu_138550_p2() {
    add_ln703_660_fu_138550_p2 = (!sext_ln203_98_fu_135904_p1.read().is_01() || !sext_ln203_97_fu_135900_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_98_fu_135904_p1.read()) + sc_bigint<10>(sext_ln203_97_fu_135900_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_661_fu_138560_p2() {
    add_ln703_661_fu_138560_p2 = (!sext_ln203_86_fu_135723_p1.read().is_01() || !sext_ln203_99_fu_135908_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_86_fu_135723_p1.read()) + sc_bigint<9>(sext_ln203_99_fu_135908_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_662_fu_138570_p2() {
    add_ln703_662_fu_138570_p2 = (!sext_ln703_393_fu_138556_p1.read().is_01() || !sext_ln703_394_fu_138566_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_393_fu_138556_p1.read()) + sc_bigint<11>(sext_ln703_394_fu_138566_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_664_fu_132222_p2() {
    add_ln703_664_fu_132222_p2 = (!grp_fu_116177_p4.read().is_01() || !ap_const_lv9_1D8.is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_116177_p4.read()) + sc_bigint<9>(ap_const_lv9_1D8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_665_fu_132232_p2() {
    add_ln703_665_fu_132232_p2 = (!sext_ln703_97_fu_132228_p1.read().is_01() || !zext_ln708_327_fu_128134_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_97_fu_132228_p1.read()) + sc_biguint<11>(zext_ln708_327_fu_128134_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_666_fu_132242_p2() {
    add_ln703_666_fu_132242_p2 = (!zext_ln203_34_fu_128138_p1.read().is_01() || !sext_ln703_98_fu_132238_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_34_fu_128138_p1.read()) + sc_bigint<12>(sext_ln703_98_fu_132238_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_667_fu_132248_p2() {
    add_ln703_667_fu_132248_p2 = (!trunc_ln708_1297_fu_128146_p4.read().is_01() || !zext_ln708_328_fu_128142_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln708_1297_fu_128146_p4.read()) + sc_biguint<10>(zext_ln708_328_fu_128142_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_668_fu_138596_p2() {
    add_ln703_668_fu_138596_p2 = (!sext_ln703_99_fu_138590_p1.read().is_01() || !zext_ln703_103_fu_138593_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_99_fu_138590_p1.read()) + sc_biguint<13>(zext_ln703_103_fu_138593_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_669_fu_132254_p2() {
    add_ln703_669_fu_132254_p2 = (!sext_ln1118_66_reg_141967.read().is_01() || !zext_ln708_329_fu_128160_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_66_reg_141967.read()) + sc_biguint<11>(zext_ln708_329_fu_128160_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_66_fu_122659_p2() {
    add_ln703_66_fu_122659_p2 = (!reg_116675.read().is_01() || !zext_ln1118_535_fu_118946_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(reg_116675.read()) + sc_biguint<9>(zext_ln1118_535_fu_118946_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_670_fu_132263_p2() {
    add_ln703_670_fu_132263_p2 = (!zext_ln1118_751_fu_128156_p1.read().is_01() || !sext_ln703_397_fu_132259_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_751_fu_128156_p1.read()) + sc_bigint<12>(sext_ln703_397_fu_132259_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_671_fu_138605_p2() {
    add_ln703_671_fu_138605_p2 = (!add_ln703_668_fu_138596_p2.read().is_01() || !sext_ln703_398_fu_138602_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_668_fu_138596_p2.read()) + sc_bigint<13>(sext_ln703_398_fu_138602_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_672_fu_132269_p2() {
    add_ln703_672_fu_132269_p2 = (!grp_fu_115677_p4.read().is_01() || !zext_ln1118_753_fu_128202_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115677_p4.read()) + sc_biguint<10>(zext_ln1118_753_fu_128202_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_673_fu_138618_p2() {
    add_ln703_673_fu_138618_p2 = (!sext_ln703_100_fu_138611_p1.read().is_01() || !zext_ln703_104_fu_138615_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_100_fu_138611_p1.read()) + sc_biguint<14>(zext_ln703_104_fu_138615_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_674_fu_132275_p2() {
    add_ln703_674_fu_132275_p2 = (!sext_ln1118_205_fu_128198_p1.read().is_01() || !sext_ln708_36_fu_128216_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_205_fu_128198_p1.read()) + sc_bigint<11>(sext_ln708_36_fu_128216_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_675_fu_132285_p2() {
    add_ln703_675_fu_132285_p2 = (!sext_ln1118_204_fu_128174_p1.read().is_01() || !sext_ln703_399_fu_132281_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_204_fu_128174_p1.read()) + sc_bigint<12>(sext_ln703_399_fu_132281_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_676_fu_138627_p2() {
    add_ln703_676_fu_138627_p2 = (!add_ln703_673_fu_138618_p2.read().is_01() || !sext_ln703_400_fu_138624_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_673_fu_138618_p2.read()) + sc_bigint<14>(sext_ln703_400_fu_138624_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_677_fu_138633_p2() {
    add_ln703_677_fu_138633_p2 = (!sext_ln1118_207_fu_135951_p1.read().is_01() || !add_ln703_676_fu_138627_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_207_fu_135951_p1.read()) + sc_biguint<14>(add_ln703_676_fu_138627_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_678_fu_132291_p2() {
    add_ln703_678_fu_132291_p2 = (!zext_ln1118_755_fu_128238_p1.read().is_01() || !zext_ln1118_754_fu_128234_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_755_fu_128238_p1.read()) + sc_biguint<9>(zext_ln1118_754_fu_128234_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_679_fu_138642_p2() {
    add_ln703_679_fu_138642_p2 = (!zext_ln203_104_fu_135947_p1.read().is_01() || !zext_ln703_105_fu_138639_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_104_fu_135947_p1.read()) + sc_biguint<10>(zext_ln703_105_fu_138639_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_67_fu_122669_p2() {
    add_ln703_67_fu_122669_p2 = (!sext_ln1118_15_fu_118981_p1.read().is_01() || !zext_ln1118_292_fu_118985_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_15_fu_118981_p1.read()) + sc_biguint<12>(zext_ln1118_292_fu_118985_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_680_fu_138652_p2() {
    add_ln703_680_fu_138652_p2 = (!add_ln703_677_fu_138633_p2.read().is_01() || !zext_ln703_106_fu_138648_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_677_fu_138633_p2.read()) + sc_biguint<14>(zext_ln703_106_fu_138648_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_681_fu_132297_p2() {
    add_ln703_681_fu_132297_p2 = (!sext_ln1118_197_fu_128049_p1.read().is_01() || !sext_ln1118_206_fu_128220_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_197_fu_128049_p1.read()) + sc_bigint<11>(sext_ln1118_206_fu_128220_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_682_fu_132307_p2() {
    add_ln703_682_fu_132307_p2 = (!zext_ln1118_757_fu_128277_p1.read().is_01() || !sext_ln703_402_fu_132303_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_757_fu_128277_p1.read()) + sc_bigint<12>(sext_ln703_402_fu_132303_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_683_fu_132317_p2() {
    add_ln703_683_fu_132317_p2 = (!sext_ln1118_180_fu_127804_p1.read().is_01() || !sext_ln708_37_fu_128273_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_180_fu_127804_p1.read()) + sc_bigint<9>(sext_ln708_37_fu_128273_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_684_fu_132327_p2() {
    add_ln703_684_fu_132327_p2 = (!sext_ln1118_208_fu_128242_p1.read().is_01() || !sext_ln703_404_fu_132323_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_208_fu_128242_p1.read()) + sc_bigint<11>(sext_ln703_404_fu_132323_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_685_fu_132337_p2() {
    add_ln703_685_fu_132337_p2 = (!sext_ln703_403_fu_132313_p1.read().is_01() || !sext_ln703_405_fu_132333_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_403_fu_132313_p1.read()) + sc_bigint<13>(sext_ln703_405_fu_132333_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_686_fu_138665_p2() {
    add_ln703_686_fu_138665_p2 = (!sext_ln703_401_fu_138658_p1.read().is_01() || !sext_ln703_406_fu_138662_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_401_fu_138658_p1.read()) + sc_bigint<15>(sext_ln703_406_fu_138662_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_687_fu_138671_p2() {
    add_ln703_687_fu_138671_p2 = (!zext_ln203_35_fu_135974_p1.read().is_01() || !add_ln703_686_fu_138665_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_35_fu_135974_p1.read()) + sc_biguint<15>(add_ln703_686_fu_138665_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_688_fu_138677_p2() {
    add_ln703_688_fu_138677_p2 = (!zext_ln708_332_fu_136005_p1.read().is_01() || !zext_ln708_331_fu_136001_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_332_fu_136005_p1.read()) + sc_biguint<11>(zext_ln708_331_fu_136001_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_689_fu_138683_p2() {
    add_ln703_689_fu_138683_p2 = (!zext_ln708_330_fu_135997_p1.read().is_01() || !add_ln703_688_fu_138677_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_330_fu_135997_p1.read()) + sc_biguint<11>(add_ln703_688_fu_138677_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_68_fu_122675_p2() {
    add_ln703_68_fu_122675_p2 = (!zext_ln703_13_fu_122665_p1.read().is_01() || !add_ln703_67_fu_122669_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_13_fu_122665_p1.read()) + sc_biguint<12>(add_ln703_67_fu_122669_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_690_fu_138693_p2() {
    add_ln703_690_fu_138693_p2 = (!add_ln703_687_fu_138671_p2.read().is_01() || !zext_ln703_107_fu_138689_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_687_fu_138671_p2.read()) + sc_biguint<15>(zext_ln703_107_fu_138689_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_691_fu_138699_p2() {
    add_ln703_691_fu_138699_p2 = (!zext_ln203_106_fu_136056_p1.read().is_01() || !zext_ln203_105_fu_136025_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_106_fu_136056_p1.read()) + sc_biguint<10>(zext_ln203_105_fu_136025_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_692_fu_138709_p2() {
    add_ln703_692_fu_138709_p2 = (!sext_ln203_103_fu_136075_p1.read().is_01() || !sext_ln203_102_fu_135993_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_103_fu_136075_p1.read()) + sc_bigint<9>(sext_ln203_102_fu_135993_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_693_fu_138719_p2() {
    add_ln703_693_fu_138719_p2 = (!sext_ln203_101_fu_135954_p1.read().is_01() || !sext_ln703_407_fu_138715_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_101_fu_135954_p1.read()) + sc_bigint<11>(sext_ln703_407_fu_138715_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_694_fu_138729_p2() {
    add_ln703_694_fu_138729_p2 = (!zext_ln703_108_fu_138705_p1.read().is_01() || !sext_ln703_408_fu_138725_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_108_fu_138705_p1.read()) + sc_bigint<12>(sext_ln703_408_fu_138725_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_696_fu_124184_p2() {
    add_ln703_696_fu_124184_p2 = (!trunc_ln203_8_fu_121799_p4.read().is_01() || !ap_const_lv8_98.is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln203_8_fu_121799_p4.read()) + sc_bigint<8>(ap_const_lv8_98));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_697_fu_124194_p2() {
    add_ln703_697_fu_124194_p2 = (!sext_ln703_103_fu_124190_p1.read().is_01() || !sext_ln203_104_fu_121824_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_103_fu_124190_p1.read()) + sc_bigint<12>(sext_ln203_104_fu_121824_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_698_fu_124200_p2() {
    add_ln703_698_fu_124200_p2 = (!sext_ln708_38_fu_121843_p1.read().is_01() || !add_ln703_697_fu_124194_p2.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_38_fu_121843_p1.read()) + sc_biguint<12>(add_ln703_697_fu_124194_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_699_fu_124210_p2() {
    add_ln703_699_fu_124210_p2 = (!zext_ln1118_761_fu_121847_p1.read().is_01() || !sext_ln1118_210_fu_121881_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_761_fu_121847_p1.read()) + sc_bigint<11>(sext_ln1118_210_fu_121881_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_69_fu_122685_p2() {
    add_ln703_69_fu_122685_p2 = (!add_ln703_65_reg_141657.read().is_01() || !sext_ln703_52_fu_122681_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_65_reg_141657.read()) + sc_bigint<13>(sext_ln703_52_fu_122681_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_6_fu_122547_p2() {
    add_ln703_6_fu_122547_p2 = (!add_ln703_4_fu_122531_p2.read().is_01() || !zext_ln703_3_fu_122543_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_4_fu_122531_p2.read()) + sc_biguint<13>(zext_ln703_3_fu_122543_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_700_fu_124220_p2() {
    add_ln703_700_fu_124220_p2 = (!sext_ln703_411_fu_124206_p1.read().is_01() || !sext_ln703_412_fu_124216_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_411_fu_124206_p1.read()) + sc_bigint<13>(sext_ln703_412_fu_124216_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_701_fu_132343_p2() {
    add_ln703_701_fu_132343_p2 = (!zext_ln1118_763_fu_128284_p1.read().is_01() || !add_ln703_700_reg_142528.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_763_fu_128284_p1.read()) + sc_biguint<13>(add_ln703_700_reg_142528.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_702_fu_132348_p2() {
    add_ln703_702_fu_132348_p2 = (!zext_ln1118_766_fu_128311_p1.read().is_01() || !zext_ln1118_764_fu_128287_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_766_fu_128311_p1.read()) + sc_biguint<10>(zext_ln1118_764_fu_128287_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_703_fu_132358_p2() {
    add_ln703_703_fu_132358_p2 = (!add_ln703_701_fu_132343_p2.read().is_01() || !zext_ln703_109_fu_132354_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_701_fu_132343_p2.read()) + sc_biguint<13>(zext_ln703_109_fu_132354_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_704_fu_132368_p2() {
    add_ln703_704_fu_132368_p2 = (!sext_ln1118_214_fu_128331_p1.read().is_01() || !zext_ln708_334_fu_128335_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_214_fu_128331_p1.read()) + sc_biguint<11>(zext_ln708_334_fu_128335_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_705_fu_124226_p2() {
    add_ln703_705_fu_124226_p2 = (!sext_ln1116_8_fu_119883_p1.read().is_01() || !sext_ln708_39_fu_121901_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_8_fu_119883_p1.read()) + sc_bigint<10>(sext_ln708_39_fu_121901_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_706_fu_132381_p2() {
    add_ln703_706_fu_132381_p2 = (!sext_ln703_414_fu_132374_p1.read().is_01() || !sext_ln703_415_fu_132378_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_414_fu_132374_p1.read()) + sc_bigint<12>(sext_ln703_415_fu_132378_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_707_fu_132391_p2() {
    add_ln703_707_fu_132391_p2 = (!sext_ln703_413_fu_132364_p1.read().is_01() || !sext_ln703_416_fu_132387_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_413_fu_132364_p1.read()) + sc_bigint<14>(sext_ln703_416_fu_132387_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_708_fu_132397_p2() {
    add_ln703_708_fu_132397_p2 = (!sext_ln1118_216_fu_128370_p1.read().is_01() || !add_ln703_707_fu_132391_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_216_fu_128370_p1.read()) + sc_biguint<14>(add_ln703_707_fu_132391_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_709_fu_132403_p2() {
    add_ln703_709_fu_132403_p2 = (!sext_ln1118_220_fu_128395_p1.read().is_01() || !sext_ln1118_219_fu_128391_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_220_fu_128395_p1.read()) + sc_bigint<12>(sext_ln1118_219_fu_128391_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_70_fu_122690_p2() {
    add_ln703_70_fu_122690_p2 = (!zext_ln1116_11_fu_118574_p1.read().is_01() || !add_ln703_69_fu_122685_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1116_11_fu_118574_p1.read()) + sc_biguint<13>(add_ln703_69_fu_122685_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_710_fu_132413_p2() {
    add_ln703_710_fu_132413_p2 = (!sext_ln1118_218_fu_128377_p1.read().is_01() || !sext_ln703_418_fu_132409_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_218_fu_128377_p1.read()) + sc_bigint<13>(sext_ln703_418_fu_132409_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_711_fu_138755_p2() {
    add_ln703_711_fu_138755_p2 = (!sext_ln703_417_fu_138749_p1.read().is_01() || !sext_ln703_419_fu_138752_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_417_fu_138749_p1.read()) + sc_bigint<15>(sext_ln703_419_fu_138752_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_712_fu_132419_p2() {
    add_ln703_712_fu_132419_p2 = (!sext_ln1118_12_fu_124653_p1.read().is_01() || !sext_ln1118_222_fu_128419_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_12_fu_124653_p1.read()) + sc_bigint<12>(sext_ln1118_222_fu_128419_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_713_fu_132429_p2() {
    add_ln703_713_fu_132429_p2 = (!sext_ln1118_221_fu_128415_p1.read().is_01() || !sext_ln1118_217_fu_128374_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_221_fu_128415_p1.read()) + sc_bigint<9>(sext_ln1118_217_fu_128374_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_714_fu_132439_p2() {
    add_ln703_714_fu_132439_p2 = (!zext_ln1118_769_fu_128433_p1.read().is_01() || !sext_ln703_421_fu_132435_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_769_fu_128433_p1.read()) + sc_bigint<10>(sext_ln703_421_fu_132435_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_715_fu_132449_p2() {
    add_ln703_715_fu_132449_p2 = (!sext_ln703_420_fu_132425_p1.read().is_01() || !sext_ln703_422_fu_132445_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_420_fu_132425_p1.read()) + sc_bigint<13>(sext_ln703_422_fu_132445_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_716_fu_138764_p2() {
    add_ln703_716_fu_138764_p2 = (!add_ln703_711_fu_138755_p2.read().is_01() || !sext_ln703_423_fu_138761_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_711_fu_138755_p2.read()) + sc_bigint<15>(sext_ln703_423_fu_138761_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_717_fu_138770_p2() {
    add_ln703_717_fu_138770_p2 = (!sext_ln203_107_fu_136090_p1.read().is_01() || !sext_ln203_106_fu_136079_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_107_fu_136090_p1.read()) + sc_bigint<12>(sext_ln203_106_fu_136079_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_718_fu_138780_p2() {
    add_ln703_718_fu_138780_p2 = (!add_ln703_716_fu_138764_p2.read().is_01() || !sext_ln703_424_fu_138776_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_716_fu_138764_p2.read()) + sc_bigint<15>(sext_ln703_424_fu_138776_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_719_fu_132455_p2() {
    add_ln703_719_fu_132455_p2 = (!zext_ln203_107_fu_128456_p1.read().is_01() || !grp_fu_116297_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_107_fu_128456_p1.read()) + sc_biguint<10>(grp_fu_116297_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_71_fu_130510_p2() {
    add_ln703_71_fu_130510_p2 = (!zext_ln708_28_fu_124872_p1.read().is_01() || !sext_ln1118_16_fu_124795_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_28_fu_124872_p1.read()) + sc_bigint<12>(sext_ln1118_16_fu_124795_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_720_fu_138789_p2() {
    add_ln703_720_fu_138789_p2 = (!sext_ln203_108_fu_136125_p1.read().is_01() || !zext_ln703_110_fu_138786_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_108_fu_136125_p1.read()) + sc_biguint<12>(zext_ln703_110_fu_138786_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_721_fu_138799_p2() {
    add_ln703_721_fu_138799_p2 = (!add_ln703_718_fu_138780_p2.read().is_01() || !sext_ln703_425_fu_138795_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_718_fu_138780_p2.read()) + sc_bigint<15>(sext_ln703_425_fu_138795_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_722_fu_138809_p2() {
    add_ln703_722_fu_138809_p2 = (!zext_ln708_262_fu_134668_p1.read().is_01() || !zext_ln708_336_fu_136086_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_262_fu_134668_p1.read()) + sc_biguint<11>(zext_ln708_336_fu_136086_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_723_fu_138815_p2() {
    add_ln703_723_fu_138815_p2 = (!zext_ln708_335_fu_136082_p1.read().is_01() || !add_ln703_722_fu_138809_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_335_fu_136082_p1.read()) + sc_biguint<11>(add_ln703_722_fu_138809_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_724_fu_132461_p2() {
    add_ln703_724_fu_132461_p2 = (!sext_ln203_105_fu_128437_p1.read().is_01() || !zext_ln708_337_fu_128460_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_105_fu_128437_p1.read()) + sc_biguint<11>(zext_ln708_337_fu_128460_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_725_fu_138828_p2() {
    add_ln703_725_fu_138828_p2 = (!zext_ln203_36_fu_136121_p1.read().is_01() || !sext_ln703_427_fu_138825_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_36_fu_136121_p1.read()) + sc_bigint<12>(sext_ln703_427_fu_138825_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_726_fu_138838_p2() {
    add_ln703_726_fu_138838_p2 = (!zext_ln703_111_fu_138821_p1.read().is_01() || !sext_ln703_428_fu_138834_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_111_fu_138821_p1.read()) + sc_bigint<13>(sext_ln703_428_fu_138834_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_728_fu_132467_p2() {
    add_ln703_728_fu_132467_p2 = (!zext_ln708_338_fu_128468_p1.read().is_01() || !ap_const_lv11_5F8.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_338_fu_128468_p1.read()) + sc_bigint<11>(ap_const_lv11_5F8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_729_fu_132477_p2() {
    add_ln703_729_fu_132477_p2 = (!sext_ln203_109_fu_128464_p1.read().is_01() || !sext_ln703_430_fu_132473_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_109_fu_128464_p1.read()) + sc_bigint<12>(sext_ln703_430_fu_132473_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_72_fu_130520_p2() {
    add_ln703_72_fu_130520_p2 = (!sext_ln703_53_fu_130507_p1.read().is_01() || !sext_ln703_54_fu_130516_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_53_fu_130507_p1.read()) + sc_bigint<14>(sext_ln703_54_fu_130516_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_730_fu_124232_p2() {
    add_ln703_730_fu_124232_p2 = (!sext_ln1118_225_fu_121970_p1.read().is_01() || !sext_ln1118_224_fu_121950_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_225_fu_121970_p1.read()) + sc_bigint<11>(sext_ln1118_224_fu_121950_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_731_fu_132490_p2() {
    add_ln703_731_fu_132490_p2 = (!sext_ln703_108_fu_132483_p1.read().is_01() || !sext_ln703_431_fu_132487_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_108_fu_132483_p1.read()) + sc_bigint<13>(sext_ln703_431_fu_132487_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_732_fu_132496_p2() {
    add_ln703_732_fu_132496_p2 = (!zext_ln1118_772_fu_128475_p1.read().is_01() || !add_ln703_731_fu_132490_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_772_fu_128475_p1.read()) + sc_biguint<13>(add_ln703_731_fu_132490_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_733_fu_132502_p2() {
    add_ln703_733_fu_132502_p2 = (!zext_ln708_339_fu_128478_p1.read().is_01() || !zext_ln708_333_fu_128281_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_339_fu_128478_p1.read()) + sc_biguint<11>(zext_ln708_333_fu_128281_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_734_fu_138857_p2() {
    add_ln703_734_fu_138857_p2 = (!add_ln703_732_reg_143098.read().is_01() || !zext_ln703_112_fu_138854_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_732_reg_143098.read()) + sc_biguint<13>(zext_ln703_112_fu_138854_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_735_fu_132508_p2() {
    add_ln703_735_fu_132508_p2 = (!sext_ln1118_228_fu_128495_p1.read().is_01() || !zext_ln1118_774_fu_128491_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_228_fu_128495_p1.read()) + sc_biguint<10>(zext_ln1118_774_fu_128491_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_736_fu_132518_p2() {
    add_ln703_736_fu_132518_p2 = (!sext_ln1118_226_fu_128472_p1.read().is_01() || !sext_ln1118_229_fu_128517_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_226_fu_128472_p1.read()) + sc_bigint<10>(sext_ln1118_229_fu_128517_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_737_fu_132528_p2() {
    add_ln703_737_fu_132528_p2 = (!sext_ln703_432_fu_132514_p1.read().is_01() || !sext_ln703_433_fu_132524_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_432_fu_132514_p1.read()) + sc_bigint<11>(sext_ln703_433_fu_132524_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_738_fu_138865_p2() {
    add_ln703_738_fu_138865_p2 = (!add_ln703_734_fu_138857_p2.read().is_01() || !sext_ln703_434_fu_138862_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_734_fu_138857_p2.read()) + sc_bigint<13>(sext_ln703_434_fu_138862_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_739_fu_132534_p2() {
    add_ln703_739_fu_132534_p2 = (!sext_ln1118_234_fu_128575_p1.read().is_01() || !sext_ln1118_215_fu_128366_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_234_fu_128575_p1.read()) + sc_bigint<12>(sext_ln1118_215_fu_128366_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_73_fu_130526_p2() {
    add_ln703_73_fu_130526_p2 = (!zext_ln1118_539_fu_124909_p1.read().is_01() || !trunc_ln1118_6_reg_141189.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_539_fu_124909_p1.read()) + sc_biguint<10>(trunc_ln1118_6_reg_141189.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_740_fu_138878_p2() {
    add_ln703_740_fu_138878_p2 = (!sext_ln703_435_fu_138871_p1.read().is_01() || !sext_ln703_436_fu_138875_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_435_fu_138871_p1.read()) + sc_bigint<14>(sext_ln703_436_fu_138875_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_741_fu_132540_p2() {
    add_ln703_741_fu_132540_p2 = (!grp_fu_115907_p4.read().is_01() || !zext_ln1118_776_fu_128521_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115907_p4.read()) + sc_biguint<10>(zext_ln1118_776_fu_128521_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_742_fu_132550_p2() {
    add_ln703_742_fu_132550_p2 = (!sext_ln708_40_fu_128609_p1.read().is_01() || !zext_ln703_113_fu_132546_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_40_fu_128609_p1.read()) + sc_biguint<12>(zext_ln703_113_fu_132546_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_743_fu_138887_p2() {
    add_ln703_743_fu_138887_p2 = (!add_ln703_740_fu_138878_p2.read().is_01() || !sext_ln703_437_fu_138884_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_740_fu_138878_p2.read()) + sc_bigint<14>(sext_ln703_437_fu_138884_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_744_fu_132556_p2() {
    add_ln703_744_fu_132556_p2 = (!zext_ln708_342_fu_128632_p1.read().is_01() || !zext_ln708_341_fu_128628_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_342_fu_128632_p1.read()) + sc_biguint<11>(zext_ln708_341_fu_128628_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_745_fu_132562_p2() {
    add_ln703_745_fu_132562_p2 = (!zext_ln708_340_fu_128529_p1.read().is_01() || !add_ln703_744_fu_132556_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_340_fu_128529_p1.read()) + sc_biguint<11>(add_ln703_744_fu_132556_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_746_fu_132572_p2() {
    add_ln703_746_fu_132572_p2 = (!sext_ln1118_230_fu_128525_p1.read().is_01() || !sext_ln1118_233_fu_128571_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_230_fu_128525_p1.read()) + sc_bigint<11>(sext_ln1118_233_fu_128571_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_747_fu_132582_p2() {
    add_ln703_747_fu_132582_p2 = (!sext_ln1118_232_fu_128557_p1.read().is_01() || !sext_ln703_439_fu_132578_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_232_fu_128557_p1.read()) + sc_bigint<12>(sext_ln703_439_fu_132578_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_748_fu_132592_p2() {
    add_ln703_748_fu_132592_p2 = (!zext_ln703_114_fu_132568_p1.read().is_01() || !sext_ln703_440_fu_132588_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_114_fu_132568_p1.read()) + sc_bigint<13>(sext_ln703_440_fu_132588_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_749_fu_138900_p2() {
    add_ln703_749_fu_138900_p2 = (!sext_ln703_438_fu_138893_p1.read().is_01() || !sext_ln703_441_fu_138897_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_438_fu_138893_p1.read()) + sc_bigint<15>(sext_ln703_441_fu_138897_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_74_fu_130535_p2() {
    add_ln703_74_fu_130535_p2 = (!sext_ln708_4_fu_124798_p1.read().is_01() || !zext_ln708_231_fu_124876_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln708_4_fu_124798_p1.read()) + sc_biguint<8>(zext_ln708_231_fu_124876_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_750_fu_138906_p2() {
    add_ln703_750_fu_138906_p2 = (!sext_ln203_110_fu_136139_p1.read().is_01() || !add_ln703_749_fu_138900_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_110_fu_136139_p1.read()) + sc_biguint<15>(add_ln703_749_fu_138900_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_751_fu_138912_p2() {
    add_ln703_751_fu_138912_p2 = (!zext_ln708_344_fu_136173_p1.read().is_01() || !zext_ln708_343_fu_136169_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_344_fu_136173_p1.read()) + sc_biguint<11>(zext_ln708_343_fu_136169_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_752_fu_138922_p2() {
    add_ln703_752_fu_138922_p2 = (!sext_ln203_113_fu_136265_p1.read().is_01() || !zext_ln703_115_fu_138918_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_113_fu_136265_p1.read()) + sc_biguint<13>(zext_ln703_115_fu_138918_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_753_fu_138932_p2() {
    add_ln703_753_fu_138932_p2 = (!add_ln703_750_fu_138906_p2.read().is_01() || !sext_ln703_442_fu_138928_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_750_fu_138906_p2.read()) + sc_bigint<15>(sext_ln703_442_fu_138928_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_754_fu_138938_p2() {
    add_ln703_754_fu_138938_p2 = (!zext_ln708_346_fu_136257_p1.read().is_01() || !zext_ln708_345_fu_136197_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_346_fu_136257_p1.read()) + sc_biguint<11>(zext_ln708_345_fu_136197_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_755_fu_138948_p2() {
    add_ln703_755_fu_138948_p2 = (!sext_ln203_111_fu_136231_p1.read().is_01() || !sext_ln203_114_fu_136269_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_111_fu_136231_p1.read()) + sc_bigint<11>(sext_ln203_114_fu_136269_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_756_fu_138958_p2() {
    add_ln703_756_fu_138958_p2 = (!sext_ln203_112_fu_136261_p1.read().is_01() || !sext_ln703_443_fu_138954_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_112_fu_136261_p1.read()) + sc_bigint<12>(sext_ln703_443_fu_138954_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_757_fu_138968_p2() {
    add_ln703_757_fu_138968_p2 = (!zext_ln703_116_fu_138944_p1.read().is_01() || !sext_ln703_444_fu_138964_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_116_fu_138944_p1.read()) + sc_bigint<13>(sext_ln703_444_fu_138964_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_759_fu_124238_p2() {
    add_ln703_759_fu_124238_p2 = (!trunc_ln1118_38_fu_122088_p4.read().is_01() || !zext_ln1116_65_fu_122075_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_38_fu_122088_p4.read()) + sc_biguint<10>(zext_ln1116_65_fu_122075_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_75_fu_130541_p2() {
    add_ln703_75_fu_130541_p2 = (!zext_ln1118_536_fu_124827_p1.read().is_01() || !add_ln703_74_fu_130535_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln1118_536_fu_124827_p1.read()) + sc_biguint<8>(add_ln703_74_fu_130535_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_760_fu_132601_p2() {
    add_ln703_760_fu_132601_p2 = (!zext_ln703_117_fu_132598_p1.read().is_01() || !ap_const_lv11_560.is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_117_fu_132598_p1.read()) + sc_bigint<11>(ap_const_lv11_560));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_761_fu_132611_p2() {
    add_ln703_761_fu_132611_p2 = (!sext_ln1116_24_fu_128636_p1.read().is_01() || !zext_ln1116_66_fu_128653_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_24_fu_128636_p1.read()) + sc_biguint<10>(zext_ln1116_66_fu_128653_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_762_fu_132621_p2() {
    add_ln703_762_fu_132621_p2 = (!zext_ln708_347_fu_128649_p1.read().is_01() || !sext_ln703_448_fu_132617_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_347_fu_128649_p1.read()) + sc_bigint<11>(sext_ln703_448_fu_132617_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_763_fu_132631_p2() {
    add_ln703_763_fu_132631_p2 = (!sext_ln703_447_fu_132607_p1.read().is_01() || !sext_ln703_449_fu_132627_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_447_fu_132607_p1.read()) + sc_bigint<12>(sext_ln703_449_fu_132627_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_764_fu_132637_p2() {
    add_ln703_764_fu_132637_p2 = (!zext_ln708_158_fu_128666_p1.read().is_01() || !add_ln703_763_fu_132631_p2.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln708_158_fu_128666_p1.read()) + sc_biguint<12>(add_ln703_763_fu_132631_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_765_fu_124244_p2() {
    add_ln703_765_fu_124244_p2 = (!zext_ln1116_67_fu_122121_p1.read().is_01() || !zext_ln1118_716_fu_121377_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_67_fu_122121_p1.read()) + sc_biguint<10>(zext_ln1118_716_fu_121377_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_766_fu_132650_p2() {
    add_ln703_766_fu_132650_p2 = (!sext_ln703_450_fu_132643_p1.read().is_01() || !zext_ln703_118_fu_132647_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_450_fu_132643_p1.read()) + sc_biguint<13>(zext_ln703_118_fu_132647_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_767_fu_138988_p2() {
    add_ln703_767_fu_138988_p2 = (!zext_ln1118_782_fu_136272_p1.read().is_01() || !add_ln703_766_reg_143128.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_782_fu_136272_p1.read()) + sc_biguint<13>(add_ln703_766_reg_143128.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_768_fu_132656_p2() {
    add_ln703_768_fu_132656_p2 = (!zext_ln1118_784_fu_128748_p1.read().is_01() || !zext_ln1118_783_fu_128736_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_784_fu_128748_p1.read()) + sc_biguint<10>(zext_ln1118_783_fu_128736_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_769_fu_138996_p2() {
    add_ln703_769_fu_138996_p2 = (!add_ln703_767_fu_138988_p2.read().is_01() || !zext_ln703_119_fu_138993_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_767_fu_138988_p2.read()) + sc_biguint<13>(zext_ln703_119_fu_138993_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_76_fu_130551_p2() {
    add_ln703_76_fu_130551_p2 = (!zext_ln703_14_fu_130531_p1.read().is_01() || !sext_ln703_55_fu_130547_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_14_fu_130531_p1.read()) + sc_bigint<12>(sext_ln703_55_fu_130547_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_770_fu_132662_p2() {
    add_ln703_770_fu_132662_p2 = (!sext_ln708_41_fu_128744_p1.read().is_01() || !sext_ln1118_239_fu_128707_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln708_41_fu_128744_p1.read()) + sc_bigint<11>(sext_ln1118_239_fu_128707_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_771_fu_132672_p2() {
    add_ln703_771_fu_132672_p2 = (!sext_ln1116_25_fu_128752_p1.read().is_01() || !zext_ln708_348_fu_128740_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1116_25_fu_128752_p1.read()) + sc_biguint<9>(zext_ln708_348_fu_128740_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_772_fu_132682_p2() {
    add_ln703_772_fu_132682_p2 = (!sext_ln703_452_fu_132668_p1.read().is_01() || !sext_ln703_453_fu_132678_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_452_fu_132668_p1.read()) + sc_bigint<12>(sext_ln703_453_fu_132678_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_773_fu_139009_p2() {
    add_ln703_773_fu_139009_p2 = (!sext_ln703_451_fu_139002_p1.read().is_01() || !sext_ln703_454_fu_139006_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_451_fu_139002_p1.read()) + sc_bigint<14>(sext_ln703_454_fu_139006_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_774_fu_139015_p2() {
    add_ln703_774_fu_139015_p2 = (!sext_ln1118_207_fu_135951_p1.read().is_01() || !add_ln703_773_fu_139009_p2.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_207_fu_135951_p1.read()) + sc_biguint<14>(add_ln703_773_fu_139009_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_775_fu_132688_p2() {
    add_ln703_775_fu_132688_p2 = (!sext_ln1118_243_fu_128817_p1.read().is_01() || !sext_ln1116_29_fu_128793_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_243_fu_128817_p1.read()) + sc_bigint<12>(sext_ln1116_29_fu_128793_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_776_fu_139024_p2() {
    add_ln703_776_fu_139024_p2 = (!add_ln703_774_fu_139015_p2.read().is_01() || !sext_ln703_455_fu_139021_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_774_fu_139015_p2.read()) + sc_bigint<14>(sext_ln703_455_fu_139021_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_777_fu_132694_p2() {
    add_ln703_777_fu_132694_p2 = (!grp_fu_116387_p4.read().is_01() || !zext_ln1118_755_fu_128238_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(grp_fu_116387_p4.read()) + sc_biguint<9>(zext_ln1118_755_fu_128238_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_778_fu_132704_p2() {
    add_ln703_778_fu_132704_p2 = (!zext_ln1116_71_fu_128855_p1.read().is_01() || !zext_ln1116_70_fu_128831_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1116_71_fu_128855_p1.read()) + sc_biguint<10>(zext_ln1116_70_fu_128831_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_779_fu_132714_p2() {
    add_ln703_779_fu_132714_p2 = (!zext_ln703_120_fu_132700_p1.read().is_01() || !zext_ln703_121_fu_132710_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_120_fu_132700_p1.read()) + sc_biguint<11>(zext_ln703_121_fu_132710_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_77_fu_130561_p2() {
    add_ln703_77_fu_130561_p2 = (!add_ln703_72_fu_130520_p2.read().is_01() || !sext_ln703_56_fu_130557_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_72_fu_130520_p2.read()) + sc_bigint<14>(sext_ln703_56_fu_130557_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_780_fu_139037_p2() {
    add_ln703_780_fu_139037_p2 = (!sext_ln703_456_fu_139030_p1.read().is_01() || !zext_ln703_122_fu_139034_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_456_fu_139030_p1.read()) + sc_biguint<15>(zext_ln703_122_fu_139034_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_781_fu_139043_p2() {
    add_ln703_781_fu_139043_p2 = (!trunc_ln1118_39_fu_136299_p4.read().is_01() || !zext_ln708_349_fu_136289_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln1118_39_fu_136299_p4.read()) + sc_biguint<9>(zext_ln708_349_fu_136289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_782_fu_139053_p2() {
    add_ln703_782_fu_139053_p2 = (!sext_ln1118_241_fu_136278_p1.read().is_01() || !zext_ln708_263_fu_134703_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_241_fu_136278_p1.read()) + sc_biguint<11>(zext_ln708_263_fu_134703_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_783_fu_139063_p2() {
    add_ln703_783_fu_139063_p2 = (!zext_ln703_123_fu_139049_p1.read().is_01() || !sext_ln703_457_fu_139059_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_123_fu_139049_p1.read()) + sc_bigint<12>(sext_ln703_457_fu_139059_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_784_fu_132720_p2() {
    add_ln703_784_fu_132720_p2 = (!sext_ln1116_28_fu_128789_p1.read().is_01() || !sext_ln1118_196_fu_128021_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1116_28_fu_128789_p1.read()) + sc_bigint<9>(sext_ln1118_196_fu_128021_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_785_fu_139072_p2() {
    add_ln703_785_fu_139072_p2 = (!zext_ln1118_204_fu_133722_p1.read().is_01() || !zext_ln1116_69_fu_136282_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_204_fu_133722_p1.read()) + sc_biguint<9>(zext_ln1116_69_fu_136282_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_786_fu_139082_p2() {
    add_ln703_786_fu_139082_p2 = (!sext_ln703_458_fu_139069_p1.read().is_01() || !zext_ln703_124_fu_139078_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_458_fu_139069_p1.read()) + sc_biguint<11>(zext_ln703_124_fu_139078_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_787_fu_139092_p2() {
    add_ln703_787_fu_139092_p2 = (!add_ln703_783_fu_139063_p2.read().is_01() || !sext_ln703_459_fu_139088_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_783_fu_139063_p2.read()) + sc_bigint<12>(sext_ln703_459_fu_139088_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_788_fu_139102_p2() {
    add_ln703_788_fu_139102_p2 = (!add_ln703_780_fu_139037_p2.read().is_01() || !sext_ln703_460_fu_139098_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_780_fu_139037_p2.read()) + sc_bigint<15>(sext_ln703_460_fu_139098_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_789_fu_139108_p2() {
    add_ln703_789_fu_139108_p2 = (!sext_ln203_116_fu_136313_p1.read().is_01() || !sext_ln203_115_fu_136309_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_116_fu_136313_p1.read()) + sc_bigint<12>(sext_ln203_115_fu_136309_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_78_fu_130567_p2() {
    add_ln703_78_fu_130567_p2 = (!sext_ln1118_19_fu_124999_p1.read().is_01() || !sext_ln1118_17_fu_124913_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_19_fu_124999_p1.read()) + sc_bigint<12>(sext_ln1118_17_fu_124913_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_791_fu_132726_p2() {
    add_ln703_791_fu_132726_p2 = (!sext_ln203_117_fu_128869_p1.read().is_01() || !ap_const_lv12_D68.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_117_fu_128869_p1.read()) + sc_bigint<12>(ap_const_lv12_D68));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_792_fu_132736_p2() {
    add_ln703_792_fu_132736_p2 = (!sext_ln203_30_fu_125575_p1.read().is_01() || !sext_ln703_116_fu_132732_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_30_fu_125575_p1.read()) + sc_bigint<13>(sext_ln703_116_fu_132732_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_793_fu_124250_p2() {
    add_ln703_793_fu_124250_p2 = (!zext_ln1118_791_fu_122173_p1.read().is_01() || !sext_ln1118_244_fu_122149_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_791_fu_122173_p1.read()) + sc_bigint<12>(sext_ln1118_244_fu_122149_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_794_fu_132745_p2() {
    add_ln703_794_fu_132745_p2 = (!add_ln703_792_fu_132736_p2.read().is_01() || !sext_ln703_463_fu_132742_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_792_fu_132736_p2.read()) + sc_bigint<13>(sext_ln703_463_fu_132742_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_795_fu_132755_p2() {
    add_ln703_795_fu_132755_p2 = (!sext_ln203_119_fu_128883_p1.read().is_01() || !sext_ln703_117_fu_132751_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_119_fu_128883_p1.read()) + sc_bigint<14>(sext_ln703_117_fu_132751_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_796_fu_132761_p2() {
    add_ln703_796_fu_132761_p2 = (!zext_ln1118_792_fu_128887_p1.read().is_01() || !trunc_ln1118_40_fu_128873_p4.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_792_fu_128887_p1.read()) + sc_biguint<10>(trunc_ln1118_40_fu_128873_p4.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_797_fu_132771_p2() {
    add_ln703_797_fu_132771_p2 = (!zext_ln708_316_fu_127851_p1.read().is_01() || !zext_ln703_125_fu_132767_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_316_fu_127851_p1.read()) + sc_biguint<11>(zext_ln703_125_fu_132767_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_798_fu_139131_p2() {
    add_ln703_798_fu_139131_p2 = (!add_ln703_795_reg_143158.read().is_01() || !zext_ln703_126_fu_139128_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_795_reg_143158.read()) + sc_biguint<14>(zext_ln703_126_fu_139128_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_799_fu_132777_p2() {
    add_ln703_799_fu_132777_p2 = (!trunc_ln1118_41_fu_128940_p4.read().is_01() || !zext_ln708_351_fu_128915_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(trunc_ln1118_41_fu_128940_p4.read()) + sc_biguint<10>(zext_ln708_351_fu_128915_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_79_fu_130577_p2() {
    add_ln703_79_fu_130577_p2 = (!add_ln703_77_fu_130561_p2.read().is_01() || !sext_ln703_60_fu_130573_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_77_fu_130561_p2.read()) + sc_bigint<14>(sext_ln703_60_fu_130573_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_7_fu_122553_p2() {
    add_ln703_7_fu_122553_p2 = (!zext_ln1116_52_fu_118664_p1.read().is_01() || !zext_ln1116_50_fu_118577_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1116_52_fu_118664_p1.read()) + sc_biguint<9>(zext_ln1116_50_fu_118577_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_800_fu_132787_p2() {
    add_ln703_800_fu_132787_p2 = (!zext_ln708_350_fu_128911_p1.read().is_01() || !zext_ln703_127_fu_132783_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_350_fu_128911_p1.read()) + sc_biguint<11>(zext_ln703_127_fu_132783_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_801_fu_124256_p2() {
    add_ln703_801_fu_124256_p2 = (!zext_ln1118_85_fu_118565_p1.read().is_01() || !sext_ln1118_245_fu_122177_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_85_fu_118565_p1.read()) + sc_bigint<10>(sext_ln1118_245_fu_122177_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_802_fu_124266_p2() {
    add_ln703_802_fu_124266_p2 = (!zext_ln708_221_reg_140870.read().is_01() || !sext_ln703_464_fu_124262_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_221_reg_140870.read()) + sc_bigint<11>(sext_ln703_464_fu_124262_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_803_fu_132800_p2() {
    add_ln703_803_fu_132800_p2 = (!zext_ln703_128_fu_132793_p1.read().is_01() || !sext_ln703_465_fu_132797_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_128_fu_132793_p1.read()) + sc_bigint<13>(sext_ln703_465_fu_132797_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_804_fu_139139_p2() {
    add_ln703_804_fu_139139_p2 = (!add_ln703_798_fu_139131_p2.read().is_01() || !sext_ln703_466_fu_139136_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_798_fu_139131_p2.read()) + sc_bigint<14>(sext_ln703_466_fu_139136_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_805_fu_139149_p2() {
    add_ln703_805_fu_139149_p2 = (!sext_ln1118_248_fu_136317_p1.read().is_01() || !sext_ln1116_26_fu_136275_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_248_fu_136317_p1.read()) + sc_bigint<12>(sext_ln1116_26_fu_136275_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_806_fu_139159_p2() {
    add_ln703_806_fu_139159_p2 = (!sext_ln703_118_fu_139145_p1.read().is_01() || !sext_ln703_467_fu_139155_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_118_fu_139145_p1.read()) + sc_bigint<15>(sext_ln703_467_fu_139155_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_807_fu_132806_p2() {
    add_ln703_807_fu_132806_p2 = (!zext_ln708_289_fu_127051_p1.read().is_01() || !zext_ln708_352_fu_128970_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_289_fu_127051_p1.read()) + sc_biguint<11>(zext_ln708_352_fu_128970_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_808_fu_139168_p2() {
    add_ln703_808_fu_139168_p2 = (!sext_ln708_42_fu_136321_p1.read().is_01() || !zext_ln703_129_fu_139165_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln708_42_fu_136321_p1.read()) + sc_biguint<13>(zext_ln703_129_fu_139165_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_809_fu_139178_p2() {
    add_ln703_809_fu_139178_p2 = (!add_ln703_806_fu_139159_p2.read().is_01() || !sext_ln703_468_fu_139174_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_806_fu_139159_p2.read()) + sc_bigint<15>(sext_ln703_468_fu_139174_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_80_fu_118111_p2() {
    add_ln703_80_fu_118111_p2 = (!sext_ln1118_23_fu_117216_p1.read().is_01() || !sext_ln1118_22_fu_117212_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_23_fu_117216_p1.read()) + sc_bigint<12>(sext_ln1118_22_fu_117212_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_810_fu_132812_p2() {
    add_ln703_810_fu_132812_p2 = (!zext_ln708_356_fu_129023_p1.read().is_01() || !zext_ln708_354_fu_129019_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_356_fu_129023_p1.read()) + sc_biguint<11>(zext_ln708_354_fu_129019_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_811_fu_132818_p2() {
    add_ln703_811_fu_132818_p2 = (!zext_ln708_353_fu_129005_p1.read().is_01() || !add_ln703_810_fu_132812_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_353_fu_129005_p1.read()) + sc_biguint<11>(add_ln703_810_fu_132812_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_812_fu_132828_p2() {
    add_ln703_812_fu_132828_p2 = (!zext_ln708_173_fu_128950_p1.read().is_01() || !zext_ln708_223_fu_124376_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_173_fu_128950_p1.read()) + sc_biguint<10>(zext_ln708_223_fu_124376_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_813_fu_124271_p2() {
    add_ln703_813_fu_124271_p2 = (!sext_ln1118_247_fu_122217_p1.read().is_01() || !zext_ln708_355_fu_122221_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_247_fu_122217_p1.read()) + sc_biguint<8>(zext_ln708_355_fu_122221_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_814_fu_132841_p2() {
    add_ln703_814_fu_132841_p2 = (!zext_ln703_131_fu_132834_p1.read().is_01() || !sext_ln703_469_fu_132838_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_131_fu_132834_p1.read()) + sc_bigint<11>(sext_ln703_469_fu_132838_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_815_fu_132851_p2() {
    add_ln703_815_fu_132851_p2 = (!zext_ln703_130_fu_132824_p1.read().is_01() || !sext_ln703_470_fu_132847_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_130_fu_132824_p1.read()) + sc_bigint<13>(sext_ln703_470_fu_132847_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_816_fu_139187_p2() {
    add_ln703_816_fu_139187_p2 = (!add_ln703_809_fu_139178_p2.read().is_01() || !sext_ln703_471_fu_139184_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_809_fu_139178_p2.read()) + sc_bigint<15>(sext_ln703_471_fu_139184_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_817_fu_139193_p2() {
    add_ln703_817_fu_139193_p2 = (!zext_ln708_358_fu_136386_p1.read().is_01() || !zext_ln708_357_fu_136375_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_358_fu_136386_p1.read()) + sc_biguint<11>(zext_ln708_357_fu_136375_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_818_fu_139203_p2() {
    add_ln703_818_fu_139203_p2 = (!add_ln703_816_fu_139187_p2.read().is_01() || !zext_ln703_132_fu_139199_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_816_fu_139187_p2.read()) + sc_biguint<15>(zext_ln703_132_fu_139199_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_819_fu_139209_p2() {
    add_ln703_819_fu_139209_p2 = (!sext_ln203_122_fu_136379_p1.read().is_01() || !sext_ln203_121_fu_136355_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_122_fu_136379_p1.read()) + sc_bigint<11>(sext_ln203_121_fu_136355_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_81_fu_130590_p2() {
    add_ln703_81_fu_130590_p2 = (!sext_ln1118_21_fu_125072_p1.read().is_01() || !sext_ln703_63_fu_130587_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_21_fu_125072_p1.read()) + sc_bigint<13>(sext_ln703_63_fu_130587_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_820_fu_139219_p2() {
    add_ln703_820_fu_139219_p2 = (!zext_ln203_37_fu_136383_p1.read().is_01() || !sext_ln203_120_fu_136341_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln203_37_fu_136383_p1.read()) + sc_bigint<10>(sext_ln203_120_fu_136341_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_821_fu_139229_p2() {
    add_ln703_821_fu_139229_p2 = (!sext_ln703_472_fu_139215_p1.read().is_01() || !sext_ln703_473_fu_139225_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_472_fu_139215_p1.read()) + sc_bigint<12>(sext_ln703_473_fu_139225_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_823_fu_132857_p2() {
    add_ln703_823_fu_132857_p2 = (!grp_fu_116427_p4.read().is_01() || !ap_const_lv8_A0.is_01())? sc_lv<8>(): (sc_biguint<8>(grp_fu_116427_p4.read()) + sc_bigint<8>(ap_const_lv8_A0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_824_fu_132867_p2() {
    add_ln703_824_fu_132867_p2 = (!sext_ln203_44_reg_141999.read().is_01() || !sext_ln703_476_fu_132863_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_44_reg_141999.read()) + sc_bigint<12>(sext_ln703_476_fu_132863_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_825_fu_132876_p2() {
    add_ln703_825_fu_132876_p2 = (!sext_ln203_124_fu_129091_p1.read().is_01() || !sext_ln703_120_fu_132872_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_124_fu_129091_p1.read()) + sc_bigint<13>(sext_ln703_120_fu_132872_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_826_fu_132882_p2() {
    add_ln703_826_fu_132882_p2 = (!zext_ln708_360_fu_129045_p1.read().is_01() || !zext_ln708_359_fu_129041_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln708_360_fu_129045_p1.read()) + sc_biguint<9>(zext_ln708_359_fu_129041_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_827_fu_139252_p2() {
    add_ln703_827_fu_139252_p2 = (!add_ln703_825_reg_143183.read().is_01() || !zext_ln703_133_fu_139249_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_825_reg_143183.read()) + sc_biguint<13>(zext_ln703_133_fu_139249_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_828_fu_132888_p2() {
    add_ln703_828_fu_132888_p2 = (!sext_ln1118_249_fu_129027_p1.read().is_01() || !zext_ln708_361_fu_129049_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_249_fu_129027_p1.read()) + sc_biguint<11>(zext_ln708_361_fu_129049_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_829_fu_118421_p2() {
    add_ln703_829_fu_118421_p2 = (!zext_ln708_362_fu_117967_p1.read().is_01() || !zext_ln1118_797_fu_117953_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln708_362_fu_117967_p1.read()) + sc_biguint<7>(zext_ln1118_797_fu_117953_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_82_fu_130600_p2() {
    add_ln703_82_fu_130600_p2 = (!sext_ln703_62_fu_130583_p1.read().is_01() || !sext_ln703_64_fu_130596_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_62_fu_130583_p1.read()) + sc_bigint<15>(sext_ln703_64_fu_130596_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_830_fu_118427_p2() {
    add_ln703_830_fu_118427_p2 = (!zext_ln1118_796_fu_117939_p1.read().is_01() || !add_ln703_829_fu_118421_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1118_796_fu_117939_p1.read()) + sc_biguint<7>(add_ln703_829_fu_118421_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_831_fu_132897_p2() {
    add_ln703_831_fu_132897_p2 = (!add_ln703_828_fu_132888_p2.read().is_01() || !zext_ln703_134_fu_132894_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(add_ln703_828_fu_132888_p2.read()) + sc_biguint<11>(zext_ln703_134_fu_132894_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_832_fu_139260_p2() {
    add_ln703_832_fu_139260_p2 = (!add_ln703_827_fu_139252_p2.read().is_01() || !sext_ln703_477_fu_139257_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_827_fu_139252_p2.read()) + sc_bigint<13>(sext_ln703_477_fu_139257_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_833_fu_139270_p2() {
    add_ln703_833_fu_139270_p2 = (!zext_ln203_38_fu_136390_p1.read().is_01() || !sext_ln703_121_fu_139266_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln203_38_fu_136390_p1.read()) + sc_bigint<14>(sext_ln703_121_fu_139266_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_834_fu_132903_p2() {
    add_ln703_834_fu_132903_p2 = (!zext_ln1118_800_fu_129099_p1.read().is_01() || !zext_ln708_273_fu_126420_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_800_fu_129099_p1.read()) + sc_biguint<10>(zext_ln708_273_fu_126420_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_835_fu_139279_p2() {
    add_ln703_835_fu_139279_p2 = (!add_ln703_833_fu_139270_p2.read().is_01() || !zext_ln703_135_fu_139276_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_833_fu_139270_p2.read()) + sc_biguint<14>(zext_ln703_135_fu_139276_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_836_fu_132909_p2() {
    add_ln703_836_fu_132909_p2 = (!zext_ln1118_802_fu_129107_p1.read().is_01() || !zext_ln1118_801_fu_129103_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln1118_802_fu_129107_p1.read()) + sc_biguint<9>(zext_ln1118_801_fu_129103_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_837_fu_132919_p2() {
    add_ln703_837_fu_132919_p2 = (!sext_ln1118_250_fu_129095_p1.read().is_01() || !zext_ln708_363_fu_129127_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_250_fu_129095_p1.read()) + sc_biguint<11>(zext_ln708_363_fu_129127_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_838_fu_132929_p2() {
    add_ln703_838_fu_132929_p2 = (!zext_ln703_136_fu_132915_p1.read().is_01() || !sext_ln703_478_fu_132925_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_136_fu_132915_p1.read()) + sc_bigint<12>(sext_ln703_478_fu_132925_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_839_fu_139288_p2() {
    add_ln703_839_fu_139288_p2 = (!add_ln703_835_fu_139279_p2.read().is_01() || !sext_ln703_479_fu_139285_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_835_fu_139279_p2.read()) + sc_bigint<14>(sext_ln703_479_fu_139285_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_83_fu_130606_p2() {
    add_ln703_83_fu_130606_p2 = (!zext_ln708_232_fu_125037_p1.read().is_01() || !zext_ln1118_541_fu_125003_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_232_fu_125037_p1.read()) + sc_biguint<10>(zext_ln1118_541_fu_125003_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_840_fu_132935_p2() {
    add_ln703_840_fu_132935_p2 = (!sext_ln1118_256_fu_129234_p1.read().is_01() || !sext_ln203_13_fu_125175_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_256_fu_129234_p1.read()) + sc_bigint<12>(sext_ln203_13_fu_125175_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_841_fu_139301_p2() {
    add_ln703_841_fu_139301_p2 = (!sext_ln703_122_fu_139294_p1.read().is_01() || !sext_ln703_480_fu_139298_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_122_fu_139294_p1.read()) + sc_bigint<15>(sext_ln703_480_fu_139298_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_842_fu_132941_p2() {
    add_ln703_842_fu_132941_p2 = (!grp_fu_116637_p4.read().is_01() || !zext_ln1118_804_fu_129181_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_116637_p4.read()) + sc_biguint<10>(zext_ln1118_804_fu_129181_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_843_fu_139310_p2() {
    add_ln703_843_fu_139310_p2 = (!sext_ln1118_257_fu_136412_p1.read().is_01() || !zext_ln703_137_fu_139307_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_257_fu_136412_p1.read()) + sc_biguint<12>(zext_ln703_137_fu_139307_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_844_fu_139320_p2() {
    add_ln703_844_fu_139320_p2 = (!add_ln703_841_fu_139301_p2.read().is_01() || !sext_ln703_481_fu_139316_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_841_fu_139301_p2.read()) + sc_bigint<15>(sext_ln703_481_fu_139316_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_845_fu_132947_p2() {
    add_ln703_845_fu_132947_p2 = (!zext_ln1118_807_fu_129238_p1.read().is_01() || !zext_ln1118_805_fu_129193_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_807_fu_129238_p1.read()) + sc_biguint<10>(zext_ln1118_805_fu_129193_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_846_fu_132957_p2() {
    add_ln703_846_fu_132957_p2 = (!zext_ln708_364_fu_129189_p1.read().is_01() || !zext_ln703_138_fu_132953_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_364_fu_129189_p1.read()) + sc_biguint<11>(zext_ln703_138_fu_132953_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_847_fu_132963_p2() {
    add_ln703_847_fu_132963_p2 = (!sext_ln708_43_fu_129185_p1.read().is_01() || !sext_ln1118_252_fu_129157_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln708_43_fu_129185_p1.read()) + sc_bigint<9>(sext_ln1118_252_fu_129157_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_848_fu_139332_p2() {
    add_ln703_848_fu_139332_p2 = (!sext_ln1118_254_fu_136408_p1.read().is_01() || !sext_ln703_482_fu_139329_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_254_fu_136408_p1.read()) + sc_bigint<10>(sext_ln703_482_fu_139329_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_849_fu_139342_p2() {
    add_ln703_849_fu_139342_p2 = (!zext_ln703_139_fu_139326_p1.read().is_01() || !sext_ln703_483_fu_139338_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_139_fu_139326_p1.read()) + sc_bigint<12>(sext_ln703_483_fu_139338_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_84_fu_130612_p2() {
    add_ln703_84_fu_130612_p2 = (!zext_ln1118_540_fu_124957_p1.read().is_01() || !add_ln703_83_fu_130606_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_540_fu_124957_p1.read()) + sc_biguint<10>(add_ln703_83_fu_130606_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_850_fu_139352_p2() {
    add_ln703_850_fu_139352_p2 = (!add_ln703_844_fu_139320_p2.read().is_01() || !sext_ln703_484_fu_139348_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_844_fu_139320_p2.read()) + sc_bigint<15>(sext_ln703_484_fu_139348_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_851_fu_139358_p2() {
    add_ln703_851_fu_139358_p2 = (!sext_ln203_126_fu_136456_p1.read().is_01() || !add_ln703_850_fu_139352_p2.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_126_fu_136456_p1.read()) + sc_biguint<15>(add_ln703_850_fu_139352_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_852_fu_139364_p2() {
    add_ln703_852_fu_139364_p2 = (!sext_ln203_125_fu_136416_p1.read().is_01() || !zext_ln708_365_fu_136460_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_125_fu_136416_p1.read()) + sc_biguint<11>(zext_ln708_365_fu_136460_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_853_fu_139374_p2() {
    add_ln703_853_fu_139374_p2 = (!zext_ln203_39_fu_136442_p1.read().is_01() || !sext_ln703_485_fu_139370_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_39_fu_136442_p1.read()) + sc_bigint<12>(sext_ln703_485_fu_139370_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_855_fu_132969_p2() {
    add_ln703_855_fu_132969_p2 = (!sext_ln203_127_fu_129242_p1.read().is_01() || !ap_const_lv12_FD8.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_127_fu_129242_p1.read()) + sc_bigint<12>(ap_const_lv12_FD8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_856_fu_132979_p2() {
    add_ln703_856_fu_132979_p2 = (!sext_ln203_128_fu_129246_p1.read().is_01() || !sext_ln703_124_fu_132975_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_128_fu_129246_p1.read()) + sc_bigint<13>(sext_ln703_124_fu_132975_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_857_fu_132985_p2() {
    add_ln703_857_fu_132985_p2 = (!sext_ln708_44_fu_129250_p1.read().is_01() || !zext_ln1118_808_fu_129264_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln708_44_fu_129250_p1.read()) + sc_biguint<12>(zext_ln1118_808_fu_129264_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_858_fu_132995_p2() {
    add_ln703_858_fu_132995_p2 = (!add_ln703_856_fu_132979_p2.read().is_01() || !sext_ln703_488_fu_132991_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_856_fu_132979_p2.read()) + sc_bigint<13>(sext_ln703_488_fu_132991_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_859_fu_133005_p2() {
    add_ln703_859_fu_133005_p2 = (!sext_ln203_129_fu_129271_p1.read().is_01() || !sext_ln703_125_fu_133001_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_129_fu_129271_p1.read()) + sc_bigint<14>(sext_ln703_125_fu_133001_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_85_fu_118117_p2() {
    add_ln703_85_fu_118117_p2 = (!sext_ln1118_18_fu_117194_p1.read().is_01() || !zext_ln708_233_fu_117220_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_18_fu_117194_p1.read()) + sc_biguint<11>(zext_ln708_233_fu_117220_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_860_fu_133011_p2() {
    add_ln703_860_fu_133011_p2 = (!sext_ln1118_258_fu_129268_p1.read().is_01() || !sext_ln1118_259_fu_129288_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_258_fu_129268_p1.read()) + sc_bigint<10>(sext_ln1118_259_fu_129288_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_861_fu_133021_p2() {
    add_ln703_861_fu_133021_p2 = (!zext_ln708_366_fu_129284_p1.read().is_01() || !sext_ln703_489_fu_133017_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_366_fu_129284_p1.read()) + sc_bigint<11>(sext_ln703_489_fu_133017_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_862_fu_133031_p2() {
    add_ln703_862_fu_133031_p2 = (!add_ln703_859_fu_133005_p2.read().is_01() || !sext_ln703_490_fu_133027_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_859_fu_133005_p2.read()) + sc_bigint<14>(sext_ln703_490_fu_133027_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_863_fu_133037_p2() {
    add_ln703_863_fu_133037_p2 = (!sext_ln1118_266_fu_129473_p1.read().is_01() || !sext_ln708_45_fu_129431_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_266_fu_129473_p1.read()) + sc_bigint<12>(sext_ln708_45_fu_129431_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_864_fu_139397_p2() {
    add_ln703_864_fu_139397_p2 = (!add_ln703_862_reg_143228.read().is_01() || !sext_ln703_491_fu_139394_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_862_reg_143228.read()) + sc_bigint<14>(sext_ln703_491_fu_139394_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_865_fu_133043_p2() {
    add_ln703_865_fu_133043_p2 = (!zext_ln1118_812_fu_129319_p1.read().is_01() || !zext_ln1118_811_fu_129315_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_812_fu_129319_p1.read()) + sc_biguint<10>(zext_ln1118_811_fu_129315_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_866_fu_133053_p2() {
    add_ln703_866_fu_133053_p2 = (!zext_ln708_367_fu_129346_p1.read().is_01() || !zext_ln1118_814_fu_129342_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_367_fu_129346_p1.read()) + sc_biguint<10>(zext_ln1118_814_fu_129342_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_867_fu_133063_p2() {
    add_ln703_867_fu_133063_p2 = (!zext_ln703_140_fu_133049_p1.read().is_01() || !zext_ln703_141_fu_133059_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_140_fu_133049_p1.read()) + sc_biguint<11>(zext_ln703_141_fu_133059_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_868_fu_139405_p2() {
    add_ln703_868_fu_139405_p2 = (!add_ln703_864_fu_139397_p2.read().is_01() || !zext_ln703_142_fu_139402_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_864_fu_139397_p2.read()) + sc_biguint<14>(zext_ln703_142_fu_139402_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_869_fu_133069_p2() {
    add_ln703_869_fu_133069_p2 = (!sext_ln1118_263_fu_129411_p1.read().is_01() || !sext_ln1118_262_fu_129380_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_263_fu_129411_p1.read()) + sc_bigint<10>(sext_ln1118_262_fu_129380_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_86_fu_118127_p2() {
    add_ln703_86_fu_118127_p2 = (!zext_ln1118_338_fu_117208_p1.read().is_01() || !sext_ln708_5_fu_117224_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln1118_338_fu_117208_p1.read()) + sc_bigint<11>(sext_ln708_5_fu_117224_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_870_fu_139418_p2() {
    add_ln703_870_fu_139418_p2 = (!zext_ln1118_815_fu_136464_p1.read().is_01() || !sext_ln703_493_fu_139415_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_815_fu_136464_p1.read()) + sc_bigint<12>(sext_ln703_493_fu_139415_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_871_fu_133075_p2() {
    add_ln703_871_fu_133075_p2 = (!sext_ln1118_260_fu_129311_p1.read().is_01() || !sext_ln1118_265_fu_129454_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_260_fu_129311_p1.read()) + sc_bigint<10>(sext_ln1118_265_fu_129454_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_872_fu_133081_p2() {
    add_ln703_872_fu_133081_p2 = (!sext_ln1118_264_fu_129450_p1.read().is_01() || !zext_ln708_268_fu_126289_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1118_264_fu_129450_p1.read()) + sc_biguint<8>(zext_ln708_268_fu_126289_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_873_fu_133091_p2() {
    add_ln703_873_fu_133091_p2 = (!add_ln703_871_fu_133075_p2.read().is_01() || !sext_ln703_494_fu_133087_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(add_ln703_871_fu_133075_p2.read()) + sc_bigint<10>(sext_ln703_494_fu_133087_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_874_fu_139427_p2() {
    add_ln703_874_fu_139427_p2 = (!add_ln703_870_fu_139418_p2.read().is_01() || !sext_ln703_495_fu_139424_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_870_fu_139418_p2.read()) + sc_bigint<12>(sext_ln703_495_fu_139424_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_875_fu_139437_p2() {
    add_ln703_875_fu_139437_p2 = (!sext_ln703_492_fu_139411_p1.read().is_01() || !sext_ln703_496_fu_139433_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_492_fu_139411_p1.read()) + sc_bigint<15>(sext_ln703_496_fu_139433_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_876_fu_139443_p2() {
    add_ln703_876_fu_139443_p2 = (!sext_ln203_131_fu_136482_p1.read().is_01() || !sext_ln203_130_fu_136478_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_131_fu_136482_p1.read()) + sc_bigint<12>(sext_ln203_130_fu_136478_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_877_fu_139453_p2() {
    add_ln703_877_fu_139453_p2 = (!add_ln703_875_fu_139437_p2.read().is_01() || !sext_ln703_497_fu_139449_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_875_fu_139437_p2.read()) + sc_bigint<15>(sext_ln703_497_fu_139449_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_878_fu_139459_p2() {
    add_ln703_878_fu_139459_p2 = (!grp_fu_115447_p4.read().is_01() || !zext_ln203_108_fu_136485_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115447_p4.read()) + sc_biguint<10>(zext_ln203_108_fu_136485_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_879_fu_139469_p2() {
    add_ln703_879_fu_139469_p2 = (!sext_ln203_133_fu_136489_p1.read().is_01() || !zext_ln703_143_fu_139465_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_133_fu_136489_p1.read()) + sc_biguint<12>(zext_ln703_143_fu_139465_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_87_fu_118137_p2() {
    add_ln703_87_fu_118137_p2 = (!sext_ln703_65_fu_118123_p1.read().is_01() || !sext_ln703_69_fu_118133_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_65_fu_118123_p1.read()) + sc_bigint<12>(sext_ln703_69_fu_118133_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_880_fu_139479_p2() {
    add_ln703_880_fu_139479_p2 = (!add_ln703_877_fu_139453_p2.read().is_01() || !sext_ln703_498_fu_139475_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_877_fu_139453_p2.read()) + sc_bigint<15>(sext_ln703_498_fu_139475_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_881_fu_139485_p2() {
    add_ln703_881_fu_139485_p2 = (!sext_ln203_134_fu_136523_p1.read().is_01() || !zext_ln203_109_fu_136547_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_134_fu_136523_p1.read()) + sc_biguint<9>(zext_ln203_109_fu_136547_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_882_fu_139495_p2() {
    add_ln703_882_fu_139495_p2 = (!zext_ln203_39_fu_136442_p1.read().is_01() || !sext_ln703_499_fu_139491_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln203_39_fu_136442_p1.read()) + sc_bigint<12>(sext_ln703_499_fu_139491_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_883_fu_133097_p2() {
    add_ln703_883_fu_133097_p2 = (!sext_ln203_135_fu_129542_p1.read().is_01() || !sext_ln203_132_fu_129522_p1.read().is_01())? sc_lv<6>(): (sc_bigint<6>(sext_ln203_135_fu_129542_p1.read()) + sc_bigint<6>(sext_ln203_132_fu_129522_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_884_fu_133107_p2() {
    add_ln703_884_fu_133107_p2 = (!zext_ln203_40_fu_129492_p1.read().is_01() || !sext_ln703_500_fu_133103_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln203_40_fu_129492_p1.read()) + sc_bigint<9>(sext_ln703_500_fu_133103_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_885_fu_139504_p2() {
    add_ln703_885_fu_139504_p2 = (!add_ln703_882_fu_139495_p2.read().is_01() || !sext_ln703_501_fu_139501_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(add_ln703_882_fu_139495_p2.read()) + sc_bigint<12>(sext_ln703_501_fu_139501_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_887_fu_133113_p2() {
    add_ln703_887_fu_133113_p2 = (!zext_ln1118_822_fu_129553_p1.read().is_01() || !zext_ln1118_821_fu_129549_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_822_fu_129553_p1.read()) + sc_biguint<10>(zext_ln1118_821_fu_129549_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_888_fu_133119_p2() {
    add_ln703_888_fu_133119_p2 = (!zext_ln1118_820_fu_129546_p1.read().is_01() || !add_ln703_887_fu_133113_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_820_fu_129546_p1.read()) + sc_biguint<10>(add_ln703_887_fu_133113_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_889_fu_133129_p2() {
    add_ln703_889_fu_133129_p2 = (!sext_ln1116_24_fu_128636_p1.read().is_01() || !ap_const_lv10_2E8.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1116_24_fu_128636_p1.read()) + sc_bigint<10>(ap_const_lv10_2E8));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_88_fu_130625_p2() {
    add_ln703_88_fu_130625_p2 = (!zext_ln703_15_fu_130618_p1.read().is_01() || !sext_ln703_70_fu_130622_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln703_15_fu_130618_p1.read()) + sc_bigint<13>(sext_ln703_70_fu_130622_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_890_fu_133135_p2() {
    add_ln703_890_fu_133135_p2 = (!zext_ln708_368_fu_129557_p1.read().is_01() || !add_ln703_889_fu_133129_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_368_fu_129557_p1.read()) + sc_biguint<10>(add_ln703_889_fu_133129_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_891_fu_133145_p2() {
    add_ln703_891_fu_133145_p2 = (!zext_ln703_144_fu_133125_p1.read().is_01() || !sext_ln703_504_fu_133141_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln703_144_fu_133125_p1.read()) + sc_bigint<11>(sext_ln703_504_fu_133141_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_892_fu_133155_p2() {
    add_ln703_892_fu_133155_p2 = (!zext_ln1116_73_fu_129561_p1.read().is_01() || !sext_ln703_505_fu_133151_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1116_73_fu_129561_p1.read()) + sc_bigint<12>(sext_ln703_505_fu_133151_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_893_fu_133161_p2() {
    add_ln703_893_fu_133161_p2 = (!zext_ln1118_824_fu_129568_p1.read().is_01() || !sext_ln708_46_fu_129564_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln1118_824_fu_129568_p1.read()) + sc_bigint<12>(sext_ln708_46_fu_129564_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_894_fu_139530_p2() {
    add_ln703_894_fu_139530_p2 = (!sext_ln703_506_fu_139524_p1.read().is_01() || !sext_ln703_507_fu_139527_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_506_fu_139524_p1.read()) + sc_bigint<13>(sext_ln703_507_fu_139527_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_895_fu_139536_p2() {
    add_ln703_895_fu_139536_p2 = (!zext_ln1118_826_fu_136551_p1.read().is_01() || !add_ln703_894_fu_139530_p2.read().is_01())? sc_lv<13>(): (sc_biguint<13>(zext_ln1118_826_fu_136551_p1.read()) + sc_biguint<13>(add_ln703_894_fu_139530_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_896_fu_133167_p2() {
    add_ln703_896_fu_133167_p2 = (!trunc_ln1118_44_fu_129629_p4.read().is_01() || !zext_ln1118_828_fu_129615_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(trunc_ln1118_44_fu_129629_p4.read()) + sc_biguint<9>(zext_ln1118_828_fu_129615_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_897_fu_139545_p2() {
    add_ln703_897_fu_139545_p2 = (!add_ln703_895_fu_139536_p2.read().is_01() || !zext_ln703_145_fu_139542_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_895_fu_139536_p2.read()) + sc_biguint<13>(zext_ln703_145_fu_139542_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_898_fu_133173_p2() {
    add_ln703_898_fu_133173_p2 = (!zext_ln708_173_fu_128950_p1.read().is_01() || !zext_ln1116_74_fu_129673_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_173_fu_128950_p1.read()) + sc_biguint<10>(zext_ln1116_74_fu_129673_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_899_fu_133183_p2() {
    add_ln703_899_fu_133183_p2 = (!sext_ln1116_30_fu_129669_p1.read().is_01() || !sext_ln1118_268_fu_129591_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln1116_30_fu_129669_p1.read()) + sc_bigint<8>(sext_ln1118_268_fu_129591_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_89_fu_130635_p2() {
    add_ln703_89_fu_130635_p2 = (!add_ln703_82_fu_130600_p2.read().is_01() || !sext_ln703_71_fu_130631_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_82_fu_130600_p2.read()) + sc_bigint<15>(sext_ln703_71_fu_130631_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_8_fu_122563_p2() {
    add_ln703_8_fu_122563_p2 = (!sext_ln708_1_fu_118634_p1.read().is_01() || !sext_ln708_fu_118528_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln708_1_fu_118634_p1.read()) + sc_bigint<10>(sext_ln708_fu_118528_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_900_fu_133193_p2() {
    add_ln703_900_fu_133193_p2 = (!zext_ln703_146_fu_133179_p1.read().is_01() || !sext_ln703_509_fu_133189_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_146_fu_133179_p1.read()) + sc_bigint<12>(sext_ln703_509_fu_133189_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_901_fu_139558_p2() {
    add_ln703_901_fu_139558_p2 = (!sext_ln703_508_fu_139551_p1.read().is_01() || !sext_ln703_510_fu_139555_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_508_fu_139551_p1.read()) + sc_bigint<14>(sext_ln703_510_fu_139555_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_902_fu_133199_p2() {
    add_ln703_902_fu_133199_p2 = (!sext_ln1118_272_fu_129722_p1.read().is_01() || !sext_ln1118_270_fu_129676_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_272_fu_129722_p1.read()) + sc_bigint<12>(sext_ln1118_270_fu_129676_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_903_fu_139567_p2() {
    add_ln703_903_fu_139567_p2 = (!add_ln703_901_fu_139558_p2.read().is_01() || !sext_ln703_511_fu_139564_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_901_fu_139558_p2.read()) + sc_bigint<14>(sext_ln703_511_fu_139564_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_904_fu_133205_p2() {
    add_ln703_904_fu_133205_p2 = (!sext_ln1118_275_fu_129755_p1.read().is_01() || !sext_ln1118_273_fu_129726_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_275_fu_129755_p1.read()) + sc_bigint<12>(sext_ln1118_273_fu_129726_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_905_fu_133215_p2() {
    add_ln703_905_fu_133215_p2 = (!zext_ln708_369_fu_129718_p1.read().is_01() || !zext_ln1116_75_fu_129714_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_369_fu_129718_p1.read()) + sc_biguint<10>(zext_ln1116_75_fu_129714_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_906_fu_133225_p2() {
    add_ln703_906_fu_133225_p2 = (!sext_ln703_513_fu_133211_p1.read().is_01() || !zext_ln703_147_fu_133221_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_513_fu_133211_p1.read()) + sc_biguint<13>(zext_ln703_147_fu_133221_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_907_fu_139580_p2() {
    add_ln703_907_fu_139580_p2 = (!sext_ln703_512_fu_139573_p1.read().is_01() || !sext_ln703_514_fu_139577_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_512_fu_139573_p1.read()) + sc_bigint<15>(sext_ln703_514_fu_139577_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_908_fu_133231_p2() {
    add_ln703_908_fu_133231_p2 = (!zext_ln1118_837_fu_129801_p1.read().is_01() || !zext_ln1118_836_fu_129787_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_837_fu_129801_p1.read()) + sc_biguint<10>(zext_ln1118_836_fu_129787_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_909_fu_133237_p2() {
    add_ln703_909_fu_133237_p2 = (!zext_ln1118_833_fu_129759_p1.read().is_01() || !add_ln703_908_fu_133231_p2.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln1118_833_fu_129759_p1.read()) + sc_biguint<10>(add_ln703_908_fu_133231_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_90_fu_136970_p2() {
    add_ln703_90_fu_136970_p2 = (!sext_ln203_10_fu_133958_p1.read().is_01() || !zext_ln203_4_fu_133905_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_10_fu_133958_p1.read()) + sc_biguint<12>(zext_ln203_4_fu_133905_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_910_fu_133243_p2() {
    add_ln703_910_fu_133243_p2 = (!sext_ln1118_149_fu_127328_p1.read().is_01() || !sext_ln1118_271_fu_129700_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_149_fu_127328_p1.read()) + sc_bigint<9>(sext_ln1118_271_fu_129700_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_911_fu_139592_p2() {
    add_ln703_911_fu_139592_p2 = (!sext_ln1118_276_fu_136574_p1.read().is_01() || !zext_ln1118_832_fu_136555_p1.read().is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln1118_276_fu_136574_p1.read()) + sc_biguint<9>(zext_ln1118_832_fu_136555_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_912_fu_139602_p2() {
    add_ln703_912_fu_139602_p2 = (!sext_ln703_515_fu_139589_p1.read().is_01() || !sext_ln703_516_fu_139598_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln703_515_fu_139589_p1.read()) + sc_bigint<10>(sext_ln703_516_fu_139598_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_913_fu_139612_p2() {
    add_ln703_913_fu_139612_p2 = (!zext_ln703_148_fu_139586_p1.read().is_01() || !sext_ln703_517_fu_139608_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_148_fu_139586_p1.read()) + sc_bigint<12>(sext_ln703_517_fu_139608_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_914_fu_139622_p2() {
    add_ln703_914_fu_139622_p2 = (!add_ln703_907_fu_139580_p2.read().is_01() || !sext_ln703_518_fu_139618_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_907_fu_139580_p2.read()) + sc_bigint<15>(sext_ln703_518_fu_139618_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_915_fu_139628_p2() {
    add_ln703_915_fu_139628_p2 = (!zext_ln203_41_fu_136588_p1.read().is_01() || !add_ln703_914_fu_139622_p2.read().is_01())? sc_lv<15>(): (sc_biguint<15>(zext_ln203_41_fu_136588_p1.read()) + sc_biguint<15>(add_ln703_914_fu_139622_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_916_fu_139634_p2() {
    add_ln703_916_fu_139634_p2 = (!sext_ln203_137_fu_136616_p1.read().is_01() || !sext_ln203_136_fu_136612_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln203_137_fu_136616_p1.read()) + sc_bigint<11>(sext_ln203_136_fu_136612_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_917_fu_139640_p2() {
    add_ln703_917_fu_139640_p2 = (!zext_ln708_370_fu_136630_p1.read().is_01() || !add_ln703_916_fu_139634_p2.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_370_fu_136630_p1.read()) + sc_biguint<11>(add_ln703_916_fu_139634_p2.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_919_fu_133249_p2() {
    add_ln703_919_fu_133249_p2 = (!grp_fu_115827_p4.read().is_01() || !ap_const_lv10_C0.is_01())? sc_lv<10>(): (sc_biguint<10>(grp_fu_115827_p4.read()) + sc_biguint<10>(ap_const_lv10_C0));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_91_fu_136980_p2() {
    add_ln703_91_fu_136980_p2 = (!add_ln703_89_reg_142848.read().is_01() || !sext_ln703_72_fu_136976_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_89_reg_142848.read()) + sc_bigint<15>(sext_ln703_72_fu_136976_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_920_fu_133259_p2() {
    add_ln703_920_fu_133259_p2 = (!zext_ln703_2_fu_133255_p1.read().is_01() || !sext_ln203_138_fu_129805_p1.read().is_01())? sc_lv<12>(): (sc_biguint<12>(zext_ln703_2_fu_133255_p1.read()) + sc_bigint<12>(sext_ln203_138_fu_129805_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_921_fu_133269_p2() {
    add_ln703_921_fu_133269_p2 = (!sext_ln203_139_fu_129808_p1.read().is_01() || !sext_ln703_132_fu_133265_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_139_fu_129808_p1.read()) + sc_bigint<13>(sext_ln703_132_fu_133265_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_922_fu_133275_p2() {
    add_ln703_922_fu_133275_p2 = (!sext_ln1118_277_fu_129811_p1.read().is_01() || !zext_ln708_371_fu_129815_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_277_fu_129811_p1.read()) + sc_biguint<11>(zext_ln708_371_fu_129815_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_923_fu_133285_p2() {
    add_ln703_923_fu_133285_p2 = (!add_ln703_921_fu_133269_p2.read().is_01() || !sext_ln703_521_fu_133281_p1.read().is_01())? sc_lv<13>(): (sc_biguint<13>(add_ln703_921_fu_133269_p2.read()) + sc_bigint<13>(sext_ln703_521_fu_133281_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_924_fu_133291_p2() {
    add_ln703_924_fu_133291_p2 = (!zext_ln708_309_fu_127572_p1.read().is_01() || !zext_ln708_372_fu_129828_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln708_309_fu_127572_p1.read()) + sc_biguint<11>(zext_ln708_372_fu_129828_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_925_fu_139666_p2() {
    add_ln703_925_fu_139666_p2 = (!sext_ln703_133_fu_139660_p1.read().is_01() || !zext_ln703_149_fu_139663_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_133_fu_139660_p1.read()) + sc_biguint<14>(zext_ln703_149_fu_139663_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_926_fu_124277_p2() {
    add_ln703_926_fu_124277_p2 = (!sext_ln1118_279_fu_122366_p1.read().is_01() || !sext_ln1118_278_fu_122346_p1.read().is_01())? sc_lv<7>(): (sc_bigint<7>(sext_ln1118_279_fu_122366_p1.read()) + sc_bigint<7>(sext_ln1118_278_fu_122346_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_927_fu_124287_p2() {
    add_ln703_927_fu_124287_p2 = (!zext_ln708_250_fu_119550_p1.read().is_01() || !sext_ln703_522_fu_124283_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln708_250_fu_119550_p1.read()) + sc_bigint<10>(sext_ln703_522_fu_124283_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_928_fu_139675_p2() {
    add_ln703_928_fu_139675_p2 = (!add_ln703_925_fu_139666_p2.read().is_01() || !sext_ln703_523_fu_139672_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(add_ln703_925_fu_139666_p2.read()) + sc_bigint<14>(sext_ln703_523_fu_139672_p1.read()));
}

void pointwise_conv_1d_latency_cl_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_add_ln703_929_fu_133297_p2() {
    add_ln703_929_fu_133297_p2 = (!sext_ln1118_280_fu_129862_p1.read().is_01() || !zext_ln1118_840_fu_129832_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_280_fu_129862_p1.read()) + sc_biguint<12>(zext_ln1118_840_fu_129832_p1.read()));
}

}

